/*
 * GeekOS file system
 * Copyright (c) 2004, David H. Hovemeyer <daveho@cs.umd.edu>
 * $Revision: 1.54 $
 *
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#include <limits.h>
#include <geekos/errno.h>
#include <geekos/kassert.h>
#include <geekos/screen.h>
#include <geekos/malloc.h>
#include <geekos/string.h>
#include <geekos/bitset.h>
#include <geekos/synch.h>
#include <geekos/int.h>
#include <geekos/bufcache.h>
#include <geekos/gosfs.h>
#include <geekos/user.h>
#include <libc/sched.h>

#ifdef DEBUG
#ifndef FS_DEBUG
#define FS_DEBUG
#endif
#endif

#ifdef FS_DEBUG
#define Debug(args...) Print(args)
#else
#define Debug(args...)
#endif


/* ----------------------------------------------------------------------
 * Private data and functions
 * ---------------------------------------------------------------------- */

//uint_t g_gosfs_sync = GOSFS_AUTOSYNC;

/* ----------------------------------------------------------------------
 * Implementation of VFS operations
 * ---------------------------------------------------------------------- */

/* find the next free inode (number) */
int Find_Free_Inode(struct Mount_Point *mountPoint, ulong_t *retInode)
{
    int rc=-1;
    ulong_t i;
    
    for (i=0; i<GOSFS_NUM_INODES; i++)
    {
        if (((struct GOSFS_Instance*)(mountPoint->fsData))->superblock.inodes[i].flags == 0)
        {
            rc=0;
            *retInode=i;
            break;
        }
    }
    
    return rc;
}


int removeTrailingSlash(char* src)
{
    if (src[strlen(src)-1]!='/') // no / at the end
    {
        return 0;
    }
    else
    {
        src[strlen(src)-1]='\0';
        return 0;
    }
}

int SetInodeDefaults(struct GOSFS_Inode* pInode)
{
    ulong_t e=0;
    
    pInode->size=0;
    pInode->link_count=0;
    pInode->blocks_used=0;
    pInode->flags=0;
    pInode->time_access=0;
    pInode->time_modified=0;
    pInode->time_inode=0;
    for (e=0; e<GOSFS_NUM_BLOCK_PTRS; e++)
    {
        pInode->blockList[e]=0;
    }
    
    return 1;

}

/* check to see if directory is empty */
bool IsDirectoryEmpty(struct GOSFS_Inode* pInode, struct GOSFS_Instance* p_instance)
{
    bool rc = 1, rc2 = 0;
    int i = 0, e = 0;
    struct FS_Buffer* p_buff = 0;
    ulong_t blockNum = 0;
    struct GOSFS_Directory*    tmpDir = 0;
    
    // check to see if it is a directory
    if (!(pInode->flags & GOSFS_INODE_ISDIRECTORY)) 
        goto finish;
    
    // check if we find any blocks with non empty-directory entries
    for (i=0; i<GOSFS_NUM_DIRECT_BLOCKS; i++)
    {
        blockNum = pInode->blockList[i];
        if (blockNum != 0)
        {
            Debug("found direct block %ld\n",blockNum);
            rc2 = Get_FS_Buffer (p_instance->buffercache, blockNum, &p_buff);
            if (rc2 < 0)
            {
                Debug("Unable to get buffer for search-directory\n");
                rc = EFSGEN;
                goto finish;
            }
            
            for (e=0; e<GOSFS_DIR_ENTRIES_PER_BLOCK; e++)
            {
                //Debug("checking directory entry %d\n",e);
                tmpDir = (struct GOSFS_Directory*) ( (p_buff->data)+(e*sizeof(struct GOSFS_Directory)) );
                if (tmpDir->type == GOSFS_DIRTYP_REGULAR)
                {
                    Debug("found used directory %d(%s) in block %ld\n", e, tmpDir->filename, blockNum);
                    rc = 0;
                    goto finish;
                }
            }
            
            rc2 = Release_FS_Buffer(p_instance->buffercache, p_buff);
            p_buff = 0;
            
            if (rc2<0)
            {
                Debug("Unable to release fs_buffer for new-directory\n");
                rc = EFSGEN;
                goto finish;
            }
        }
    }


finish:
    if (p_buff != 0)  Release_FS_Buffer(p_instance->buffercache, p_buff);
    Debug("IsDirectoryEmpty returns %d\n", (int)rc);
    return rc;
}


/* calc number of needed blocks for spezified number of bytes */
int FindNumBlocks(ulong_t size)
{
    return (((size-1)/GOSFS_FS_BLOCK_SIZE)+1);
}


/* wirte superblock from instance to disc */
int WriteSuperblock(struct GOSFS_Instance *p_instance)
{
    int numBlocks, rc=0;
    ulong_t numBytes, bwritten=0, i;
    struct FS_Buffer *p_buff=0;
    
    numBytes = p_instance->superblock.supersize;
    numBlocks = FindNumBlocks(numBytes);
    
    for (i=0; i<numBlocks; i++)
    {
        
        rc = Get_FS_Buffer(p_instance->buffercache,i,&p_buff);
        if (rc<0)
        {
            Debug("Unable to get buffer for new-directory\n");
            rc = EFSGEN;
            goto finish;
        }
        
        if ((p_instance->superblock.supersize - bwritten) < GOSFS_FS_BLOCK_SIZE)
        {
            memcpy(p_buff->data, ((void*)&(p_instance->superblock))+bwritten, p_instance->superblock.supersize - bwritten);
            bwritten = bwritten + (p_instance->superblock.supersize - bwritten);
        }
        else
        {
            memcpy(p_buff->data, ((void*)&(p_instance->superblock))+bwritten, GOSFS_FS_BLOCK_SIZE);
            bwritten = bwritten+GOSFS_FS_BLOCK_SIZE;
        }
        
        Modify_FS_Buffer(p_instance->buffercache,p_buff);
/*
        if (g_gosfs_sync)
        {
            rc = Sync_FS_Buffer(p_instance->buffercache, p_buff);
            if (rc<0)
            {
                Debug("Unable to sync fs_buffer for new-directory\n");
                rc = EFSGEN;
                goto finish;
            }
        }
*/    
        rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
        p_buff = 0;
        if (rc<0)
        {
            Debug("Unable to release fs_buffer for new-directory\n");
            rc = EFSGEN;
            goto finish;
        }
    }
        
finish:
    if (p_buff!=0) Release_FS_Buffer(p_instance->buffercache, p_buff);
    return rc;
}



/* create a block with directory-entries for spezified inode*/
/* including . and .. directories */
int CreateFirstDirectoryBlock(ulong_t thisInode, ulong_t parentInode, struct FS_Buffer *p_buff)
{
    struct GOSFS_Directory dirEntry;
    int i;
    
    // create "." and ".." entries for root-directory    
    for (i=0; i<GOSFS_DIR_ENTRIES_PER_BLOCK; i++)
    {
        if (i==0)    // this directory entry "."
        {
            dirEntry.type = GOSFS_DIRTYP_THIS;
            dirEntry.inode = thisInode;
            strcpy(dirEntry.filename, GOSFS_THIS_DIRECTORY);
        }
        else if (i==1)    // parent directory entry ".."
        {
            dirEntry.type = GOSFS_DIRTYP_PARENT;
            dirEntry.inode = parentInode;
            strcpy(dirEntry.filename, GOSFS_PARENT_DIRECTORY);
        }
        else
        {
            dirEntry.type = GOSFS_DIRTYP_FREE;
            dirEntry.inode = 0;
            strcpy(dirEntry.filename, "\0");
        }
        
        memcpy(p_buff->data + (i*sizeof(struct GOSFS_Directory)), &dirEntry, sizeof(struct GOSFS_Directory));
    }
    
    return 0;
}

/* create a block with directory-entries for spezified inode*/
int CreateNextDirectoryBlock(struct FS_Buffer *p_buff)
{
    struct GOSFS_Directory dirEntry;
    int i;
    
    for (i=0; i<GOSFS_DIR_ENTRIES_PER_BLOCK; i++)
    {
        dirEntry.type = GOSFS_DIRTYP_FREE;
        dirEntry.inode = 0;
        strcpy(dirEntry.filename, "\0");
        
        memcpy(p_buff->data + (i*sizeof(struct GOSFS_Directory)), &dirEntry, sizeof(struct GOSFS_Directory));
    }
    
    return 0;
}


/* remove directory entry from inode */
int RemoveDirEntryFromInode(struct GOSFS_Instance *p_instance, ulong_t parentInode, ulong_t inode)
{
    int rc = 0, i = 0, e = 0;
    struct FS_Buffer *p_buff = 0;
    struct GOSFS_Directory* tmpDir = 0;
    ulong_t blockNum=0;
    
    Debug("About to remove inode %ld from dir-inode %ld\n",inode, parentInode);
    
    // search the directory entries for inode to delete
    for (i=0; i<GOSFS_NUM_DIRECT_BLOCKS; i++)
    {
        blockNum = p_instance->superblock.inodes[parentInode].blockList[i];
        if (blockNum != 0)
        {        
            rc = Get_FS_Buffer(p_instance->buffercache,blockNum,&p_buff);
            if (rc<0)
            {
                Debug("Unable to get buffer for search-directory\n");
                rc = EFSGEN;
                goto finish;
            }
            
            for (e=0; e<GOSFS_DIR_ENTRIES_PER_BLOCK; e++)
            {
                tmpDir = (struct GOSFS_Directory*)((p_buff->data)+(e*sizeof(struct GOSFS_Directory)));
                if (tmpDir->inode == inode)
                {
                    Debug("found directory entry %d in Block %ld\n",e,blockNum);
                    tmpDir->inode=0;
                    tmpDir->type=GOSFS_DIRTYP_FREE;
                    strcpy(tmpDir->filename, "\0");
                    
                    Modify_FS_Buffer(p_instance->buffercache,p_buff);
/*
                    if (g_gosfs_sync)
                    {            
                        rc = Sync_FS_Buffer(p_instance->buffercache, p_buff);
                    
                        if (rc<0)
                        {
                            Debug("Unable to sync fs_buffer for new-directory\n");
                            rc = EFSGEN;
                            goto finish;
                        }
                    }
*/
                    // decrease size of parent_inode
                    p_instance->superblock.inodes[parentInode].size--;
                    
                    // superblock is written in Delete functions
                    
                    //TODO: check if there are still directory entries in this block, if not, free block
                    goto finish;
                }
            }
            
            
            rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
            p_buff = 0;
            
            if (rc<0)
            {
                Debug("Unable to release fs_buffer for new-directory\n");
                rc = EFSGEN;
                goto finish;
            }
        }
    }
    
finish:
    if (p_buff != 0)  Release_FS_Buffer(p_instance->buffercache, p_buff);
    return rc;
}


/* add a directory-entry to an inode */
int AddDirEntry2Inode(struct GOSFS_Instance *p_instance, ulong_t parentInode, struct GOSFS_Directory *dirEntry)
{
    int i=0,e=0,rc=0,found=0, numDirectPtr=-1;
    ulong_t blockNum;
    struct FS_Buffer *p_buff=0;
    struct GOSFS_Directory *tmpDir=0;
    
    // find a free directory entry in the direct blocks
    for (i=0; i<GOSFS_NUM_DIRECT_BLOCKS; i++)
    {
        if (found==1) break;
            
        blockNum = p_instance->superblock.inodes[parentInode].blockList[i];
        if (blockNum != 0)
        {
            Debug("found direct block %ld\n",blockNum);
            rc = Get_FS_Buffer(p_instance->buffercache,blockNum,&p_buff);
            if (rc<0)
            {
                Debug("Unable to get buffer for search-directory\n");
                rc = EFSGEN;
                goto finish;
            }
            
            for (e=0; e < GOSFS_DIR_ENTRIES_PER_BLOCK; e++)
            {
                //Debug("checking directory entry %d\n",e);
                tmpDir = (struct GOSFS_Directory*)((p_buff->data)+(e*sizeof(struct GOSFS_Directory)));
                if (tmpDir->type == GOSFS_DIRTYP_FREE)
                {
                    Debug("found free directory %d in block %ld\n",e,blockNum);
                    
                    memcpy((p_buff->data)+(e*sizeof(struct GOSFS_Directory)), dirEntry, sizeof(struct GOSFS_Directory));
                    
                    found=1;
                    
                    Modify_FS_Buffer(p_instance->buffercache,p_buff);
/*
                    if (g_gosfs_sync)
                    {
                        rc = Sync_FS_Buffer(p_instance->buffercache, p_buff);
                    
                        if (rc<0)
                        {
                        Debug("Unable to sync fs_buffer for new-directory\n");
                            rc = EFSGEN;
                            goto finish;
                        }
                    }
*/

                    p_instance->superblock.inodes[parentInode].size++;
/*                    
                    rc = WriteSuperblock(p_instance);
                    if (rc<0)
                    {
                        Debug("count not write superblock to disk\n");
                        rc = EFSGEN;
                        goto finish;
                    }
*/
                    
                    //goto finish;
                    break;
                }
            }
            
            rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
            p_buff = 0;
            
            if (rc<0)
            {
                Debug("Unable to release fs_buffer for new-directory\n");
                rc = EFSGEN;
                goto finish;
            }
        }
    }
    
    // no block with free directory entry found, create a new block
    numDirectPtr=-1;
    if (found==0)
    {
        Debug("no free directory found, create new directory block\n");
        // find next direct-block to allocate
        for (i=0; i<GOSFS_NUM_DIRECT_BLOCKS; i++)
        {
            Debug("direct ptr %d has value %ld\n",i,p_instance->superblock.inodes[parentInode].blockList[i]);
            // free direct ptr
            if (p_instance->superblock.inodes[parentInode].blockList[i] == 0)
            {
                numDirectPtr=i;
            Debug("using direct ptr %d.\n",numDirectPtr);
                break;
            }
        }
    }
    
    if ((found==0) && (numDirectPtr>=0))
    {    
        blockNum=Find_First_Free_Bit(p_instance->superblock.bitSet, p_instance->superblock.size);
        if (blockNum<=0)
        {
            Debug("no free block found.\n");
            rc = EFSGEN;
            goto finish;
        }

        Debug("found free directory 0 in block %ld\n",blockNum);
        
        rc = Get_FS_Buffer(p_instance->buffercache,blockNum,&p_buff);
        if (rc<0)
        {
            Debug("Unable to get buffer for search-directory\n");
            rc = EFSGEN;
            goto finish;
        }
        
        rc = CreateNextDirectoryBlock(p_buff);
        // copy directory on first position
        memcpy(p_buff->data, dirEntry, sizeof(struct GOSFS_Directory));
        
        Modify_FS_Buffer(p_instance->buffercache,p_buff);
/*
        if (g_gosfs_sync)
        {
            rc = Sync_FS_Buffer(p_instance->buffercache, p_buff);
            if (rc<0)
            {
                Debug("Unable to sync fs_buffer for new-directory\n");
                rc = EFSGEN;
                goto finish;
            }    
        }
*/
        
        rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
        p_buff = 0;
        if (rc<0)
        {
            Debug("Unable to release fs_buffer for new-directory\n");
            rc = EFSGEN;
            goto finish;
        }
        
        p_instance->superblock.inodes[parentInode].blockList[numDirectPtr]=blockNum;
        p_instance->superblock.inodes[parentInode].size++;
        Set_Bit(p_instance->superblock.bitSet, blockNum);
/*        
        rc = WriteSuperblock(p_instance);
        if (rc<0)
        {
            Debug("count not write superblock to disk\n");
            rc = EFSGEN;
            goto finish;
        }
*/
        
        found = 1;
        goto finish;
            
    }

    // all direct blocks full
    if (found == 0)  rc = -1;
    
finish:
    if (p_buff!=0) Release_FS_Buffer(p_instance->buffercache, p_buff);
    if (found == 0)
        Debug("no free directory found and no direct blocks available\n");
    return rc;
}



/* find inode in directory by filename or pathname*/
int Find_InodeInDirectory(struct GOSFS_Instance *p_instance, char *path, ulong_t searchInode, ulong_t* retInode)
{
    ulong_t i = 0, e = 0, blockNum;
    int rc = -1, ret = -1;
    struct FS_Buffer *p_buff = 0;
    struct GOSFS_Directory    *dirEntry;

    Debug("Find_InodeInDirectory: inode=%d path=%s\n",(int)searchInode, path);

    
    // search all direct blocks
    for (i=0; i<GOSFS_NUM_DIRECT_BLOCKS; i++)
    {
        blockNum = p_instance->superblock.inodes[searchInode].blockList[i];
        if (blockNum != 0)
        {
            rc = Get_FS_Buffer(p_instance->buffercache,blockNum,&p_buff);
            if (rc < 0)
            {
                Debug("Unable to get buffer for search-directory\n");
                ret = EFSGEN;
                goto finish;
            }
            
            // search through all directory entries
            for (e=0; e < GOSFS_DIR_ENTRIES_PER_BLOCK; e++)
            {
                dirEntry = (struct GOSFS_Directory*)((p_buff->data)+(e*sizeof(struct GOSFS_Directory)));
                if (dirEntry->type != GOSFS_DIRTYP_FREE)
                {
                    if (strcmp(dirEntry->filename, path)==0)
                    {
                        *retInode = dirEntry->inode;
                        ret = 0;
                        goto finish;
                    }
                }
            }
            Release_FS_Buffer(p_instance->buffercache, p_buff);
            p_buff=0;
        }
    }
    
finish:
    if (p_buff != 0) Release_FS_Buffer(p_instance->buffercache, p_buff);

    if (ret < 0) 
    {
        Debug("Find_InodeInDirectory: inode not found: %d\n",ret);
        return ret;
    }
    else 
    {
        Debug("Find_InodeInDirectory: returns %d\n",(int)*retInode);
        return ret;
    }
}


int Find_InodeByName(struct GOSFS_Instance *p_instance, const char *path, ulong_t* retInode)
{
    char* searchPath;
    char* nextSlash;
    int offset, rc = 0, finished = 0;
    ulong_t inode = 0;
    
    searchPath = Malloc(strlen(path)+1);
    
    Debug("Find_InodeByName: path=%s\n", path);
    
    // assume root-directory
    if (strcmp(path,"") == 0)
    {
        *retInode = 0;
        return rc;
    }
    if (path[0]!='/')  return -2;
    offset = 1;
    
    nextSlash=strchr(path+offset,'/');
    /*
    if (nextSlash==0) 
    {
        inode=0;    // file or dirctory is in root-directory
        finished=1;
    }
    */
    while (finished == 0)
    {
        if (nextSlash == 0)
        {
            finished = 1;
            nextSlash = (char*)path+strlen(path);
            
        }
        
        //searchPath=strncpy(searchPath, path+offset-1, nextSlash-(path+offset-1));
        searchPath = strncpy(searchPath, path+offset, nextSlash-(path+offset));
        searchPath[nextSlash-(path+offset)]='\0';
        Debug("searching for part %s in inode %d\n",searchPath, (int)inode);
        
        rc = Find_InodeInDirectory(p_instance, searchPath, inode, &inode);
        if (rc < 0) break;
        
        offset=nextSlash-path+1;
        nextSlash=strchr(path+offset,'/');
    }
    
    Free(searchPath);
    
    *retInode=inode;
    Debug("found inode %d\n",(int) inode);
    return rc;
}

/* create a file inode */
int CreateFileInode(struct Mount_Point *mountPoint, const char *path, ulong_t *inode)
{
    int rc=0;
    struct GOSFS_Inode* pInode;
    struct GOSFS_Instance* p_instance = (struct GOSFS_Instance*) mountPoint->fsData;
    struct GOSFS_Directory    dirEntry;
    char *filename=0, *parentpath=0;
    ulong_t parentInode;
    
    // strip filename from path including /
    filename=strrchr(path,'/')+1;
    
    rc = Find_Free_Inode(mountPoint, inode);
    if (rc<0)
    {
        rc=EFSGEN;
        goto finish;
    }
    
    pInode=&(p_instance->superblock.inodes[*inode]);
    SetInodeDefaults(pInode);
    pInode->inode=*inode;
    pInode->link_count=1;
    pInode->flags=GOSFS_INODE_USED;
    memset (pInode->acl, '\0', sizeof (struct VFS_ACL_Entry) * VFS_MAX_ACL_ENTRIES);
    pInode->acl[0].uid = g_currentThread->userContext ? g_currentThread->userContext->eUId : 0;
    pInode->acl[0].permission = O_READ | O_WRITE;
    
    dirEntry.type=GOSFS_DIRTYP_REGULAR;
    dirEntry.inode=*inode;
    strcpy(dirEntry.filename, filename);
    
    
    parentpath=Malloc(strlen(path));
    strncpy(parentpath, path, strrchr(path,'/')-path);
    parentpath[strrchr(path,'/')-path]='\0';
    Debug("searching for inode of parent path %s\n",parentpath);
    
    // search parent directory-inode
    rc=Find_InodeByName(p_instance, parentpath, &parentInode);
    if (rc<0)
    {
        Debug("parent inode not found\n");
        rc=EFSGEN;
        goto finish;
    }
    
    rc=AddDirEntry2Inode(p_instance, parentInode, &dirEntry);
    if (rc<0)
    {
        Debug("failed to create directory-entry\n");
        rc=EFSGEN;
        goto finish;
    }

finish:
    return rc;
}

/* check if spezified block-number (x'th block of this file) is allocated for spezified file */
bool FileBlockExists(struct GOSFS_Instance *p_instance, struct GOSFS_Inode* inode, ulong_t blockNum)
{
    int rc=0;
    struct FS_Buffer* p_buff=0;
    int numIndirectPtr=-1; // 1-based
    int numPtrInIndirect=-1, numPtrIn2Indirect=-1; // 0-based
    int inodePtr=-1; // 0-based
    ulong_t indirectBlock=0;
    ulong_t phyBlock=0, phyIndBlock=0;
    
    // check if block-number is in range
    if (blockNum >= GOSFS_NUM_DIRECT_BLOCKS + (GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK)+(GOSFS_NUM_2X_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK*GOSFS_NUM_PTRS_PER_BLOCK)) 
    {
        rc=0;
        goto finish;
    }
    
    
    // check direct block
    if (blockNum < GOSFS_NUM_DIRECT_BLOCKS)
    {
        if (inode->blockList[blockNum] != 0)
            rc = 1;
            
    }
    // check indirect-block
    else if (blockNum < GOSFS_NUM_DIRECT_BLOCKS + (GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK))
    {
        
        numIndirectPtr = ((((blockNum+1) - (GOSFS_NUM_DIRECT_BLOCKS+1)) / GOSFS_NUM_INDIRECT_PTR_PER_BLOCK)) + 1;
        numPtrInIndirect = ((((blockNum+1) - (GOSFS_NUM_DIRECT_BLOCKS+1)) % GOSFS_NUM_INDIRECT_PTR_PER_BLOCK));
        inodePtr = GOSFS_NUM_DIRECT_BLOCKS + numIndirectPtr -1;
        
        indirectBlock=inode->blockList[inodePtr];
        if (indirectBlock==0)
        {
            rc=0;
            goto finish;
        }
        
        rc = Get_FS_Buffer(p_instance->buffercache,indirectBlock,&p_buff);
        if (rc<0)
        {
            Debug("Unable to get buffer\n");
            rc = 0;
            goto finish;
        }
        
		memcpy(&phyBlock, p_buff->data + (numPtrInIndirect*sizeof(ulong_t)), sizeof(ulong_t));
        
        rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
        p_buff = 0;
        if (rc<0)
        {
            Debug("Unable to release fs_buffer\n");
            rc = 0;
            goto finish;
        }
		

        if (phyBlock>0) rc=1;
    }
	// check 2xindirect-block
	else
	{
		numIndirectPtr = ((((blockNum+1) - (GOSFS_NUM_DIRECT_BLOCKS+(GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK)+1)) / (GOSFS_NUM_INDIRECT_PTR_PER_BLOCK*GOSFS_NUM_INDIRECT_PTR_PER_BLOCK))) + 1;
        numPtrIn2Indirect = ((((blockNum+1) - (GOSFS_NUM_DIRECT_BLOCKS+(GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK)+1)) / (GOSFS_NUM_INDIRECT_PTR_PER_BLOCK)));
		numPtrInIndirect = ((((blockNum+1) - (GOSFS_NUM_DIRECT_BLOCKS+(GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK)+1)) % (GOSFS_NUM_INDIRECT_PTR_PER_BLOCK)));
        inodePtr = GOSFS_NUM_DIRECT_BLOCKS + (GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK) + numIndirectPtr -1;
		
		indirectBlock=inode->blockList[inodePtr];
        if (indirectBlock==0)
        {
            rc=0;
            goto finish;
        }
        
        rc = Get_FS_Buffer(p_instance->buffercache,indirectBlock,&p_buff);
        if (rc<0)
        {
            Debug("Unable to get buffer\n");
            rc = 0;
            goto finish;
        }
        		
		memcpy(&phyIndBlock, p_buff->data + (numPtrIn2Indirect*sizeof(ulong_t)), sizeof(ulong_t));
        
        rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
        p_buff = 0;
        if (rc<0)
        {
            Debug("Unable to release fs_buffer\n");
            rc = 0;
            goto finish;
        }
		
		// block nicht alloziert
		if (phyIndBlock<=0)
		{
			rc=0;
			goto finish;
		}
		
		rc = Get_FS_Buffer(p_instance->buffercache,phyIndBlock,&p_buff);
        if (rc<0)
        {
            Debug("Unable to get buffer\n");
            rc = 0;
            goto finish;
        }
        
        memcpy(&phyBlock, p_buff->data + (numPtrInIndirect*sizeof(ulong_t)), sizeof(ulong_t));
        
        rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
        p_buff = 0;
        if (rc<0)
        {
            Debug("Unable to release fs_buffer\n");
            rc = 0;
            goto finish;
        }
		

        if (phyBlock>0) rc=1;

	}
    
finish:
    if (p_buff!=0) Release_FS_Buffer(p_instance->buffercache, p_buff);
    return rc;    
}

/* create a new inizialized block */
ulong_t GetNewCleanBlock(struct GOSFS_Instance *p_instance)
{
    ulong_t freeBlock;
    int rc=0;
    struct FS_Buffer *p_buff=0;
    
    freeBlock=Find_First_Free_Bit(p_instance->superblock.bitSet, p_instance->superblock.size);
    Debug("found free block %ld\n",freeBlock);
    if (freeBlock<=0)
    {
    Debug("No free Blocks found\n");
        rc=EFSGEN;
        goto finish;
    }
    
    rc = Get_FS_Buffer(p_instance->buffercache,freeBlock,&p_buff);
    if (rc<0)
    {
        Debug("Unable to get buffer\n");
        rc = EFSGEN;
        goto finish;
    }

    // lets "format" block
    memset(p_buff->data,'\0',GOSFS_FS_BLOCK_SIZE);
    
    Modify_FS_Buffer(p_instance->buffercache,p_buff);
/*    
    if (g_gosfs_sync)
    {        
        rc = Sync_FS_Buffer(p_instance->buffercache, p_buff);
        if (rc<0)
        {
            Debug("Unable to sync fs_buffer for new-directory\n");
            rc = EFSGEN;
            goto finish;
        }
    }
*/

    rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
    p_buff = 0;
    if (rc<0)
    {
        Debug("Unable to release fs_buffer\n");
        rc = EFSGEN;
        goto finish;
    }
    
    Set_Bit(p_instance->superblock.bitSet, freeBlock);

finish:
    if (p_buff!=0) Release_FS_Buffer(p_instance->buffercache, p_buff);
    if (rc<0) return rc;
    else return freeBlock;
}


/* write an entry to the indirect block */
int WriteIndirectBlockEntry(struct GOSFS_Instance *p_instance, ulong_t numBlock, ulong_t offset, ulong_t freeBlock)
{
    int rc=0;
    struct FS_Buffer *p_buff=0;
        
    rc = Get_FS_Buffer(p_instance->buffercache,numBlock,&p_buff);
    if (rc<0)
    {
        Debug("Unable to get buffer\n");
        rc = EFSGEN;
        goto finish;
    }

    // lets "format" block
    memcpy(p_buff->data + (offset * sizeof(ulong_t)), &freeBlock, sizeof(ulong_t));
    
    Modify_FS_Buffer(p_instance->buffercache,p_buff);
/*
    if (g_gosfs_sync)
    {
        rc = Sync_FS_Buffer(p_instance->buffercache, p_buff);
        if (rc<0)
        {
            Debug("Unable to sync fs_buffer for new-directory\n");
            rc = EFSGEN;
            goto finish;
        }
    }
*/
    rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
    p_buff = 0;
    if (rc<0)
    {
        Debug("Unable to release fs_buffer\n");
        rc = EFSGEN;
        goto finish;
    }
    
finish:
    if (p_buff!=0) Release_FS_Buffer(p_instance->buffercache, p_buff);
    return rc;
    
}

/* allocate a new block for this file */
int GetPhysicalBlockByLogical(struct GOSFS_Instance* p_instance, struct GOSFS_Inode* inode, ulong_t blockNum)
{
    int rc=0;
    int phyBlock=0, phyIndBlock=0;
    int numIndirectPtr = -1;    // which indirect inode ptr to use (1-based)
    int numPtrInIndirect = -1; // which pointer in the indirct-block (0-based)
	int numPtrIn2Indirect = -1; // which pointer in the 2xindirct-block (0-based)
    int inodePtr = -1;    // which entry in the inode-array are we refering to (0-based)
    int indirectBlock;  // physical block with block-ptrs
    struct FS_Buffer *p_buff=0;
    
    // direct block
    if (blockNum < GOSFS_NUM_DIRECT_BLOCKS)
    {
        phyBlock = inode->blockList[blockNum];
    }
    // indirect-block
    else if (blockNum < GOSFS_NUM_DIRECT_BLOCKS + (GOSFS_NUM_INDIRECT_PTR_PER_BLOCK * GOSFS_NUM_INDIRECT_BLOCKS))
    {
        numIndirectPtr = ((((blockNum+1) - (GOSFS_NUM_DIRECT_BLOCKS+1)) / GOSFS_NUM_INDIRECT_PTR_PER_BLOCK)) + 1;
        numPtrInIndirect = (((blockNum+1) - (GOSFS_NUM_DIRECT_BLOCKS+1)) % GOSFS_NUM_INDIRECT_PTR_PER_BLOCK);
        inodePtr = GOSFS_NUM_DIRECT_BLOCKS + numIndirectPtr -1;
        Debug("GetPhysicalBlockByLogical: blocknum: %ld, numIndirectPtr: %d, numPtrInIndirect: %d, inodePtr: %d\n",blockNum, numIndirectPtr,numPtrInIndirect,inodePtr);
        
        indirectBlock = inode->blockList[inodePtr];
        if (indirectBlock == 0)
        {
            Debug("indirect pointer not initialized\n");
            rc = EFSGEN;
            goto finish;
        }
        
        rc = Get_FS_Buffer(p_instance->buffercache,indirectBlock,&p_buff);
        if (rc<0)
        {
            Debug("Unable to get buffer\n");
            rc = EFSGEN;
            goto finish;
        }
        
        memcpy(&phyBlock, p_buff->data + (numPtrInIndirect*sizeof(ulong_t)), sizeof(ulong_t));

        rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
        p_buff = 0;
        if (rc<0)
        {
            Debug("Unable to release fs_buffer\n");
            rc = EFSGEN;
            goto finish;
        }
    }
	// 2xindirect-block
	else
	{
		numIndirectPtr = ((((blockNum+1) - (GOSFS_NUM_DIRECT_BLOCKS+(GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK)+1)) / (GOSFS_NUM_INDIRECT_PTR_PER_BLOCK*GOSFS_NUM_INDIRECT_PTR_PER_BLOCK))) + 1;
        numPtrIn2Indirect = ((((blockNum+1) - (GOSFS_NUM_DIRECT_BLOCKS+(GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK)+1)) / (GOSFS_NUM_INDIRECT_PTR_PER_BLOCK)));
		numPtrInIndirect = ((((blockNum+1) - (GOSFS_NUM_DIRECT_BLOCKS+(GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK)+1)) % (GOSFS_NUM_INDIRECT_PTR_PER_BLOCK)));
        inodePtr = GOSFS_NUM_DIRECT_BLOCKS + (GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK) + numIndirectPtr -1;
		Debug("GetPhysicalBlockByLogical: blocknum: %ld, numIndirectPtr: %d, numPtrIn2Indirect: %d, numPtrInIndirect: %d, inodePtr: %d\n",blockNum, numIndirectPtr,numPtrIn2Indirect,numPtrInIndirect,inodePtr);
	
        indirectBlock = inode->blockList[inodePtr];
        if (indirectBlock == 0)
        {
            Debug("indirect pointer not initialized\n");
            rc = EFSGEN;
            goto finish;
        }
        
        rc = Get_FS_Buffer(p_instance->buffercache,indirectBlock,&p_buff);
        if (rc<0)
        {
            Debug("Unable to get buffer\n");
            rc = EFSGEN;
            goto finish;
        }
        
        memcpy(&phyIndBlock, p_buff->data + (numPtrIn2Indirect*sizeof(ulong_t)), sizeof(ulong_t));

        rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
        p_buff = 0;
        if (rc<0)
        {
            Debug("Unable to release fs_buffer\n");
            rc = EFSGEN;
            goto finish;
        }
		
		if (phyIndBlock<=0)
		{
			Debug("2xindirect pointer not initialized\n");
            rc = EFSGEN;
            goto finish;

		}
		
        rc = Get_FS_Buffer(p_instance->buffercache,phyIndBlock,&p_buff);
        if (rc<0)
        {
            Debug("Unable to get buffer\n");
            rc = EFSGEN;
            goto finish;
        }
        
        memcpy(&phyBlock, p_buff->data + (numPtrInIndirect*sizeof(ulong_t)), sizeof(ulong_t));

        rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
        p_buff = 0;
        if (rc<0)
        {
            Debug("Unable to release fs_buffer\n");
            rc = EFSGEN;
            goto finish;
        }
		
	}
    
finish:
    if (p_buff!=0) Release_FS_Buffer(p_instance->buffercache, p_buff);
    if (rc<0) return rc;
    else return phyBlock;
}

/* allocate a new block for this file */
int CreateFileBlock(struct GOSFS_Instance* p_instance, struct GOSFS_Inode* inode, ulong_t blockNum)
{
    int rc=0;
    int freeBlock;
    struct FS_Buffer *p_buff=0;
    int numIndirectPtr = -1;    // which indirect inode ptr to use (1-based)
    int numPtrInIndirect = -1; // which pointer in the indirct-block (0-based)
	int numPtrIn2Indirect = -1; // which pointer in the 2xindirct-block (0-based)
    int inodePtr = -1;    // which entry in the inode-array are we refering to (0-based)
    int indirectBlock;  // physical block with block-ptrs
	ulong_t phyIndBlock=-1;
    
    blockNum++; // lets start by 1 here, not 0-based
    
    
    // create block to store data in
    freeBlock=GetNewCleanBlock(p_instance);
    if (freeBlock<=0)
    {
        Debug("No free Blocks found\n");
        rc=EFSGEN;
        goto finish;
    }
    
    
    // lets see what kind of block we need, direct, indect or 2xindirect
    // direct block
    if (blockNum <= GOSFS_NUM_DIRECT_BLOCKS)
    {
        Debug("using direct pointer\n");
        inodePtr = blockNum -1;
        inode->blockList[inodePtr]=freeBlock;
    }
    // indirect block
    else if (blockNum <= (GOSFS_NUM_INDIRECT_PTR_PER_BLOCK * GOSFS_NUM_INDIRECT_BLOCKS )+ GOSFS_NUM_DIRECT_BLOCKS)
    {
        Debug("using indirect pointer\n");
        numIndirectPtr = (((blockNum - (GOSFS_NUM_DIRECT_BLOCKS+1)) / GOSFS_NUM_INDIRECT_PTR_PER_BLOCK)) + 1;
        numPtrInIndirect = (((blockNum - (GOSFS_NUM_DIRECT_BLOCKS+1)) % GOSFS_NUM_INDIRECT_PTR_PER_BLOCK));
        inodePtr = GOSFS_NUM_DIRECT_BLOCKS + numIndirectPtr -1;
        
        // if this is the first use of the indirect block, we need to initialize it
        indirectBlock = inode->blockList[inodePtr];
        if (indirectBlock == 0)
        {
            indirectBlock = GetNewCleanBlock(p_instance);
            if (indirectBlock<=0)
            {
                Debug("No free Blocks found for indirect block\n");
                rc=EFSGEN;
                goto finish;
            }
            Debug("setting inode blocklistindex %d inodePtr to block %d\n",inodePtr,indirectBlock);
            inode->blockList[inodePtr]=    indirectBlock;    
        }
        // write entry to indirect block
        rc = WriteIndirectBlockEntry(p_instance, indirectBlock, numPtrInIndirect, freeBlock);
        if (rc<0)
        {
            Debug("could not write entry to indirect block %d\n",rc);
            rc = EFSGEN;
            goto finish;
        }            
        
    }
	// 2xindirect block
    else if (blockNum <= (GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK*GOSFS_NUM_PTRS_PER_BLOCK) + (GOSFS_NUM_INDIRECT_PTR_PER_BLOCK * GOSFS_NUM_INDIRECT_BLOCKS )+ GOSFS_NUM_DIRECT_BLOCKS)
    {
        Debug("using 2Xindirect pointer\n");
		numIndirectPtr = (((blockNum - (GOSFS_NUM_DIRECT_BLOCKS+(GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK)+1)) / (GOSFS_NUM_INDIRECT_PTR_PER_BLOCK*GOSFS_NUM_INDIRECT_PTR_PER_BLOCK))) + 1;
        numPtrIn2Indirect = (((blockNum - (GOSFS_NUM_DIRECT_BLOCKS+(GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK)+1)) / (GOSFS_NUM_INDIRECT_PTR_PER_BLOCK)));
		numPtrInIndirect = (((blockNum - (GOSFS_NUM_DIRECT_BLOCKS+(GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK)+1)) % (GOSFS_NUM_INDIRECT_PTR_PER_BLOCK)));
        inodePtr = GOSFS_NUM_DIRECT_BLOCKS + (GOSFS_NUM_INDIRECT_BLOCKS*GOSFS_NUM_PTRS_PER_BLOCK) + numIndirectPtr -1;

		// if this is the first use of the indirect block, we need to initialize it
        indirectBlock = inode->blockList[inodePtr];
        if (indirectBlock == 0)
        {
            indirectBlock = GetNewCleanBlock(p_instance);
            if (indirectBlock<=0)
            {
                Debug("No free Blocks found for indirect block\n");
                rc=EFSGEN;
                goto finish;
            }
            Debug("setting inode 2xblocklistindex %d inodePtr to block %d\n",inodePtr,indirectBlock);
            inode->blockList[inodePtr]=    indirectBlock;    
        }
		
		// lets see if ptr in 2xindirct block is allocated
		rc = Get_FS_Buffer(p_instance->buffercache,indirectBlock,&p_buff);
        if (rc<0)
        {
            Debug("Unable to get buffer\n");
            rc = EFSGEN;
            goto finish;
        }
        
        memcpy(&phyIndBlock, p_buff->data + (numPtrIn2Indirect*sizeof(ulong_t)), sizeof(ulong_t));

        rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
        p_buff = 0;
        if (rc<0)
        {
            Debug("Unable to release fs_buffer\n");
            rc = EFSGEN;
            goto finish;
        }

		// block not allocated, allocate it
		if (phyIndBlock<=0)
		{
			phyIndBlock = GetNewCleanBlock(p_instance);
            if (phyIndBlock<=0)
            {
                Debug("No free Blocks found for 2xindirect block\n");
                rc=EFSGEN;
                goto finish;
            }
			// write entry to indirect block
        	rc = WriteIndirectBlockEntry(p_instance, indirectBlock, numPtrIn2Indirect, phyIndBlock);
        	if (rc<0)
        	{
            	Debug("could not write entry to indirect block %d\n",rc);
            	rc = EFSGEN;
            	goto finish;
        	}
			
		}
		
		// write entry to indirect block
        rc = WriteIndirectBlockEntry(p_instance, phyIndBlock, numPtrInIndirect, freeBlock);
        if (rc<0)
        {
           	Debug("could not write entry to indirect block %d\n",rc);
           	rc = EFSGEN;
           	goto finish;
        }
		
		
	}
    else
    {
        Debug("maximum filesize reached\n");
        rc=EMAXSIZE;
        goto finish;
    }
        
    inode->blocks_used++;
    
finish:
    if (p_buff!=0) Release_FS_Buffer(p_instance->buffercache, p_buff);
    return rc;
}


/*
 * Get metadata for given file.
 */
static int GOSFS_FStat(struct File *file, struct VFS_File_Stat *stat)
{
    //TODO("GeekOS filesystem FStat operation");
    int rc=0;
    struct GOSFS_FileEntry* fileEntry = (struct GOSFS_FileEntry*) file->fsData;
    
    Mutex_Lock(&fileEntry->instance->lock);
    
    stat->size = fileEntry->inode->size;
    
    if (fileEntry->inode->flags & GOSFS_INODE_ISDIRECTORY)
        stat->isDirectory = 1;
    else
        stat->isDirectory = 0;
    
    if (fileEntry->inode->flags & GOSFS_INODE_SETUID)
        stat->isSetuid = 1;
    else
        stat->isSetuid = 0;        
    
    memcpy (stat->acls, fileEntry->inode->acl,
            sizeof(struct VFS_ACL_Entry) * VFS_MAX_ACL_ENTRIES);
    
    Mutex_Unlock(&fileEntry->instance->lock);

    return rc;
}

/*
 * Read data from current position in file.
 */
static int GOSFS_Read(struct File *file, void *buf, ulong_t numBytes)
{
    //TODO("GeekOS filesystem read operation");
    int rc=0;
    struct GOSFS_FileEntry* pFileEntry= (struct GOSFS_FileEntry*) file->fsData;
    ulong_t offset = file->filePos;
    ulong_t readTo = (file->filePos+numBytes-1);
    struct FS_Buffer* p_buff=0;
    ulong_t startBlock = offset / GOSFS_FS_BLOCK_SIZE;
    ulong_t endBlock = readTo / GOSFS_FS_BLOCK_SIZE;
    ulong_t i=0;
    ulong_t phyBlock, readFrom=0, readNum=0, bytesRead=0;


    Debug ("GOSFS_Read: about to read from offs=%ld (startblk=%ld) to end=%ld (endblk=%ld)\n",
           offset, startBlock, readTo, endBlock);

    Mutex_Lock(&pFileEntry->instance->lock);
    
    // check if read operation is allowed
    if (!(file->mode & O_READ))
    {
        Debug("trying to read from wirte-only file\n");
        rc=EACCESS;
        goto finish;
    }
    
    /*
    // only direct blocks supported at the moment
    if (endBlock > GOSFS_NUM_DIRECT_BLOCKS)
    {
        Debug("only direct blocks supported at the moment\n");
        rc = EFSGEN;
        goto finish;
        
    }
    */
    Debug ("filepos: %ld, endpos: %ld\n",file->filePos, file->endPos);
    // check if we are at the end of the file
    if (file->filePos >= file->endPos)
    {
        bytesRead=0;
        goto finish;
    }        
    
    
    for (i=startBlock; i<=endBlock; i++)
    {
        //phyBlock = pFileEntry->inode->blockList[i];
        phyBlock = GetPhysicalBlockByLogical(pFileEntry->instance, pFileEntry->inode, i);

        if (phyBlock == 0)
        {
            Debug("block not allocated\n");
            rc = EFSGEN;
            goto finish;
            
        }
        
        // read data
        rc = Get_FS_Buffer(pFileEntry->instance->buffercache,phyBlock,&p_buff);
        if (rc<0)
        {
            Debug("Unable to get buffer\n");
            rc = EFSGEN;
            goto finish;
        }
        
        if (i==startBlock)
            readFrom=offset % GOSFS_FS_BLOCK_SIZE;
        else
            readFrom=0;
        
        readNum = GOSFS_FS_BLOCK_SIZE-readFrom;
        if (bytesRead+readNum > numBytes) readNum = numBytes - bytesRead;
        if (readNum + bytesRead + offset > file->endPos)
            readNum = file->endPos-offset-bytesRead;
        
        Debug ("about to read data from logical block %ld (physical %ld)\n",i,phyBlock);
        Debug ("readFrom=%ld readNum=%ld\n",readFrom,readNum);
        
        memcpy(buf + bytesRead, p_buff->data + readFrom, readNum);
        bytesRead = bytesRead + readNum;

        
        rc = Release_FS_Buffer(pFileEntry->instance->buffercache, p_buff);
        p_buff = 0;
        if (rc<0)
        {
            Debug("Unable to release fs_buffer\n");
            rc = EFSGEN;
            goto finish;
        }
    }
    
    // set correct filepos
    file->filePos=file->filePos+numBytes;
    
finish:
    Debug ("numBytesRead = %ld\n",bytesRead);
    if (p_buff!=0) Release_FS_Buffer(pFileEntry->instance->buffercache, p_buff);
    Mutex_Unlock(&pFileEntry->instance->lock);
    if (rc<0) return rc;
    else return bytesRead;
}

/*
 * Write data to current position in file.
 */
static int GOSFS_Write(struct File *file, void *buf, ulong_t numBytes)
{
    //TODO("GeekOS filesystem write operation");
    int rc=0;
    //ulong_t blocksNeeded = 0;
    ulong_t startBlock = 0;
    ulong_t startBlockOffset = 0;
    ulong_t endBlock = 0;
    ulong_t i = 0;
    struct GOSFS_FileEntry* pFileEntry = file->fsData;
    struct FS_Buffer* p_buff = 0;
    ulong_t phyBlock, writeFrom, writeNum, bytesWritten = 0;
    struct Mutex* lock = &pFileEntry->instance->lock;
    
    Debug("GOSFS_Write: about to write %ld bytes at offset %ld\n", numBytes, file->filePos);
    
    Mutex_Lock(lock);
    
    // check if write operation is allowed
    if (!(file->mode & O_WRITE))
    {
        Debug("trying to write from read-only file\n");
        rc = EACCESS;
        goto finish;
    }
    
    // lets see which and how many block we need to write data to
    //blocksNeeded = ((numBytes -1) / GOSFS_FS_BLOCK_SIZE)+1;
    startBlock = file->filePos / GOSFS_FS_BLOCK_SIZE;
    startBlockOffset = file->filePos % GOSFS_FS_BLOCK_SIZE;
    endBlock = (file->filePos + numBytes) / GOSFS_FS_BLOCK_SIZE;

    Debug("logical blocks %ld - %ld needed\n",startBlock, endBlock);
    
    
    // write data to disk
    for (i=startBlock; i<=endBlock; i++)
    {
        // check block for existence, otherwise allocate block
        if (!FileBlockExists(pFileEntry->instance, pFileEntry->inode, i))
        {
            Debug("block not allocated --> allocate new block\n");
            rc=CreateFileBlock(pFileEntry->instance, pFileEntry->inode, i);
            if (rc<0)
            {
                Debug("received errorcode %d from CreateFileBlock\n",rc);
                goto finish;
            }
        }
        
        //phyBlock = pFileEntry->inode->blockList[i];
        phyBlock = GetPhysicalBlockByLogical(pFileEntry->instance, pFileEntry->inode, i);
        if (phyBlock<=0)
        {
            Debug("block not allocated \n");
            rc = EFSGEN;
            goto finish;
        }
        
        Debug("About to write (logical) blocknumber %ld to physical block %ld\n",i,phyBlock);
        
        // write data
        rc = Get_FS_Buffer(pFileEntry->instance->buffercache,phyBlock,&p_buff);
        if (rc<0)
        {
            Debug("Unable to get buffer\n");
            rc = EFSGEN;
            goto finish;
        }
        
        if (i == startBlock) writeFrom=startBlockOffset;
        else writeFrom = 0;
            
        writeNum = GOSFS_FS_BLOCK_SIZE - writeFrom;
        
        if (writeNum > numBytes-bytesWritten) writeNum=numBytes-bytesWritten;
        Debug("writeFrom=%ld, writeNum=%ld\n",writeFrom, writeNum);
        
        memcpy(p_buff->data+writeFrom, buf+bytesWritten, writeNum);
        bytesWritten = bytesWritten + writeNum;
    
        Modify_FS_Buffer(pFileEntry->instance->buffercache,p_buff);
/*        
        if (g_gosfs_sync)
        {
            rc = Sync_FS_Buffer(pFileEntry->instance->buffercache, p_buff);
            if (rc<0)
            {
                Debug("Unable to sync fs_buffer for new-directory\n");
                rc = EFSGEN;
                goto finish;
            }
        }
*/
        
        rc = Release_FS_Buffer(pFileEntry->instance->buffercache, p_buff);
        p_buff = 0;
        if (rc<0)
        {
            Debug("Unable to release fs_buffer\n");
            rc = EFSGEN;
            goto finish;
        }

    }
    
    // bring inode info and file-descriptor up-to-date
    if (file->filePos + numBytes > pFileEntry->inode->size)
    {
        pFileEntry->inode->size = file->filePos + numBytes;
        file->endPos=pFileEntry->inode->size;
    }
    file->filePos=file->filePos + numBytes;

finish:
    if (p_buff != 0) Release_FS_Buffer(pFileEntry->instance->buffercache, p_buff);
    Mutex_Unlock(lock);
    if (rc < 0) return rc;
    else return bytesWritten;
}

/*
 * Seek to a position in file.
 */
static int GOSFS_Seek(struct File *file, ulong_t pos)
{
    //TODO("GeekOS filesystem seek operation");
    int rc = 0;
    
    file->filePos = pos;

    return rc;
}

/*
 * Close a file.
 */
static int GOSFS_Close(struct File *file)
{
    //TODO("GeekOS filesystem close operation");
    struct GOSFS_FileEntry * pFileEntry = file->fsData;
    struct GOSFS_Instance* p_instance = pFileEntry->instance;

    Debug ("GOSFS_Close: about to close file and freeing data at %p\n", pFileEntry);

    if (!pFileEntry)
        return 0;

    bool iflag = Begin_Int_Atomic();
    --pFileEntry->references;
    End_Int_Atomic(iflag);

    Debug ("GOSFS_Close: pid=%d ref=%d, fda=%p\n",
          g_currentThread->pid, pFileEntry->references, pFileEntry);

    if (pFileEntry->references)
        return 0;
    
    Mutex_Lock (&p_instance->lock);

    Free (pFileEntry);
        
    Mutex_Unlock (&p_instance->lock);

    return 0;
}


/*
 * Clone a file.
 * The clone will access the same underlying file as the
 * original, but read/write/seek operations, etc. will be distinct.
 * Returns 0 if successful, or an error code if unsuccessful.
*/
static int GOSFS_Clone(struct File *file, struct File **pClone)
{
    //TODO("GeekOS filesystem clone operation");
    int rc = 0;
    struct File *clone;
    struct GOSFS_FileEntry* pFileEntry = 0;

    /* Create a duplicate File object. */
    clone = Allocate_File (file->ops, file->filePos, file->endPos, file->fsData,
                           file->mode, file->mountPoint);
    if (clone == 0) {
        rc = ENOMEM;
        goto done;
    }

    *pClone = clone;

    pFileEntry = (struct GOSFS_FileEntry*) file->fsData;
    bool iflag = Begin_Int_Atomic();
    ++pFileEntry->references;
    End_Int_Atomic(iflag);

done:
    Print ("GOSFS_Clone: pid=%d ref=%d, file=%p, clone=%p\n",
           g_currentThread->pid, pFileEntry->references, file, clone);
    return rc;
}


static struct File_Ops s_gosfsFileOps = {
    &GOSFS_FStat,
    &GOSFS_Read,
    &GOSFS_Write,
    &GOSFS_Seek,
    &GOSFS_Close,
    0, /* Read_Entry */
    &GOSFS_Clone,
};

/*
 * Stat operation for an already open directory.
 */
static int GOSFS_FStat_Directory(struct File *dir, struct VFS_File_Stat *stat)
{
    //TODO("GeekOS filesystem FStat directory operation");
    int rc=0;
    struct GOSFS_FileEntry* fileEntry = 0; // (struct GOSFS_FileEntry*) dir->fsData;

    stat->size=dir->endPos;
    stat->isDirectory=1;
    stat->isSetuid=0;
    
    if (!fileEntry)
        Print ("ERROR: GOSFS_FStat_Directory: fsData == NULL!\n");
    else
        memcpy (stat->acls, fileEntry->inode->acl,
                sizeof(struct VFS_ACL_Entry) * VFS_MAX_ACL_ENTRIES);

    return rc;
}

/*
 * Directory Close operation.
 */
static int GOSFS_Close_Directory(struct File *dir)
{
    //TODO("GeekOS filesystem Close directory operation");
    struct GOSFS_Directory *dirEntries = 0;

    if (!dir)  return EINVALID;

    dirEntries = (struct GOSFS_Directory*)dir->fsData;

    if (!dirEntries)  return EINVALID;

    Free(dirEntries);
    //Free(dir);     // file itself is freed else where in vfs

    return 0;
}

/*
 * Read a directory entry from an open directory.
 */
static int GOSFS_Read_Entry(struct File *dir, struct VFS_Dir_Entry *entry)
{
    //TODO("GeekOS filesystem Read_Entry operation");
    int rc=0;
    ulong_t offset = dir->filePos;
    struct GOSFS_Directory *directory;
    struct GOSFS_Inode *inode;
        
    if (dir->filePos >= dir->endPos)
        return VFS_NO_MORE_DIR_ENTRIES;    // we are at the end of the file
    
    directory = ((struct GOSFS_Directory*) dir->fsData)+offset;
    strcpy(entry->name, directory->filename);
    
    inode = &(((struct GOSFS_Instance*)(dir->mountPoint->fsData))->superblock.inodes[directory->inode]);
    entry->stats.size = inode->size;
    
    entry->stats.isDirectory = (inode->flags & GOSFS_INODE_ISDIRECTORY) ? 1 : 0;
    entry->stats.isSetuid    = (inode->flags & GOSFS_INODE_SETUID     ) ? 1 : 0;

    dir->filePos++;    // increase file pos

    memcpy (entry->stats.acls, inode->acl,
            sizeof(struct VFS_ACL_Entry) * VFS_MAX_ACL_ENTRIES);

    return rc;
}

static struct File_Ops s_gosfsDirOps = {
    &GOSFS_FStat_Directory,
    0, /* Read */
    0, /* Write */
//  0, /* Seek */
    &GOSFS_Seek,
    &GOSFS_Close_Directory,
    &GOSFS_Read_Entry,
};

/*
 * Open a file named by given path.
 */
static int GOSFS_Open(struct Mount_Point *mountPoint, const char *path, int mode, struct File **pFile)
{
    //TODO("GeekOS filesystem open operation");
    int rc=0;
    struct GOSFS_Instance *p_instance = (struct GOSFS_Instance*) mountPoint->fsData;
    ulong_t inode;
    struct GOSFS_Inode*    pInode;
    struct GOSFS_FileEntry* pFileEntry=0;
    
    Debug ("GOSFS_Open: path=%s, mode=%d\n",path, mode);
    
    Mutex_Lock(&p_instance->lock);
    
    // check if file already exists
    rc=Find_InodeByName(p_instance, path, &inode);
    if (rc<0)
    {
        Debug ("file not found\n");
        if (!(mode & O_CREATE))
        {
            rc=ENOTFOUND;
            goto finish;
        }
        Debug ("about to create file\n");
        
        rc = CreateFileInode(mountPoint, path, &inode);
        
        if (rc<0)
        {
            Debug ("file could not be created\n");
            rc=EFSGEN;
            goto finish;
        }
    }

    pInode = &p_instance->superblock.inodes[inode];
    // check to see if inode is really a file
    /*
    if (pInode->flags & GOSFS_INODE_ISDIRECTORY)
    {
        Debug("file expected but directory found\n");
        rc=ENOTFILE;
        goto finish;
    }
    */
    
    pFileEntry = Malloc(sizeof(struct GOSFS_FileEntry));
    if (pFileEntry == 0)
    {
        rc = ENOMEM;
        goto finish;
    }
    pFileEntry->inode = pInode;
    pFileEntry->instance = p_instance;
    pFileEntry->references = 1;
    
#if 0
    (*pFile)->ops = &s_gosfsFileOps;
    (*pFile)->filePos = 0;
    (*pFile)->endPos = pInode->size;
    (*pFile)->mode = mode;
    (*pFile)->mountPoint = mountPoint;
    (*pFile)->fsData = pFileEntry;
#endif

    struct File *file = Allocate_File(&s_gosfsFileOps, 0, pInode->size, pFileEntry, mode, mountPoint);
    if (file == 0) {
        rc = ENOMEM;
        goto finish;
    }

    *pFile = file;
    
    Debug ("GOSFS_Open: pid=%d ref=%d, fda=%p\n",
          g_currentThread->pid, pFileEntry->references, pFileEntry);

finish:
    if ((rc<0) && (pFileEntry!=0)) Free(pFileEntry);
    Mutex_Unlock(&p_instance->lock);
    return rc;
}

/*
 * Create a directory named by given path.
 */
static int GOSFS_Create_Directory(struct Mount_Point *mountPoint, const char *path)
{
    //TODO("GeekOS filesystem create directory operation");
    int rc=0,e;
    ulong_t freeBlock;
    struct GOSFS_Directory    dirEntry;
    struct FS_Buffer            *p_buff=0;
    struct GOSFS_Instance        *p_instance;
    ulong_t freeInode, parentInode, tmpInode;
    char*                filename=0;
    char*                parentpath=0;
    
    //removeTrailingSlash((char*)path);
    
    p_instance = (struct GOSFS_Instance*) mountPoint->fsData;    
        
    Debug("about to create directory %s\n",path);
    
    Mutex_Lock(&p_instance->lock);
    
    parentpath=Malloc(strlen(path));
    strncpy(parentpath, path, strrchr(path,'/')-path);
    parentpath[strrchr(path,'/')-path]='\0';
    Debug("searching for inode of parent path %s\n",parentpath);
    
    // search parent directory-inode
    rc=Find_InodeByName(p_instance, parentpath, &parentInode);
    if (rc<0)
    {
        Debug("parent inode not found\n");
        rc=EFSGEN;
        goto finish;
    }

    
    rc=Find_Free_Inode(mountPoint, &freeInode);
    Debug("found free inode %d\n",(int)freeInode);
    if (rc<0)
    {
        Debug("No free Inode found\n");
        rc=-1;
        goto finish;
    }
    
    // strip filename from path including /
    filename=strrchr(path,'/')+1;
    
    // check if directory already exists
    rc=Find_InodeInDirectory(p_instance, filename, parentInode, &tmpInode);
    // directory already exists
    if (rc>=0)
    {
        Debug("Directory already exists.\n");
        rc=EEXIST;
        goto finish;
    }
    
    // write directory entry on parent inode
    dirEntry.type = GOSFS_DIRTYP_REGULAR;
    dirEntry.inode = freeInode;
    strcpy(dirEntry.filename, filename);
    
    rc = AddDirEntry2Inode(p_instance, parentInode, &dirEntry);
    
    freeBlock=Find_First_Free_Bit(p_instance->superblock.bitSet, p_instance->superblock.size);
    Debug("found free block %ld\n",freeBlock);
    if (freeBlock<=0)
    {
        Debug("No free Blocks found\n");
        rc=-2;
        goto finish;
    }
    
    rc = Get_FS_Buffer(p_instance->buffercache,freeBlock,&p_buff);
    if (rc<0)
    {
        Debug("Unable to get buffer for directory\n");
        rc = EFSGEN;
        goto finish;
    }    
    rc = CreateFirstDirectoryBlock(freeInode, 0, p_buff);
    
    if (rc<0)
    {
        Debug("Unable to get buffer for new-directory\n");
        rc = EFSGEN;
        goto finish;
    }
    
    
    Modify_FS_Buffer(p_instance->buffercache,p_buff);
/*    
    if (g_gosfs_sync)
    {
        rc = Sync_FS_Buffer(p_instance->buffercache, p_buff);
        if (rc<0)
        {
            Debug("Unable to sync fs_buffer for new-directory\n");
            rc = EFSGEN;
            goto finish;
        }
    }
*/
    rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
    p_buff = 0;
    if (rc<0)
    {
        Debug("Unable to release fs_buffer for new-directory\n");
        rc = EFSGEN;
        goto finish;
    }
    Set_Bit(p_instance->superblock.bitSet, freeBlock);


    p_instance->superblock.inodes[freeInode].size=2;        // directories start with 2 entries ("." and "..")
    p_instance->superblock.inodes[freeInode].link_count=1;
    p_instance->superblock.inodes[freeInode].blocks_used=1; // new directories will consume 1 Block
    p_instance->superblock.inodes[freeInode].flags=GOSFS_INODE_ISDIRECTORY | GOSFS_INODE_USED;
    memset (p_instance->superblock.inodes[freeInode].acl, '\0', sizeof (struct VFS_ACL_Entry) * VFS_MAX_ACL_ENTRIES);
    p_instance->superblock.inodes[freeInode].acl[0].uid = g_currentThread->userContext ? g_currentThread->userContext->eUId : 0;
    p_instance->superblock.inodes[freeInode].acl[0].permission = O_READ | O_WRITE;
    p_instance->superblock.inodes[freeInode].time_access=0;
    p_instance->superblock.inodes[freeInode].time_modified=0;
    p_instance->superblock.inodes[freeInode].time_inode=0;
    for (e=0; e<GOSFS_NUM_BLOCK_PTRS; e++)
    {
        p_instance->superblock.inodes[freeInode].blockList[e]=0;
    }
    p_instance->superblock.inodes[freeInode].blockList[0]=freeBlock;
    
/*
    rc = WriteSuperblock(p_instance);
    if (rc<0)
    {
        Debug("Unable to wirte changed superblock to disc\n");
        rc = EFSGEN;
        goto finish;
    }
*/    

finish:
    if (parentpath!=0) Free(parentpath);
    Mutex_Unlock(&p_instance->lock);
    return rc;
}

/*
 * Open a directory named by given path.
 */
static int GOSFS_Open_Directory(struct Mount_Point *mountPoint, const char *path, struct File **pDir)
{
    //TODO("GeekOS filesystem open directory operation");
    int rc = 0, i, e;
    ulong_t inodeNum, blockNum, found = 0;
    struct GOSFS_Inode    *inode = 0;
    struct GOSFS_Directory *dirEntries = 0, *tmpDir;
    struct FS_Buffer *p_buff = 0;
    struct GOSFS_Instance* p_instance = (struct GOSFS_Instance*)mountPoint->fsData;
    
    Mutex_Lock(&p_instance->lock);
    
    // spezial treatment for root-directory
    if (strcmp(path,"/") == 0)
    {
        inodeNum=0;
    }
    else
    {
        rc = Find_InodeByName((struct GOSFS_Instance*)mountPoint->fsData, path, &inodeNum);
        if (rc < 0)  goto finish;
    }
        
    inode = &(((struct GOSFS_Instance*)mountPoint->fsData)->superblock.inodes[inodeNum]);
    
    (*pDir)->ops = &s_gosfsDirOps;
    (*pDir)->filePos = 0;
    (*pDir)->endPos = inode->size;
    (*pDir)->mode = O_READ;
    (*pDir)->mountPoint=mountPoint;
    
    dirEntries = Malloc(inode->size * sizeof(struct GOSFS_Directory));
    if (dirEntries == 0)
    {
        rc = ENOMEM;
        goto finish;
    }
    
    // put directory listing in file-data
    for (i=0; i < GOSFS_NUM_DIRECT_BLOCKS; i++)
    {        
        blockNum = inode->blockList[i];
        if (blockNum != 0)
        {
            Debug("found direct block %ld\n",blockNum);
            rc = Get_FS_Buffer(((struct GOSFS_Instance*)mountPoint->fsData)->buffercache,blockNum,&p_buff);
            if (rc < 0)
            {
                Debug("Unable to get buffer for search-directory\n");
                rc = EFSGEN;
                goto finish;
            }
            
            for (e = 0; e < GOSFS_DIR_ENTRIES_PER_BLOCK; e++)
            {
                tmpDir = (struct GOSFS_Directory*)((p_buff->data)+(e*sizeof(struct GOSFS_Directory)));
                if (tmpDir->type != GOSFS_DIRTYP_FREE)
                {
                    Debug("found directory entry %d\n",e);
                    memcpy(dirEntries+found, tmpDir, sizeof(struct GOSFS_Directory));
                    found++;
                }
            }
            
            rc = Release_FS_Buffer(((struct GOSFS_Instance*)mountPoint->fsData)->buffercache, p_buff);
            p_buff = 0;
            if (rc < 0)
            {
                Debug("Unable to release fs_buffer for root-directory\n");
                rc = EFSGEN;
                goto finish;
            }                
        }
    }
    
    if (found != inode->size)
    {
        Debug("Number of Entries found does not match directory-size\n");
        rc=EFSGEN;
        goto finish;
    }
    
    (*pDir)->fsData = dirEntries;
        
    Debug ("GOSFS_Open_Directory: pid=%d fda=%p\n",
          g_currentThread->pid, dirEntries);
    
finish:
    if ((rc < 0) && (dirEntries != 0))  Free(dirEntries);
    if (p_buff != 0)  Release_FS_Buffer(((struct GOSFS_Instance*)mountPoint->fsData)->buffercache, p_buff);
    Mutex_Unlock(&p_instance->lock);
    return rc;
}

/*
 * Delete file or directory named by given path.
 */
static int GOSFS_Delete(struct Mount_Point *mountPoint, const char *path)
{
    //TODO("GeekOS filesystem delete operation");
    int rc=0,i=0;
    ulong_t inodeNum=-1, parentInodeNum=-1, e=0, f=0;
    struct GOSFS_Inode *pInode=0;
    ulong_t blockNum=0, blockIndirect=0, block2Indirect=0;
    struct GOSFS_Instance *p_instance = (struct GOSFS_Instance*)mountPoint->fsData;
    char  *parentPath=0, *offset;
    struct FS_Buffer *p_buff=0;
    
    /*
    for (i=0;i<30;i++)
    {
        char* string=Malloc(100);
        string[0]='/';
        string[1]=65+(i/100);
        string[2]=65+(i/10)-10*(i/100);
        string[3]=65+(i-(i/10)*10);
        string[4]='\0';
        Debug("creating dir(%d) %s\n",i,string);
        GOSFS_Create_Directory(mountPoint, string);
        Free(string);
    }
    return 0;    
    */
    
    Mutex_Lock(&p_instance->lock);
    
    rc = Find_InodeByName(p_instance, path, &inodeNum);
    
    if (rc<0)
    {
        Debug("File or Directory %s not found\n",path);
        rc = ENOTFOUND;
        goto finish;
    }
    
    pInode = &(p_instance->superblock.inodes[inodeNum]);
    
    if (!IsDirectoryEmpty(pInode,p_instance))
    {
        Debug("seems to be non-empty directory\n");
        rc = EDIRNOTEMPTY;
        goto finish;        
    }
    
    // find parent directory
    offset = strrchr(path,'/');    
    parentPath = strdup(path);
    parentPath[offset-path]='\0';
    Debug("parent-path: %s\n",parentPath);
    rc = Find_InodeByName(p_instance, parentPath, &parentInodeNum);
    if (rc<0)
    {
        Debug("Parent Directory %s not found\n",path);
        rc = EFSGEN;
        goto finish;
    }
    
    // free all asigned direct blocks of this inode
    for (i=0; i<GOSFS_NUM_DIRECT_BLOCKS; i++)
    {
        blockNum = pInode->blockList[i];
        if (blockNum != 0)
        {
            Clear_Bit(p_instance->superblock.bitSet, blockNum);
        }
    }
    
    // free indirect-blocks
    for (i=0; i<GOSFS_NUM_INDIRECT_BLOCKS; i++)
    {
        blockNum = pInode->blockList[GOSFS_NUM_DIRECT_BLOCKS+i];
        if (blockNum !=0)
        {
            Debug("found indirect block %ld --> freeing\n",blockNum);
            
            rc = Get_FS_Buffer(p_instance->buffercache,blockNum,&p_buff);
            if (rc<0)
            {
                Debug("Unable to get buffer for search-directory\n");
                rc = EFSGEN;
                goto finish;
            }
            
            
            for (e=0; e<GOSFS_NUM_INDIRECT_PTR_PER_BLOCK; e++)
            {
                memcpy(&blockIndirect, (void*) p_buff->data + (e*sizeof(ulong_t)), sizeof(ulong_t));
                if (blockIndirect!=0)
                {
                    Debug("found block %ld to delete\n",blockIndirect);
                    Clear_Bit(p_instance->superblock.bitSet, blockIndirect);
                    
                }
            }
            
            rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
            p_buff = 0;
            if (rc<0)
            {
                Debug("Unable to release fs_buffer\n");
                rc = EFSGEN;
                goto finish;
            }                
            
            Clear_Bit(p_instance->superblock.bitSet, blockNum);
        }
    }
	
	// free 2Xindirect blocks
	for (i=0;i<GOSFS_NUM_2X_INDIRECT_BLOCKS;i++)
	{
		blockNum = pInode->blockList[GOSFS_NUM_DIRECT_BLOCKS+GOSFS_NUM_INDIRECT_BLOCKS+i];
        if (blockNum !=0)
        {
            Debug("found indirect block %ld --> freeing\n",blockNum);
			
            for (e=0; e<GOSFS_NUM_INDIRECT_PTR_PER_BLOCK; e++)
            {
				rc = Get_FS_Buffer(p_instance->buffercache,blockNum,&p_buff);
            	if (rc<0)
            	{
                	Debug("Unable to get buffer\n");
                	rc = EFSGEN;
                	goto finish;
            	}
			
                memcpy(&block2Indirect, (void*) p_buff->data + (e*sizeof(ulong_t)), sizeof(ulong_t));
				
				rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
            	p_buff = 0;
            	if (rc<0)
            	{
	                Debug("Unable to release fs_buffer\n");
    	            rc = EFSGEN;
        	        goto finish;
            	}                
				
				
                if (block2Indirect!=0)
                {
					for (f=0;f<GOSFS_NUM_INDIRECT_PTR_PER_BLOCK;f++)
					{
						rc = Get_FS_Buffer(p_instance->buffercache,block2Indirect,&p_buff);
						if (rc<0)
						{
							Debug("Unable to get buffer\n");
							rc = EFSGEN;
							goto finish;
						}
					
						memcpy(&blockIndirect, (void*) p_buff->data + (f*sizeof(ulong_t)), sizeof(ulong_t));
						
						rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
						p_buff = 0;
						if (rc<0)
						{
							Debug("Unable to release fs_buffer\n");
							rc = EFSGEN;
							goto finish;
						}       
	
						if (blockIndirect!=0)
						{
							Debug("found blockIndirect %ld to delete\n",blockIndirect);
							Clear_Bit(p_instance->superblock.bitSet, blockIndirect);
						
						}
	
					}			
					
                    Debug("found block2Indirect %ld to delete\n",block2Indirect);
                    Clear_Bit(p_instance->superblock.bitSet, block2Indirect);
                    
                }
            }
            
            
            Clear_Bit(p_instance->superblock.bitSet, blockNum);		
			
		}
		
	}
    
    // remove directory-entry from parent directory
    rc = RemoveDirEntryFromInode(p_instance, parentInodeNum, inodeNum);
    if (rc<0)
    {
        Debug("could not remove directory entry\n");
        rc = EFSGEN;
        goto finish;
    }

    
    // reset inode to defaults
    SetInodeDefaults(pInode);

    //rc = WriteSuperblock(p_instance);
    
finish:
    if (p_buff!=0)  Release_FS_Buffer(((struct GOSFS_Instance*)mountPoint->fsData)->buffercache, p_buff);
    if (parentPath!=0) Free(parentPath);
    Mutex_Unlock(&p_instance->lock);
    return rc;
}

/*
 * Get metadata (size, permissions, etc.) of file named by given path.
 */
static int GOSFS_Stat(struct Mount_Point *mountPoint, const char *path, struct VFS_File_Stat *stat)
{        
    //TODO("GeekOS filesystem stat operation");
    int rc=0;
    ulong_t inode=0;
    struct GOSFS_Instance *p_instance = (struct GOSFS_Instance*)mountPoint->fsData;
    
    
    Debug("GOSFS_Stat for directory %s\n",path);

    Mutex_Lock(&p_instance->lock);    
    
    //removeTrailingSlash((char*)path);
    // special treatment for root-directory
    if (strcmp(path,"/")==0) 
    {
        inode=0;
    }
    else
    {
        rc=Find_InodeByName((struct GOSFS_Instance*)mountPoint->fsData, path, &inode);
        if (rc<0) 
        {
            rc=ENOTFOUND;
            goto finish;
        }
    }
    
    stat->size=((struct GOSFS_Instance*)mountPoint->fsData)->superblock.inodes[inode].size;
    
    if (!(((struct GOSFS_Instance*)mountPoint->fsData)->superblock.inodes[inode].flags & GOSFS_INODE_USED))
    {
        rc = ENOTFOUND;
        goto finish;
    }
    
    if (((struct GOSFS_Instance*)mountPoint->fsData)->superblock.inodes[inode].flags & GOSFS_INODE_ISDIRECTORY)
            stat->isDirectory=1;
    else 
            stat->isDirectory=0;
    
    if (((struct GOSFS_Instance*)mountPoint->fsData)->superblock.inodes[inode].flags & GOSFS_INODE_SETUID)
        stat->isSetuid=1;
    else
        stat->isSetuid=0;

    memcpy (stat->acls, ((struct GOSFS_Instance*)mountPoint->fsData)->superblock.inodes[inode].acl,
            sizeof(struct VFS_ACL_Entry) * VFS_MAX_ACL_ENTRIES);
    
finish:
    Mutex_Unlock(&p_instance->lock);
    return rc;
}


/*
 * Synchronize the filesystem data with the disk
 * (i.e., flush out all buffered filesystem data).
 */
static int GOSFS_Sync(struct Mount_Point *mountPoint)
{
    //TODO("GeekOS filesystem sync operation");
    int rc=0;
    //ulong_t i=0;
    struct GOSFS_Instance *p_instance = (struct GOSFS_Instance *)mountPoint->fsData;
    struct FS_Buffer    *p_buff=0;
        
    Mutex_Lock(&p_instance->lock);
    
    // we always need to write the superblock to disk
    rc = WriteSuperblock(p_instance);
    if (rc<0)
    {
        Debug("count not write superblock to disk\n");
        rc = EFSGEN;
        goto finish;
    }
    
    //if (g_gosfs_sync) goto finish; // data is already in sync
    
    rc=Sync_FS_Buffer_Cache(p_instance->buffercache);
    if (rc<0)
    {
        Debug("Could not sync buffer cache\n");
        rc = EFSGEN;
        goto finish;
    }

    
    /*
    for (i=0; i<p_instance->superblock.size; i++)
    {
        rc = Get_FS_Buffer(p_instance->buffercache, i, &p_buff);
        if (rc<0)
        {
            Debug("Unable to get buffer\n");
            rc = EFSGEN;
            goto finish;
        }
        
        if (p_buff->flags & FS_BUFFER_DIRTY)
        {
            Debug("found dirty block %ld\n",i);
            rc = Sync_FS_Buffer(p_instance->buffercache, p_buff);
            if (rc<0)
            {
                Debug("Unable to sync fs_buffer\n");
                rc = EFSGEN;
                goto finish;
            }
            
        }
        
        rc = Release_FS_Buffer(p_instance->buffercache, p_buff);
        p_buff = 0;
            
        if (rc<0)
        {
            Debug("Unable to release fs_buffer\n");
            rc = EFSGEN;
            goto finish;
        }
    
    }
    */
    
finish:
    if (p_buff!=0)  Release_FS_Buffer(p_instance->buffercache, p_buff);
    Mutex_Unlock(&p_instance->lock);
    return rc;
}

static struct Mount_Point_Ops s_gosfsMountPointOps = {
    &GOSFS_Open,
    &GOSFS_Create_Directory,
    &GOSFS_Open_Directory,
    &GOSFS_Stat,
    &GOSFS_Sync,
    &GOSFS_Delete,
    &GOSFS_SetAcl,
    &GOSFS_SetSetUid,
};

static int GOSFS_Format(struct Block_Device *blockDev)
{
    //TODO("GeekOS filesystem format operation");
    struct FS_Buffer_Cache        *gosfs_cache=0;
    struct FS_Buffer            *p_buff=0;
    struct GOSFS_Superblock        *superblock=0;
    int rc=0;
    uchar_t    *bitset=0;
    ulong_t bcopied=0;
    ulong_t i;
        
    
    int numBlocks = Get_Num_Blocks(blockDev)/GOSFS_SECTORS_PER_FS_BLOCK;
    
    ulong_t byteCountSuperblock = sizeof(struct GOSFS_Superblock) + FIND_NUM_BYTES(numBlocks);
    // how many blocks do we need for the supernode (bitset)
    ulong_t blockCountSuperblock = FindNumBlocks(byteCountSuperblock);
        
    
    if (blockCountSuperblock >= numBlocks)
    {
        Debug("Disk to small for GosFS\n");
        rc=EFSGEN;
        goto finish;
    }
    
    gosfs_cache = Create_FS_Buffer_Cache(blockDev, GOSFS_FS_BLOCK_SIZE);
    
    if (gosfs_cache == 0)
    {
        Debug("Unable to create buffer_cache for format\n");
        rc = EFSGEN;
        goto finish;
    }
    
    Debug("About to create root-directory\n");
    // create root directory entry
    rc = Get_FS_Buffer(gosfs_cache,blockCountSuperblock,&p_buff);
    if (rc<0)
    {
        Debug("Unable to get buffer for root-directory\n");
        rc = EFSGEN;
        goto finish;
    }
    // lets "format" at least the root-directory
    memset(p_buff->data,'\0',GOSFS_FS_BLOCK_SIZE);
    
    Debug("About to create directory entries for root-directory\n");
    
    rc = CreateFirstDirectoryBlock(0,0,p_buff);
    
    Modify_FS_Buffer(gosfs_cache,p_buff);
    
    rc = Sync_FS_Buffer(gosfs_cache, p_buff);
    if (rc<0)
    {
        Debug("Unable to sync fs_buffer for root-directory\n");
        rc = EFSGEN;
        goto finish;
    }
    rc = Release_FS_Buffer(gosfs_cache, p_buff);
    p_buff = 0;
    if (rc<0)
    {
        Debug("Unable to release fs_buffer for root-directory\n");
        rc = EFSGEN;
        goto finish;
    }
    Debug("root-directory created\n");
    
    Debug("About to create superblock (%ld)\n",byteCountSuperblock);
        
    // build superblock
    superblock = Malloc(byteCountSuperblock);
    if (superblock==0)
    {
        Debug("Unable to assign memory for superblock\n");
        rc=EFSGEN;
        goto finish;
    }
    
    superblock->magic = GOSFS_MAGIC;
    superblock->size = numBlocks;
    superblock->supersize = byteCountSuperblock;
    
    for (i=0; i<GOSFS_NUM_INODES; i++)
    {
        superblock->inodes[i].inode=i;
        SetInodeDefaults(&superblock->inodes[i]);
        /*
        superblock->inodes[i].size=0;
        superblock->inodes[i].link_count=0;
        superblock->inodes[i].blocks_used=0;
        superblock->inodes[i].flags=0;
        superblock->inodes[i].time_access=0;
        superblock->inodes[i].time_modified=0;
        superblock->inodes[i].time_inode=0;
        for (e=0; e<GOSFS_NUM_BLOCK_PTRS; e++)
        {
            superblock->inodes[i].blockList[e]=0;
        }
        */
    }
    // inode 0 is our root-directory
    superblock->inodes[0].size=2;                    // directory starts with 2 entries ("." and "..")    
    superblock->inodes[0].blocks_used=1;            // root directory needs 1 block after format
    superblock->inodes[0].link_count=1;
    superblock->inodes[0].flags=GOSFS_INODE_USED | GOSFS_INODE_ISDIRECTORY;
    superblock->inodes[0].time_access=0;
    superblock->inodes[0].time_modified=0;
    superblock->inodes[0].time_inode=0;
    superblock->inodes[0].blockList[0]=blockCountSuperblock;    // this is where the contents of our root-directory is stored
    
    Debug("About to create bitset for superblock\n");
    bitset = Create_Bit_Set(numBlocks);    // one bit per block
    for (i=0; i<blockCountSuperblock; i++)
    {
        Set_Bit(bitset, i);        //super block
    }
    
    Set_Bit(bitset, blockCountSuperblock);            //root directory starts after superblock
    
    //superblock.p_root_dir = blockCountSuperblock;
    Debug("About attach bitset to superblock\n");
    // attach bitset to superblock
    memcpy(superblock->bitSet,bitset, FIND_NUM_BYTES(numBlocks));

    Debug("gosfs-format: blockssize: %d\n",GOSFS_FS_BLOCK_SIZE);
    Debug("gosfs-format: numBlocks: %d\n",numBlocks);
    Debug("gosfs-format: Num SuperBlock-blocks: %ld\n",blockCountSuperblock);
    Debug("About to wirte superblock to disc\n");
    
    // write superblock to disc
    bcopied=0;
    for (i=0; i<blockCountSuperblock; i++)
    {
        rc = Get_FS_Buffer(gosfs_cache, i, &p_buff) ;
        if (rc<0)
        {
            Debug("Unable to get buffer for superblock\n");
            rc = EFSGEN;
            goto finish;
        }
        
        if ((byteCountSuperblock-bcopied) < GOSFS_FS_BLOCK_SIZE)
        {
            memcpy(p_buff->data, ((void*)superblock)+bcopied, byteCountSuperblock-bcopied);
            bcopied = bcopied+(byteCountSuperblock-bcopied);
        }
        else
        {
            memcpy(p_buff->data, ((void*)superblock)+bcopied, GOSFS_FS_BLOCK_SIZE);
            bcopied = bcopied + GOSFS_FS_BLOCK_SIZE;
        }
            Debug("Bytes written %ld\n",bcopied);
        
        Modify_FS_Buffer(gosfs_cache, p_buff);
    
        rc = Sync_FS_Buffer(gosfs_cache, p_buff);
        if (rc<0)
        {
            Debug("Unable to sync fs_buffer\n");
            rc = EFSGEN;
            goto finish;
        }
        rc = Release_FS_Buffer(gosfs_cache, p_buff);
        p_buff = 0;
        if (rc<0)
        {
            Debug("Unable to release fs_buffer\n");
            rc = EFSGEN;
            goto finish;
        }
    }
    
    Debug("superblock written\n");
    
    //memcpy(p_buff->data, &superblock, sizeof(superblock));
    //memcpy(((struct GOSFS_Superblock *)p_buff->data)->bitSet,bitset, FIND_NUM_BYTES(numBlocks));
    
    //BitSet copied, we dont need it any longer
    Destroy_Bit_Set(bitset);
    bitset = 0;
    
    Free(superblock);
    superblock=0;
    
    Debug("gosfs-format: finished successfully on %s\n",blockDev->name);
    Debug("gosfs-format: Filesystemsize: %d MB\n",numBlocks*GOSFS_FS_BLOCK_SIZE/1024/1024);
    
    rc = Destroy_FS_Buffer_Cache(gosfs_cache);
    gosfs_cache = 0;

finish:
    if (superblock!=0) Free(superblock);
    if (p_buff != 0) Release_FS_Buffer(gosfs_cache, p_buff);
    if (gosfs_cache != 0) Destroy_FS_Buffer_Cache(gosfs_cache);
    if (bitset !=0 ) Destroy_Bit_Set(bitset);
    return rc;
}


static int GOSFS_Mount(struct Mount_Point *mountPoint)
{
    //TODO("GeekOS filesystem mount operation");
    struct FS_Buffer_Cache        *gosfs_cache = 0;
    struct FS_Buffer            *p_buff = 0;
    struct GOSFS_Superblock        *superblock = 0;
    struct GOSFS_Instance        *instance;
    ulong_t numBlocks, numBytes,bwritten,i;
    int    rc;
    
    
    mountPoint->ops = &s_gosfsMountPointOps;
    
    gosfs_cache = Create_FS_Buffer_Cache(mountPoint->dev, GOSFS_FS_BLOCK_SIZE);
    
    if (gosfs_cache == 0)
    {
        Debug("Unable to create buffer_cache\n");
        rc = EFSGEN;
        goto finish;
    }
    
    // fetch first block for superblock
    rc = Get_FS_Buffer(gosfs_cache, 0, &p_buff) ;
    if (rc<0)
    {
        Debug("Unable to get buffer for superblock\n");
        rc = EFSGEN;
        goto finish;
    }
    superblock = (struct GOSFS_Superblock*) p_buff->data;

    Debug("found magic:%lx\n",superblock->magic);
    if (superblock->magic!=GOSFS_MAGIC)
    {
        Debug("GOSFS_Mount ERROR: does not seem to be a GOSFS filesystem, try format first\n");
        rc = EFSGEN;
        goto finish;
    }
    Debug("superblock size: %ld Byte\n",superblock->supersize);
    Debug("number of blocks of whole fs %ld bocks\n",superblock->size);

    numBytes = superblock->supersize;
    numBlocks = (numBytes / GOSFS_FS_BLOCK_SIZE)+1;
        Debug("superblock spreads %ld blocks\n",numBlocks);
    /* create filesystem instance */
    int sizeofInstance=sizeof(struct GOSFS_Instance) + FIND_NUM_BYTES(superblock->size);
    Debug("size of instance %d bytes\n",sizeofInstance);
    rc = Release_FS_Buffer(gosfs_cache, p_buff);
    if (rc<0)
    {
        Debug("Unable to release fs_buffer\n");
        rc = EFSGEN;
        goto finish;
    }
    p_buff = 0;
    
    // allocate enough memory, struct + dyn bitset array
    instance = Malloc(sizeofInstance);
    
    if (instance==0)
    {
        Debug("Malloc failed to allocate memory\n");
        rc=ENOMEM;
        goto finish;
    }
    
    // initialize mutex for while fs
    Mutex_Init(&instance->lock);
    
    instance->buffercache = gosfs_cache;
        
    bwritten = 0;
    // superblock spreads among several blocks, so chunk load
    superblock = &(instance->superblock);
    for (i=0; i<numBlocks; i++)
    {
        Debug("fetching block[%ld]\n",i);
        rc = Get_FS_Buffer(gosfs_cache, i, &p_buff) ;
        if (rc<0)
        {
            Debug("Unable to get buffer for superblock[%ld]\n",i);
            rc = EFSGEN;
            goto finish;
        }
        
        if ((numBytes-bwritten)<GOSFS_FS_BLOCK_SIZE)
        {
            memcpy(((void*)superblock)+bwritten, p_buff->data, numBytes-bwritten);
            bwritten=bwritten+(numBytes-bwritten);
        }
        else
        {
            memcpy(((void*)superblock)+bwritten, p_buff->data, GOSFS_FS_BLOCK_SIZE);
            bwritten=bwritten+GOSFS_FS_BLOCK_SIZE;
        }
        
        rc = Release_FS_Buffer(gosfs_cache, p_buff);
        if (rc<0)
        {
            Debug("Unable to release fs_buffer\n");
            rc = EFSGEN;
            goto finish;
        }
        p_buff = 0;
    }
    
    //instance->superblock = *superblock;
#ifdef FS_DEBUG
    Print("magic: %lx\n",instance->superblock.magic);
    Print("superblock size: %ld Byte\n",instance->superblock.supersize);
    Print("number of blocks of whole fs %ld bocks\n",instance->superblock.size);
    Print("looping through inodes and showing used inodes\n");
    for (i=0; i<GOSFS_NUM_INODES; i++)
    {
        if (instance->superblock.inodes[i].flags!=0)
            Print("Inode %ld has type %ld\n",i,instance->superblock.inodes[i].flags);
    }
    Print("looping over BitSet with size (%d) and showing bits set\n",(int)instance->superblock.size);
    for (i=0; i<instance->superblock.size; i++)
    {
        if (Is_Bit_Set(instance->superblock.bitSet,i)) Print("%ld: %x\n",i,Is_Bit_Set(instance->superblock.bitSet,i));
    }
#endif
    //copy bitset to filesystem instance
    //memcpy(instance->superblock.bitSet, superblock->bitSet, FIND_NUM_BYTES(superblock->size));
    
    mountPoint->fsData = instance;
        
    //don't destroy buffer, we want to keep it since fs is mounted
    //rc = Destroy_FS_Buffer_Cache(gosfs_cache);
    //gosfs_cache=0;
    rc = 0;
    
finish:
    //Debug("dirs per block %d\n",GOSFS_DIR_ENTRIES_PER_BLOCK);
    //Debug("num direct blocks %d\n",GOSFS_NUM_DIRECT_BLOCKS);
    //Debug("sum directories %d\n",GOSFS_NUM_DIRECT_BLOCKS*GOSFS_DIR_ENTRIES_PER_BLOCK);
	//Debug("num ptrs per block %d\n",GOSFS_NUM_PTRS_PER_BLOCK);
	//Debug("num block ptrs %d \n",GOSFS_NUM_BLOCK_PTRS);
	//Debug("num indirect ptr per block %d\n",GOSFS_NUM_INDIRECT_PTR_PER_BLOCK);

	//Print("sizeof %d\n",GOSFS_DIR_ENTRIES_PER_BLOCK);
	
    if (p_buff!=0) Release_FS_Buffer(gosfs_cache, p_buff);
    if ((rc<0)&&(gosfs_cache!=0)) Destroy_FS_Buffer_Cache(gosfs_cache);
    
    return rc;
}

static struct Filesystem_Ops s_gosfsFilesystemOps = {
    &GOSFS_Format,
    &GOSFS_Mount,
};

/* ----------------------------------------------------------------------
 * Public functions
 * ---------------------------------------------------------------------- */

void Init_GOSFS(void)
{
    Register_Filesystem("gosfs", &s_gosfsFilesystemOps);
}


int GOSFS_SetAcl(struct Mount_Point *mp, const char *path, int uid, int permissions)
{
    // TODO("GOSFS_SetAcl subroutine.");
    Debug ("GOSFS_SetAcl path=%s, uid=%d, perm=%x\n", path, uid, permissions);

    int rc = 0;
    ulong_t inode=0;
    struct GOSFS_Instance *p_instance = (struct GOSFS_Instance*)mp->fsData;

    Mutex_Lock(&p_instance->lock);

    if (strcmp(path,"/")==0)
        inode=0;
    else {
        rc = Find_InodeByName((struct GOSFS_Instance*)mp->fsData, path, &inode);
        if (rc < 0) {
            rc = ENOTFOUND;
            goto finish;
        }
    }

    struct GOSFS_Inode *n = ((struct GOSFS_Instance*)mp->fsData)->superblock.inodes;

    if (! (n[inode].flags & GOSFS_INODE_USED) ) {
        rc = ENOTFOUND;
        goto finish;
    }

    struct VFS_ACL_Entry *acl = n[inode].acl;

    int eUId = 0;
    /* if we have a user context attached, we take the effective user id from there */
    if (g_currentThread->userContext)
        eUId = g_currentThread->userContext->eUId;

    /* first we check if we are owner of this file or directory */
    if (eUId && acl[0].uid != eUId) {
        rc = EACCESS;
        goto finish;
    }

    /* if we are superuser and we own the file give the file to uid */
    if (!eUId && !acl[0].uid) {
        acl[0].uid = uid;
        acl[0].permission = permissions;
        goto finish;
    }

    /* we look for the uid in the ACL entries to adjust the permissions */
    int i;
    for (i=0; i < VFS_MAX_ACL_ENTRIES; i++) {
        if (acl[i].uid == uid) {
            acl[i].permission = permissions;
            if (!permissions)
                acl[i].uid = 0;
            rc = 0;
            goto finish;
        }
    }

    /* we didn't find a entry with user id uid, so we try to create a new one */
    bool found = false;
    rc = 0;
    for (i=0; i < VFS_MAX_ACL_ENTRIES; i++) {
        if (!acl[i].permission) {
            acl[i].uid = uid;
            acl[i].permission = permissions;
            found = true;
            break;
        }
    }

    if (!found)
        rc = EACLMAXENTRIES;

finish:
    Mutex_Unlock(&p_instance->lock);
    return rc;
}


int GOSFS_SetSetUid(struct Mount_Point *mp, const char *path, int setUid)
{
    // TODO("GOSFS_SetSetUid subroutine.");
    Debug ("GOSFS_SetSetUid path=%s, suid=%s\n", path, setUid ? "set" : "clear");

    int rc = 0;
    ulong_t inode=0;
    struct GOSFS_Instance *p_instance = (struct GOSFS_Instance*)mp->fsData;

    Mutex_Lock(&p_instance->lock);

    if (strcmp(path,"/")==0)
        inode=0;
    else {
        rc = Find_InodeByName((struct GOSFS_Instance*)mp->fsData, path, &inode);
        if (rc < 0) {
            rc = ENOTFOUND;
            goto finish;
        }
    }

    struct GOSFS_Inode *n = ((struct GOSFS_Instance*)mp->fsData)->superblock.inodes;

    if (! (n[inode].flags & GOSFS_INODE_USED) ) {
        rc = ENOTFOUND;
        goto finish;
    }

    struct VFS_ACL_Entry *acl = n[inode].acl;

    int eUId = 0;
    /* if we have a user context attached, we take the effective user id from there */
    if (g_currentThread->userContext)
        eUId = g_currentThread->userContext->eUId;

    /* first we check if we are owner of this file or directory */
    if (eUId && acl[0].uid != eUId) {
        rc = EACCESS;
        goto finish;
    }

    if (setUid)  n[inode].flags |=  GOSFS_INODE_SETUID;
    else         n[inode].flags &= ~GOSFS_INODE_SETUID;

    rc = 0;

finish:
    Mutex_Unlock(&p_instance->lock);
    return rc;
}
