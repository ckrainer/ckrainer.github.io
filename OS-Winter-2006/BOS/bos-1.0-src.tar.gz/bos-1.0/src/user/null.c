/*
 * A test program for GeekOS user mode
 */

#include <process.h>

int main(int argc, char** argv)
{
  Null();

  for(;;);

  return 0;
}
