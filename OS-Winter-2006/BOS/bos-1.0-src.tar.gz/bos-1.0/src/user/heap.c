/*
 * A test program for GeekOS user mode heap
 */

#include <conio.h>
#include <malloc.h>

#define ALLOC_SIZE	1024
#define MAX_ALLOC	100

int main(int argc, char** argv)
{
    int i;
    int *b[MAX_ALLOC];
    int *z;

    Print_String("I am the heap testing program\n");
    for (i = 0; i < MAX_ALLOC; ++i) {
        b[i] = Malloc (ALLOC_SIZE);
	Print("Allocate %4d, %d Bytes, result %p\n", i, ALLOC_SIZE, b[i]);
        if (!b[i])  break;
        for (z = b[i]; (z-b[i]) < (ALLOC_SIZE/sizeof(int)); z++)
             *z = (z-b[i])+i;
    }

    int err = 0;

    for (i = 0; i < MAX_ALLOC; ++i) {
	Print("Free     %4d, %d Bytes at %p\n", i, ALLOC_SIZE, b[i]);
        if (!b[i])  break;
        for (z = b[i]; (z-b[i]) < (ALLOC_SIZE/sizeof(int)); z++) {
            if (*z != (z-b[i])+i) {
                Print ("Heap Error: i=%d, p=%p, o=%d, *z=%d != i=%d\n", i, z, z-b[i], *z, i);
                err++;
            }
        }
        Free (b[i]);
    }

    if (err)
        Print ("%d errors detected in heap memory.\n", err);
    else
        Print ("No errors detected in heap memory.\n");

    return err != 0;
}
