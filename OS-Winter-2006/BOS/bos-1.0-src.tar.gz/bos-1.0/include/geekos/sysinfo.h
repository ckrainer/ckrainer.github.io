/*
 * System Information
 * Copyright (c) 2007, Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 * Copyright (c) 2007, Bernhard Danninger <bid-soft@gmx.at>
 * 
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#ifndef GEEKOS_SYSINFO_H
#define GEEKOS_SYSINFO_H

int PrintSystemInfo(int);

#endif  /* GEEKOS_SYSINFO_H */
