/**
 * \file string.c
 * \brief CKPM C library implementation of string functions.
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/


#include <string.h>
#include <stdlib.h>

/**
 * \brief Copy a string. See also strcpy(3).
 * \param dest destination array
 * \param src source string
 * \return a pointer to the destination string dest
 *****************************************************************************/

char*
strcpy(char *dest, const char *src) {
   char *d; d = dest;
// while ( (*d++ = *src++) )  continue;
   while ( (*d = *src) ) { d=d+1;  src=src+1; }
   return dest;
}


/**
 * \brief Copy a string. See also strncpy(3).
 * \param dest destination array
 * \param src source string
 * \param n maximal length of copying
 * \return a pointer to the destination string dest
 *****************************************************************************/

char*
strncpy(char *dest, const char *src, size_t n) {
   char *d;
   char *e;
   d = dest;
   e = d + n;
//   if (!dest || !src || !n)  return 0;
// while (d < e && (*d++ = *src++))  continue;
   while (d < e && (*d = *src))  { d=d+1; src=src+1; }
   while (d < e)  { *d = '\0'; d=d+1; }
   d=d-1;
   *d = '\0';
   return dest;
}


/**
 * \brief Concatenate two strings. See also strcat(3).
 * \param dest destination array
 * \param src source string
 * \return a pointer to the destination string dest
 *****************************************************************************/

char*
strcat(char *dest, const char *src) {
   char *d;
   d = dest;
   while (*d) d = d + 1;
// while ( (*d++ = *src++) ) continue;
   while ( (*d = *src) ) { d=d+1; src=src+1; }
   return dest;
}


/**
 * \brief Concatenate two strings. See also strncat(3).
 * \param dest destination array
 * \param src source string
 * \param n maximal length of concatination
 * \return a pointer to the destination string dest
 *****************************************************************************/

char*
strncat(char *dest, const char *src, size_t n) {
   char *d; d = dest;
// while (*d)  d++;
   while (*d)  d = d + 1;
// while (n-- &&  (*d++ = *src++))  continue;
   while (n &&  (*d = *src))  { n=n-1;  d=d+1;  src=src+1; }
   *d = '\0'; /* necessary ? */
   return dest;
}


/**
 * \brief Compare two strings. See also strcmp(3).
 * \param s1 first string
 * \param s2 second string
 * \return 0 if s1 == s2, > 0 if s1 > s1 or < 0 if s1 < s2
 *****************************************************************************/

int
strcmp(const char *s1, const char *s2) {
// while (*s1 && *s2 && *s1++ == *s2++) continue;
   while (*s1 && *s2 && *s1 == *s2) { s1=s1+1; s2=s2+1; }
   return (int)(*s1 - *s2);
}


/**
 * \brief Compare two strings. See also strncmp(3).
 * \param s1 first string
 * \param s2 second string
 * \param n maximal length of comparison
 * \return 0 if s1 == s2, > 0 if s1 > s1 or < 0 if s1 < s2
 *****************************************************************************/

int
strncmp(const char *s1, const char *s2, size_t n) {
// while (n-- && *s1 && *s2 && *s1++ == *s2++) continue;
   while (n && *s1 && *s2 && *s1 == *s2) { n=n-1; s1=s1+1; s2=s2+1; }
   return (int)(*s1 - *s2);
}


/**
 * \brief Calculate the length of a string
 * \param s a string
 * \return the number of characters in s
 *****************************************************************************/

size_t
strlen(const char *s) {
   int k;
   k = 0;
   while (*s) { k = k + 1; s = s + 1; }
   return k;
}


/**
 * \brief Duplicate a string
 * \param s a string
 * \return the duplicated  string
 *****************************************************************************/

char*
strdup(const char *s) {
   char* n;
   n = (char*) malloc (strlen (s)+1);
   return strcpy (n, s);
}

