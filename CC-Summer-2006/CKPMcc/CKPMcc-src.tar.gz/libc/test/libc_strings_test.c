/**
 * \file libc_strings_test.c
 * \brief CKPM C library strings function tester
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <stdio.h>
//include <stdlib.h>
//include <string.h>
#include <strings.h>

#include "libc_test.h"
//include "../include/strings.h"


/**
 * \brief test the C library strings functions
 * \return 0 if successful, 1 otherwise
 *****************************************************************************/

int
cpp_strings_test () {
    int ok = 0;
    int fail = 0;

    char *s = "You should have received a copy of the GNU General Public License";

    CHK_RESULT ("index ( 1)", (int)index (s, 'Y'), (int)(s+0) );
    CHK_RESULT ("index ( 2)", (int)index (s, 'o'), (int)(s+1) );
    CHK_RESULT ("index ( 3)", (int)index (s, 'u'), (int)(s+2) );
    CHK_RESULT ("index ( 4)", (int)index (s, ' '), (int)(s+3) );
    CHK_RESULT ("index ( 5)", (int)index (s, 'Z'), (int)0);

    printf ("%d subtests total, %d ok, %d failed\n", ok+fail, ok, fail);
    return fail;
}
