/**
 * \file libc_string_test.c
 * \brief CKPM C library string functions tester
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
//include <string.h>

#include "libc_test.h"
#include "../include/string.h"


/**
 * \brief test the C library string functions
 * \return 0 if successful, 1 otherwise
 *****************************************************************************/

int
cpp_string_test () {
    int ok = 0;
    int fail = 0;
    char buf[1024];
    char *r;
    int rc;


    /* strcmp tests */
    rc = strcmp ("You should have received a copy of the GNU ...",
                 "You should have received a copy of the GNU ...");
    CHK_RESULT     ("strcmp ( 1)", rc, 0);

    rc = strcmp ("You should have received a copy of the GNU ...",
                 "You ");
    CHK_RESULT     ("strcmp ( 2)", (rc > 0), 1);

    rc = strcmp ("You ",
                 "You should have received a copy of the GNU ...");
    CHK_RESULT     ("strcmp ( 3)", (rc < 0), 1);


    /* strncmp tests */
    rc = strncmp ("You should have received a copy of the GNU ...",
                  "You should have received a copy of the GNU ...", 10);
    CHK_RESULT     ("strncmp ( 1)", rc, 0);

    rc = strncmp ("You should have received a copy of the GNU ...",
                  "You ", 10);
    CHK_RESULT     ("strncmp ( 2)", (rc > 0), 1);

    rc = strncmp ("You ",
                  "You should have received a copy of the GNU ...", 10);
    CHK_RESULT     ("strncmp ( 3)", (rc < 0), 1);

    rc = strncmp ("You ", "You ", 4);
    CHK_RESULT     ("strncmp ( 4)", rc, 0);
    rc = strncmp ("You ", "You ", 3);
    CHK_RESULT     ("strncmp ( 5)", rc, 0);
    rc = strncmp ("You ", "You ", 2);
    CHK_RESULT     ("strncmp ( 6)", rc, 0);
    rc = strncmp ("You ", "You ", 1);
    CHK_RESULT     ("strncmp ( 7)", rc, 0);

    rc = strncmp ("you ", "You ", 4);
    CHK_RESULT     ("strncmp ( 8)", rc > 0, 1);
    rc = strncmp ("you ", "You ", 3);
    CHK_RESULT     ("strncmp ( 9)", rc > 0, 1);
    rc = strncmp ("you ", "You ", 2);
    CHK_RESULT     ("strncmp (10)", rc > 0, 1);
    rc = strncmp ("you ", "You ", 1);
    CHK_RESULT     ("strncmp (11)", rc > 0, 1);

    rc = strncmp ("You ", "you ", 4);
    CHK_RESULT     ("strncmp (12)", rc < 0, 1);
    rc = strncmp ("You ", "you ", 3);
    CHK_RESULT     ("strncmp (13)", rc < 0, 1);
    rc = strncmp ("You ", "you ", 2);
    CHK_RESULT     ("strncmp (14)", rc < 0, 1);
    rc = strncmp ("You ", "you ", 1);
    CHK_RESULT     ("strncmp (15)", rc < 0, 1);

    /* strcpy tests */
    r = strcpy (buf, "You should have ...");
    CHK_RESULT     ("strcpy ( 1)", (r != 0), 1);
    CHK_RESULT_STR ("strcpy ( 2)", r,   buf);
    CHK_RESULT_STR ("strcpy ( 3)", r,   "You should have ...");
    CHK_RESULT_STR ("strcpy ( 4)", buf, "You should have ...");


    /* strncpy tests */
    r = strncpy (buf, "You might want to have ...",1024);
    CHK_RESULT_STR ("strncpy ( 1)", r,   buf);
    CHK_RESULT_STR ("strncpy ( 2)", r,   "You might want to have ...");
    CHK_RESULT_STR ("strncpy ( 3)", buf, "You might want to have ...");

    r = strncpy (buf, "You might want to have ...",1024);
    r = strncpy (buf, "You should have seen ...",10);
    CHK_RESULT_STR ("strncpy ( 4)", r,   buf);
    CHK_RESULT_STR ("strncpy ( 5)", &r[10], "want to have ...");
    r[10] = '\0';
    CHK_RESULT_STR ("strncpy ( 6)", r,   "You should");
    CHK_RESULT_STR ("strncpy ( 7)", buf, "You should");


    /* strcat tests */
    buf[0] = '\0';
    r = strcat (buf, "You ");
    CHK_RESULT_STR ("strcat ( 1)", r, buf);
    CHK_RESULT_STR ("strcat ( 2)", r,   "You ");
    CHK_RESULT_STR ("strcat ( 3)", buf, "You ");

    r = strcat (buf, "should have ");
    CHK_RESULT_STR ("strcat ( 4)", r, buf);
    CHK_RESULT_STR ("strcat ( 5)", r,   "You should have ");
    CHK_RESULT_STR ("strcat ( 6)", buf, "You should have ");


    /* strncat tests */
    buf[0] = '\0';
    r = strncat (buf, "You  ", 4);
    CHK_RESULT_STR ("strncat ( 1)", r, buf);
    CHK_RESULT_STR ("strncat ( 2)", r,   "You ");
    CHK_RESULT_STR ("strncat ( 3)", buf, "You ");

    r = strncat (buf, "should have  ", 12);
    CHK_RESULT_STR ("strncat ( 4)", r, buf);
    CHK_RESULT_STR ("strncat ( 5)", r,   "You should have ");
    CHK_RESULT_STR ("strncat ( 6)", buf, "You should have ");


    printf ("%d subtests total, %d ok, %d failed\n", ok+fail, ok, fail);
    return fail;
}
