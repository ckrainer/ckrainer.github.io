#!/bin/sh
#
# @(#) libc_test.sh - run the C library test scripts.
#

LIBC_TEST=${LIBC_TEST-./libc_test}
TMP=/tmp/libc_test.$$;

trap "rm -f $TMP;" 0 1 2 15

die () { echo "$*"; exit 1; }

[ "$*" != "" ] && die "Usage: $(basename $0)";

rc=0;
{
   $LIBC_TEST
} | awk '
      {print;}
      /subtests total/ { t=t+$1; o=o+$4; e=e+$6; u=u+$8; }
      END {
            printf("\nSummary:  %d tests total, %d ok, %d errors, %d unexpected lines\n",t,o,e,u);
            exit (e+u?1:0);
      }' || rc=1;


[ "$rc" -eq 0 ] \
   && echo "All tests succeeded." \
   || echo "Tests failed, see above for details.";

exit $rc;
