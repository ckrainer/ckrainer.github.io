#ifndef _CKPMCC_FCNTL_H_
#define _CKPMCC_FCNTL_H_

#define	O_RDONLY	00
#define	O_WRONLY	01
#define	O_CREAT		0100
#define	O_TRUNC		01000

#define	mode_t		int


#if 0
extern "builtin" {
   int open (const char *pathname, int flags, mode_t mode);
}
#endif


#endif /* _CKPMCC_FCNTL_H_ */
