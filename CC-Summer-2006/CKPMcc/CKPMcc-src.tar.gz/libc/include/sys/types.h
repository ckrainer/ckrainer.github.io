#ifndef _CKPMCC_SYS_TYPES_H_
#define _CKPMCC_SYS_TYPES_H_

#define	size_t	int
#define	ssize_t	int

#endif /* _SYS_TYPES_H_ */
