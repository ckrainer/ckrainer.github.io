#ifndef _CKPMCC_STRINGS_H_
#define _CKPMCC_STRINGS_H_

char* index(const char *s, int c);

#endif /* _CKPMCC_STRINGS_H_ */

