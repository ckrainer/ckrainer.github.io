#ifndef _CKPMCC_STDLIB_H_
#define _CKPMCC_STDLIB_H_

#include <sys/types.h>

#if 0
extern "builtin" {
   void *malloc(size_t size);
   void free(void *ptr);
}
#endif

#endif /* _CKPMCC_STDLIB_H_ */
