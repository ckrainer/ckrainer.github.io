#ifndef _CKPMCC_STRING_H_
#define _CKPMCC_STRING_H_

#include <sys/types.h>

char *strcpy(char *dest, const char *src);
char *strncpy(char *dest, const char *src, size_t n);
char *strcat(char *dest, const char *src);
char *strncat(char *dest, const char *src, size_t n);
int strcmp(const char *s1, const char *s2);
int strncmp(const char *s1, const char *s2, size_t n);
size_t strlen(const char *s);
char *strdup(const char *s);

#endif /* _CKPMCC_STRING_H_ */

