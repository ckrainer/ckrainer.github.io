/**
 * \file cpp_macros.c
 * \brief CKPM C pre-processor macro table
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifdef DEBUG
#include <unistd.h>
#endif
#include <stdlib.h>
#include <string.h>

#include "cpp_io.h"
#include "cpp_macros.h"


/**
 * \brief create and initialize a new macro list
 * \return the macro list
 *****************************************************************************/

struct _macro_list* ML_Create () {
   struct _macro_list* l;
   l = (struct _macro_list*) malloc (sizeof(struct _macro_list));
   l->len = 0;
   return l;
}


/**
 * \brief destroy the macro list
 * \param l the macro list
 *****************************************************************************/
void
ML_Destroy (struct _macro_list* l) {
   int i; i=0;
   while (i < l->len) {
      free ((void*)l->m[i].id);
      free ((void*)l->m[i].val);
      i = i + 1;
   }
   free ((void*)l);
#ifdef DEBUG
   put_string (STDERR_FILENO, "ML_Destroy:\n");
#endif
}


/**
 * \brief dump the macro list
 * \param fd the filedesciptor index of the output file
 * \param l the macro list
 * \return index of the found macro on success, otherwise -1
 *****************************************************************************/
void
ML_Dump (int fd, struct _macro_list* l) {
   int i; i=0;
   put_string (fd, "\nDefined macros list, length=");
   put_int (fd, l->len);
   put_string (fd, "\n");
   while (i < l->len) {
      put_string (fd, l->m[i].id);
      put_string (fd, " = ");
      put_string (fd, l->m[i].val);
      put_string (fd, "\n");
      i = i + 1;
   }
}


/**
 * \brief add an entry to the macro list
 * \param l the macro list
 * \param id the requested macro identification
 * \param val the macro value
 * \return new lenght of the macro list on success, otherwise -1 
 *****************************************************************************/
int
ML_Add (struct _macro_list* l, char *id, char *val) {
   if ( ML_Get (l,id) )
      return -1;
   l->m[l->len].id = strdup(id);
   l->m[l->len].val = strdup(val);
   l->len = l->len + 1;
#ifdef DEBUG
   put_string (STDERR_FILENO, "ML_Add: '");
   put_string (STDERR_FILENO, id);
   put_string (STDERR_FILENO, "' defined as '");
   put_string (STDERR_FILENO, val);
   put_string (STDERR_FILENO, "'\n");

   put_string (STDERR_FILENO, "ML_Add2: '");
   put_string (STDERR_FILENO, l->m[l->len].id);
   put_string (STDERR_FILENO, "' defined as '");
   put_string (STDERR_FILENO, l->m[l->len].val);
   put_string (STDERR_FILENO, "'\n");
#endif
   return l->len;
}


/**
 * \brief remove an entry from the macro list
 * \param l the macro list
 * \param id the requested macro identification
 * \return new lenght of the macro list on success, otherwise -1 
 *****************************************************************************/
int
ML_Remove (struct _macro_list* l, char *id) {
   int i;
#ifdef DEBUG
   put_string (STDERR_FILENO, "ML_Remove: '");
   put_string (STDERR_FILENO, id);
   put_string (STDERR_FILENO, "'\n");
#endif

   i = ML_Index (l,id);
   if (i < 0 || l->len == 0)
      return -1;
   free ((void*)l->m[i].id);
   free ((void*)l->m[i].val);
   l->len = l->len - 1;
   l->m[i].id = l->m[l->len].id;
   l->m[i].val = l->m[l->len].val;
   return l->len;
}


/**
 * \brief get an entry from the macro list
 * \param l the macro list
 * \param id the requested macro identification
 * \return value of the found macro on success, otherwise NULL
 *****************************************************************************/
char*
ML_Get (struct _macro_list* l, char *id) {
   char *s;
   int i;

   s = (char*)0;
   i=0;
   while (i < l->len) {
      if (!strcmp (l->m[i].id, id))
         s = l->m[i].val;
      i = i + 1;
   }

#ifdef DEBUG
   put_string (STDERR_FILENO, "ML_Get: '");
   put_string (STDERR_FILENO, id);
   if (s) {
      put_string (STDERR_FILENO, "' => '");
      put_string (STDERR_FILENO, s);
      put_string (STDERR_FILENO, "'\n");
   } else {
      put_string (STDERR_FILENO, "' not found\n");
   }
#endif

   return s;
}


/**
 * \brief get an entry index from the macro list
 * \param l the macro list
 * \param id the requested macro identification
 * \return index of the found macro on success, otherwise -1
 *****************************************************************************/
int
ML_Index (struct _macro_list* l, char *id) {
   int i;
#ifdef DEBUG
   put_string (STDERR_FILENO, "ML_Index:\n");
#endif

   i=0;
   while (i < l->len) {
      if (!strcmp (l->m[i].id, id))
         return i;
      i = i + 1;
   }
   return -1;
}

