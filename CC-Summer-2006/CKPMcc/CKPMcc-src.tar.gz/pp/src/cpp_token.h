/**
 * \file cpp_token.h
 * \brief CKPM C pre-processor token definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef	_CKPM_CPP_TOKEN_H_
#define	_CKPM_CPP_TOKEN_H_

#define IDENT_MAX_LEN   65536


/**
 * \struct _token
 * \brief This structure describes a scanner token 
 */
struct _token {
   int     stat;			/*!< status from read(2) */
   int     sym;				/*!< scanned symbol */
   int     line;			/*!< line number */
   int     num;				/*!< converted number for numeric constants */
   char   *file;			/*!< current file name */
   char    ch;				/*!< scanned character */
   char    id[IDENT_MAX_LEN];		/*!< scanned identifier */
};


/*
 * forward declarations
 */
struct _token* Token_Create (char *file_name);
void Token_Destroy (struct _token* t);
struct _token* Token_Clone (struct _token* t);
int Token_Equals (struct _token* t1, struct _token* t2);


#endif /* _CKPM_CPP_TOKEN_H_ */

