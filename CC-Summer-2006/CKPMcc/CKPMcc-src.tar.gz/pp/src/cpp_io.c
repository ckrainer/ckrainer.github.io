/**
 * \file cpp_io.c
 * \brief CKPM C pre-processor I/O functions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/


#include <unistd.h>
#include <string.h>

#include "cpp_io.h"
#include "cpp_conv.h"
#include "cpp_scan.h"

/**
 * \brief write a string to an open file:
 * \param fd an already opened file to write to
 * \param s the string to be written
 * \return the response code from write(2)
 *****************************************************************************/

int
put_string (int fd, char* s) {
// if (!s || !*s)  return 0;
   return write (fd, (void*)s, strlen(s));
}


/**
 * \brief write an integer value as a string to an open file:
 * \param fd an already opened file to write to
 * \param i the integer value to be written
 * \return the response code from write(2)
 *****************************************************************************/

int
put_int (int fd, int i) {
   char buf[100];
   return put_string (fd, int_to_str (buf, 100, 10, i));
}


/**
 * \brief write a single character to an open file:
 * \param fd an already opened file to write to
 * \param c the character to be written
 * \return the response code from write(2)
 *****************************************************************************/

int
put_char (int fd, char c) {
   return write (fd, (void*)&c, 1);
}


/**
 * \brief write two strings and a newline to an open file
 * \param fd an already opened file to write to
 * \param s1 the first string to be written
 * \param s2 the second string to be written
 * \return the response code from write(2)
 *****************************************************************************/

int
put_two_string_nl (int fd, char* s1, char* s2) {
   put_string (fd, s1);
   put_string (fd, s2);
   return put_string (fd, "\n");
}


/**
 * \brief write three strings and a newline to an open file
 * \param fd an already opened file to write to
 * \param s1 the first string to be written
 * \param s2 the second string to be written
 * \param s3 the third string to be written
 * \return the response code from write(2)
 *****************************************************************************/

int
put_three_string_nl (int fd, char* s1, char* s2, char* s3) {
   put_string (fd, s1);
   return put_two_string_nl (fd, s2, s3);
}

