/**
 * \file cpp_io.h
 * \brief CKPM C pre-processor I/O definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef	_CKPM_CPP_IO_H_
#define	_CKPM_CPP_IO_H_

/*
 * forward declarations
 */
int put_string (int fd, char* s);
int put_int (int fd, int i);
int put_char (int fd, char c);
int put_two_string_nl (int fd, char* s1, char* s2);
int put_three_string_nl (int fd, char* s1, char* s2, char* s3);

#endif /* _CKPM_CPP_IO_H_ */

