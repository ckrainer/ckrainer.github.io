/**
 * \file cpp_run.c
 * \brief CKPM C pre-processor
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/


#include <unistd.h>
#include <fcntl.h>
#include <string.h>

#include "cpp.h"
#include "cpp_io.h"
#include "cpp_run.h"
#include "cpp_parse.h"

/**
 * \brief print error and pass through the return value
 * \param s the input string for perror()
 * \param rc the value to be returned
 * \return returns the handed over value of input parameter rc
 */
int
pr_error (char *s, int rc) {
   put_two_string_nl (STDERR_FILENO, "Can not open file ", s);
   return rc;
}


/**
 * \brief run the C pre-processor
 * \param verbose verbosity level
 * \param iFile input file name
 * \param oFile output file name
 * \param eFile error output file name
 * \param pl the include path list
 * \param ml the macro list
 * \return scanned symbol
 *****************************************************************************/

int
cpp_run (int verbose, char* iFile, char* oFile, char* eFile, struct _include_path* pl,
         struct _macro_list* ml)
{
   int rc;
   int fd_in;
   int fd_out;
   int fd_err;
   struct _token* t;
   struct _calc* st;

   if (!strcmp (iFile,"-")) {
      fd_in = STDIN_FILENO;
   } else {
      fd_in = open (iFile, O_RDONLY, 0);
      if (fd_in < 0)  return pr_error (iFile,1);
   }

   if (!strcmp (oFile,"-")) {
      fd_out = STDOUT_FILENO;
   } else {
      fd_out = open (oFile, O_WRONLY | O_CREAT | O_TRUNC, 0644);
      if (fd_out < 0)  return pr_error (oFile,1);
   }

   if (!strcmp (eFile,"-")) {
      fd_err = STDERR_FILENO;
   } else {
      fd_err = open (eFile, O_WRONLY | O_CREAT, 0644);
      if (fd_err < 0)  return pr_error (eFile,1);
   }

   t = Token_Create (iFile);
   st = Calc_Create ();

   ML_Add (ml, "__CKPMCC__", CPP_VERSION_STR);

   rc = cpp_parse (fd_in, fd_out, fd_err, t, ml, st, pl);

#ifdef DEBUG
   put_string (fd_err, "\n\n");
   Calc_Dump (st, fd_err);
#endif
   if (verbose > 1)  ML_Dump (fd_err, ml);

   Calc_Destroy (st);
   Token_Destroy (t);

   close (fd_in);
   close (fd_out);
   close (fd_err);

   return rc;
}









