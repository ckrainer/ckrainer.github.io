/**
 * \file cpp_scan.c
 * \brief CKPM C pre-processor
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/


#include <unistd.h>

#ifdef DEBUG
#include "cpp_io.h"
#endif

#include "cpp_token.h"
#include "cpp_scan.h"

/**
 * \brief check if a given character is a digit
 * \param ch the character to be checked
 * \return !=0 if the character is a digit, otherwise 0
 *****************************************************************************/

int
isDigit (char ch) {
   if  (ch >= '0' && ch <= '9') return 1;
   return 0;
}


/**
 * \brief check if a given character is a octal digit
 * \param ch the character to be checked
 * \return !=0 if the character is a digit, otherwise 0
 *****************************************************************************/

int
isOctDigit (char ch) {
   if (ch >= '0' && ch <= '7') return 1;
   return 0;
}


/**
 * \brief check if a given character is a hex digit
 * \param ch the character to be checked
 * \return !=0 if the character is a hex digit, otherwise 0
 *****************************************************************************/

int
isHexDigit (char ch) {
   if (ch >= '0' && ch <= '9')  return 1;
   if (ch >= 'A' && ch <= 'F')  return 1;
   if (ch >= 'a' && ch <= 'f')  return 1;
   return 0;
}


/**
 * \brief check if a given character is a letter
 * \param ch the character to be checked
 * \return !=0 if the character is a letter, otherwise 0
 *****************************************************************************/

int
isLetter (char ch) {
   if (ch >= 'A' && ch <= 'Z')  return 1;
   if (ch >= 'a' && ch <= 'z')  return 1;
   if (ch == '_')  return 1;
   return 0;
}


/**
 * \brief check if a given character is a white space
 * \param ch the character to be checked
 * \return !=0 if the character is a white space, otherwise 0
 *****************************************************************************/

int
isSpace (char ch) {
   if (ch == ' ' || ch == '\t') return 1;
   return 0;
}


/**
 * \brief read one byte
 * \param fd file descriptor index of the input file
 * \param c the output variable containing the byte
 * \return status on from file read
 *****************************************************************************/
int
read_byte (int fd, char* c) {
   int rc;
   rc = read (fd, (void*)c, sizeof(char));
#if 0
#ifdef DEBUG
   put_string (STDERR_FILENO, "read: ");
   put_int (STDERR_FILENO, *c);
   put_string (STDERR_FILENO, " '");
   if (*c > 31) put_char (STDERR_FILENO, '?');
   else         put_char (STDERR_FILENO, *c);
   put_string (STDERR_FILENO, "\n");
#endif
#endif
   return rc;
}


/**
 * \brief get next symbol that is no white space
 * \param fd file descriptor index of the input file
 * \param t contains a complete token
 *****************************************************************************/

void
GetSymNoSpace (int fd, struct _token* t) {
   GetSym (fd, t);
   while (t->sym == SYM_SPACE) GetSym (fd, t);
}


/**
 * \brief get next symbol
 * \param fd file descriptor index of the input file
 * \param t contains a complete token
 *****************************************************************************/

void
GetSym (int fd, struct _token* t) {
   int	i;
   int	e;

#ifdef DEBUG
   put_string (STDERR_FILENO, "GetSym() before: stat=");
   put_int    (STDERR_FILENO, t->stat);
   put_string (STDERR_FILENO, " line=");
   put_int    (STDERR_FILENO, t->line);
   put_string (STDERR_FILENO, " sym=");
   put_int    (STDERR_FILENO, t->sym);
   put_string (STDERR_FILENO, " (");
   put_string (STDERR_FILENO, sym_to_string(t->sym));
   put_three_string_nl (STDERR_FILENO, ") id='", t->id,"'");
#endif

   t->sym = SYM_OTHER;
   t->id[0] = t->ch;
   t->id[1] = '\0';

   if ( t->stat <= 0 )
      return;

   if ( t->ch == '\n' ) {
      t->sym = SYM_NEWLINE;
      t->line = t->line + 1;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( isSpace (t->ch) ) {
      t->sym = SYM_SPACE;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch <  ' ' ) {	/* an unprintable character */
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '(' ) {
      t->sym = SYM_LEFT_PAREN;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '[' ) {
      t->sym = SYM_LEFT_BRACK;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '{' ) {
      t->sym = SYM_LEFT_BRACE;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '<' ) {
      t->sym = SYM_LEFT_ANGLE_BRACK;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '<' ) {
         t->id[1] = t->ch;
         t->id[2] = '\0';
         t->sym = SYM_LEFT_SHIFT;
         t->stat = read_byte (fd, &t->ch);
         return;
      }
      if ( t->ch == '=' ) {
         t->id[1] = t->ch;
         t->id[2] = '\0';
         t->sym = SYM_CMP_LE;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == '|' ) {
      t->sym = SYM_BAR;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '|' ) {
         t->id[1] = t->ch;
         t->id[2] = '\0';
         t->sym = SYM_LOGICAL_OR;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == '&' ) {
      t->sym = SYM_AMPERSAND;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '&' ) {
         t->id[1] = t->ch;
         t->id[2] = '\0';
         t->sym = SYM_LOGICAL_AND;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == '=' ) {
      t->sym = SYM_EQUAL;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '=' ) {
         t->id[1] = t->ch;
         t->id[2] = '\0';
         t->sym = SYM_CMP_EQ;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == ')' ) {
      t->sym = SYM_RIGHT_PAREN;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == ']' ) {
      t->sym = SYM_RIGHT_BRACK;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '}' ) {
      t->sym = SYM_RIGHT_BRACE;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '>' ) {
      t->sym = SYM_RIGHT_ANGLE_BRACK;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '>' ) {
         t->id[1] = t->ch;
         t->id[2] = '\0';
         t->sym = SYM_RIGHT_SHIFT;
         t->stat = read_byte (fd, &t->ch);
         return;
      }
      if ( t->ch == '=' ) {
         t->id[1] = t->ch;
         t->id[2] = '\0';
         t->sym = SYM_CMP_GE;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == '.' ) {
      t->sym = SYM_PERIOD;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == ':' ) {
      t->sym = SYM_COLON;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == ';' ) {
      t->sym = SYM_SEMICOLON;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == ',' ) {
      t->sym = SYM_COMMA;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '+' ) {
      t->sym = SYM_PLUS;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '-' ) {
      t->sym = SYM_MINUS;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '*' ) {
      t->sym = SYM_ASTERISK;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '!' ) {
      t->sym = SYM_EXCLAMATION_MARK;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '=' ) {
         t->id[1] = t->ch;
         t->id[2] = '\0';
         t->sym = SYM_CMP_NEQ;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   /* character literal */
   if ( t->ch == '\'' ) {
      i = 0;
      t->sym = SYM_CHARACTER;
      t->id[i] = t->ch;
      i = i + 1;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '\\' ) {
         t->id[i] = t->ch;
         i = i + 1;
         t->stat = read_byte (fd, &t->ch);
      }
      t->id[i] = t->ch;
      i = i + 1;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '\'' ) {
         t->id[i] = t->ch;
         i = i + 1;
         t->id[i] = '\0';
         t->stat = read_byte (fd, &t->ch);
         return;
      }
      t->sym = SYM_OTHER;
      t->id[i] = '\0';
      return;
   }

   /* pre-processor command */
   if ( t->ch == '#' ) {
      t->sym = SYM_NUMBER_SIGN;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   /* comment */
   if ( t->ch == '/' ) {
      i = 0;
      t->id[i] = '/';
      i = i + 1;
      if ( (t->stat = read_byte (fd, &t->ch)) <= 0)
         return;
      if ( t->ch == '/' ) {
         t->id[i] = t->ch;
         i = i + 1;
         t->sym = SYM_COMMENT;
         while ( (t->stat = read_byte (fd, &t->ch)) > 0) {
//          if (t->ch == '\n') { t->line = t->line + 1; break; }
            if (t->ch == '\n') break;
            t->id[i] = t->ch;
            i = i + 1;
         }
         t->id[i] = '\0';
         return;
      }
      if ( t->ch != '*' ) {
         t->sym = SYM_DIVIDE;
         t->id[i] = '\0';
         return;
      }
      t->id[i] = t->ch;
      i = i + 1;
      t->sym = SYM_COMMENT;
      while ( (t->stat = read_byte (fd, &t->ch)) > 0) {
         t->id[i] = t->ch;
         i = i + 1;
         if (t->ch == '\n') t->line = t->line + 1;
         if ( i >= IDENT_MAX_LEN )
            break;
         if ( t->ch == '/' && t->id[i-2] == '*' )
            break;
      }
      t->id[i] = '\0';
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   /* string literal */
   if ( t->ch == '"' ) {
      t->sym = SYM_LITERAL;
      i = 0;
      e = 0;
      while ( (t->stat = read_byte (fd, &t->ch)) > 0 ) {
         if (t->ch == '\n')  t->line = t->line + 1;
         if ( !e && (t->ch == '"' || t->ch == '\n') )
            break;
         if (t->ch == '\\') e = 1; else e = 0;
         t->id[i] = t->ch;
         i = i + 1;
      }
      t->id[i] = '\0';
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   /* idenifier */
   if ( isLetter (t->ch) ) {
      t->sym = SYM_IDENT;
      i = 0;
      while ( t->stat > 0 && (isLetter (t->ch) || isDigit (t->ch)) ) {
         t->id[i] = t->ch;
         i = i + 1;
         if ( i >= IDENT_MAX_LEN )
            break;
         t->stat = read_byte (fd, &t->ch);
      }
      t->id[i] = '\0';
      return;
   }

   /* number */
   if ( isDigit (t->ch) ) {
      t->sym = SYM_NUMBER;
      if (t->ch == '0')  t->sym = SYM_OCT_NUMBER;
      i = 0;
      t->id[i] = t->ch;
      i = i + 1;
      t->stat = read_byte (fd, &t->ch);

      if (t->ch == 'x' || t->ch == 'X') {
         t->sym = SYM_HEX_NUMBER;
         t->id[i] = t->ch;
         i = i + 1;
         t->stat = read_byte (fd, &t->ch);
         if (!isHexDigit (t->ch)) {
            t->sym = SYM_OTHER;
            t->id[i] = '\0';
            t->stat = read_byte (fd, &t->ch);
            return;
         }
         while ( t->stat > 0 && isHexDigit (t->ch) ) {
            t->id[i] = t->ch;
            i = i + 1;
            if ( i >= IDENT_MAX_LEN )
               break;
            t->stat = read_byte (fd, &t->ch);
         }
         t->id[i] = '\0';
         return;
      }

      if (t->sym == SYM_OCT_NUMBER) {
         while ( t->stat > 0 && isOctDigit (t->ch) ) {
            t->id[i] = t->ch;
            i = i + 1;
            if ( i >= IDENT_MAX_LEN )
               break;
            t->stat = read_byte (fd, &t->ch);
         }
         t->id[i] = '\0';
         return;
      }

      while ( t->stat > 0 && isDigit (t->ch) ) {
         t->id[i] = t->ch;
         i = i + 1;
         if ( i >= IDENT_MAX_LEN )
            break;
         t->stat = read_byte (fd, &t->ch);
      }
      t->id[i] = '\0';
      return;
   }

   t->stat = read_byte (fd, &t->ch);
   return;
}



/**
 * \brief read characters from an input files and copy them to an output file until '\n' occurs.
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \return status code of read(2) and write(2), respectively.
 *****************************************************************************/

int
CopyTillNewline (int fd_in, int fd_out) {
   char ch;  
   int rc;
   while ( (rc = read  (fd_in, (void*)&ch, sizeof(ch))) > 0 ) {
      if ( (rc = write (fd_out, (void*)&ch, sizeof(ch))) < 0 )
         break;
      if ( ch == '\n' )
         break;
   }
   return rc;
}


/**
 * \brief convert symbols to the corresponding text
 * \param sym the symbol
 * \return the symbol as a string
 *****************************************************************************/

char*
sym_to_string (int sym) {
   if (sym == SYM_LEFT_PAREN)         return "left parenthesis symbol";
   if (sym == SYM_LEFT_BRACK)         return "left bracket symbol";
   if (sym == SYM_LEFT_BRACE)         return "left brace symbol";
   if (sym == SYM_LEFT_ANGLE_BRACK)   return "left angle bracket";
   if (sym == SYM_LEFT_SHIFT)         return "left shift symbol";
   if (sym == SYM_BAR)                return "bar symbol";
   if (sym == SYM_EQUAL)              return "equal symbol";
   if (sym == SYM_RIGHT_PAREN)        return "right parenthesis symbol";
   if (sym == SYM_RIGHT_BRACK)        return "right bracket symbol";
   if (sym == SYM_RIGHT_BRACE)        return "right brace symbol";
   if (sym == SYM_RIGHT_ANGLE_BRACK)  return "right angle bracket";
   if (sym == SYM_RIGHT_SHIFT)        return "right shift symbol";
   if (sym == SYM_PERIOD)             return "period symbol";
   if (sym == SYM_NUMBER_SIGN)        return "number sign";
   if (sym == SYM_DIVIDE)             return "arithmetic division";
   if (sym == SYM_REMINDER)           return "reminder of an integer division";
   if (sym == SYM_SPACE)              return "white space";
   if (sym == SYM_PLUS)               return "positive sign / addition";
   if (sym == SYM_MINUS)              return "negative sign / subtraction";
   if (sym == SYM_ASTERISK)           return "multiplication";
   if (sym == SYM_EXCLAMATION_MARK)   return "exclamation mark";
   if (sym == SYM_LOGICAL_OR)         return "logical or operator";
   if (sym == SYM_LOGICAL_AND)        return "logical and operator";
   if (sym == SYM_AMPERSAND)          return "ampersand symbol";
   if (sym == SYM_CMP_EQ)             return "comparison equal symbol";
   if (sym == SYM_CMP_NEQ)            return "comparison not equal symbol";
   if (sym == SYM_CMP_GE)             return "comparison greater or equal";
   if (sym == SYM_CMP_LE)             return "comparison lower or equal";
   if (sym == SYM_COLON)              return "colon";
   if (sym == SYM_SEMICOLON)          return "semi colon";
   if (sym == SYM_COMMA)              return "comma";

   if (sym == SYM_COMMENT)            return "comment symbol";
   if (sym == SYM_NEWLINE)            return "newline symbol";
   if (sym == SYM_NUMBER)             return "number";
   if (sym == SYM_OCT_NUMBER)         return "octal number";
   if (sym == SYM_HEX_NUMBER)         return "hexa decimal number";
   if (sym == SYM_IDENT)              return "identifier symbol";
   if (sym == SYM_LITERAL)            return "string literal symbol";
   if (sym == SYM_CHARACTER)          return "a single character";

   if (sym == SYM_INCLUDE)            return "include symbol";
   if (sym == SYM_DEFINE)             return "define symbol";
   if (sym == SYM_DEFINED)            return "defined symbol";
   if (sym == SYM_IF)                 return "if symbol";
   if (sym == SYM_IFDEF)              return "ifdef symbol";
   if (sym == SYM_ELSIF)              return "elsif symbol";
   if (sym == SYM_ELSE)               return "else symbol";
   if (sym == SYM_ENDIF)              return "endif symbol";
   if (sym == SYM_UNDEF)              return "undef symbol";

   if (sym == SYM_OTHER)              return "other symbol";
   return "unknown symbol";
}
