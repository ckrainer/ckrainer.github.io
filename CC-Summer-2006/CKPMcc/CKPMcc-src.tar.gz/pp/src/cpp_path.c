/**
 * \file cpp_path.c
 * \brief CKPM C pre-processor include path list
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifdef DEBUG
#include <unistd.h>
#endif
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>

#include "cpp_io.h"
#include "cpp_path.h"


/**
 * \brief create and initialize a new path list
 * \return the path list
 *****************************************************************************/

struct _include_path*
Path_Create () {
   struct _include_path* l;
   l = (struct _include_path*) malloc (sizeof(struct _include_path));
   l->len = 0;
   return l;
}


/**
 * \brief destroy the path list
 * \param l the path list
 *****************************************************************************/
void
Path_Destroy (struct _include_path* l) {
   int i; i=0;
   while (i < l->len) {
      free ((void*)l->dirs[i]);
      i = i + 1;
   }
   free ((void*)l);
#ifdef DEBUG
   put_string (STDERR_FILENO, "Path_Destroy:\n");
#endif
}


/**
 * \brief dump the path list
 * \param l the path list
 * \param fd the filedesciptor index of the output file
 * \return index of the found path on success, otherwise -1
 *****************************************************************************/
void
Path_Dump (struct _include_path* l, int fd) {
   int i; i=0;
   put_string (fd, "\nDefined include paths:\n");
   while (i < l->len) {
      put_int (fd, i);
      put_string (fd, ": '");
      put_string (fd, l->dirs[i]);
      put_string (fd, "'\n");
      i = i + 1;
   }
}


/**
 * \brief add an entry to the path list
 * \param l the path list
 * \param dir the new path name
 * \return new lenght of the path list on success, otherwise -1 
 *****************************************************************************/
int
Path_Add (struct _include_path* l, char *dir) {
   if ( Path_Index (l,dir) >= 0 || l->len >= MAX_INCLUDE_PATH )
      return -1;
   l->dirs[l->len] = strdup(dir);
   l->len = l->len + 1;
#ifdef DEBUG
   put_three_string_nl (STDERR_FILENO, "Path_Add: '",dir,"'");
#endif
   return l->len;
}


/**
 * \brief remove an entry from the path list
 * \param l the path list
 * \param dir the requested path name
 * \return new lenght of the path list on success, otherwise -1 
 *****************************************************************************/
int
Path_Remove (struct _include_path* l, char *dir) {
   int i;
#ifdef DEBUG
   put_three_string_nl (STDERR_FILENO, "Path_Remove: '",dir,"'");
#endif

   i = Path_Index (l,dir);
   if (i < 0 || l->len == 0)
      return -1;
#ifdef DEBUG
   put_string (STDERR_FILENO, "Path_Remove: '");
   put_string (STDERR_FILENO, dir);
   put_string (STDERR_FILENO, "' '");
   put_int (STDERR_FILENO, i);
   put_string (STDERR_FILENO, "': '");
   put_string (STDERR_FILENO, l->dirs[i]);
   put_string (STDERR_FILENO, "'\n");
#endif
   free ((void*)l->dirs[i]);
   l->len = l->len - 1;
   while (i < l->len)  { l->dirs[i] = l->dirs[i+1]; i = i + 1; }
   return l->len;
}


/**
 * \brief search a file's path name and open it
 * \param l the path list
 * \param name the name of the file who's path is required
 * \param loc additionally search the local directory first
 * \return file descriptor index of the found file on success, otherwise -1
 *****************************************************************************/
int
Path_Search_And_Open (struct _include_path* l, char *name, int loc) {
   char path[1024];
   int fd;
   int i;

   if (!name || *name == 0)
      return -1;

   if (loc) {
      strcpy (path, "./");
      strcat (path, name);
      fd = open (path, O_RDONLY, 0);
      if (fd >= 0)
         return fd;
   }

   i=0;
   while (i < l->len) {
      strcpy (path, l->dirs[i]);
      strcat (path, "/");
      strcat (path, name);
      fd = open (path, O_RDONLY, 0);
#ifdef DEBUG
      put_string (STDERR_FILENO, "Path_Search_And_Open: ");
      if (fd < 0) put_string (STDERR_FILENO, "search '");
      else        put_string (STDERR_FILENO, "found  '");
      put_string (STDERR_FILENO, name);
      put_string (STDERR_FILENO, "' as '");
      put_two_string_nl (STDERR_FILENO, path, "'");
#endif
      if (fd >= 0)
         return fd;
      i = i + 1;
   }

   return -1;
}


/**
 * \brief get an entry index from the path list
 * \param l the path list
 * \param dir the requested path identification
 * \return index of the found path on success, otherwise -1
 *****************************************************************************/
int
Path_Index (struct _include_path* l, char *dir) {
   int i;
#ifdef DEBUG
   put_string (STDERR_FILENO, "Path_Index:\n");
#endif

   i=0;
   while (i < l->len) {
      if (!strcmp (l->dirs[i], dir))
         return i;
      i = i + 1;
   }
   return -1;
}

