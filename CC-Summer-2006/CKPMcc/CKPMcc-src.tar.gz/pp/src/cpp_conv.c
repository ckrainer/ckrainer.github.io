/**
 * \file cpp_conv.c
 * \brief CKPM C pre-processor convert routines definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/


#include "cpp_conv.h"

/**
 * \brief convert an integer value to its string representation
 * \param buf a character buffer to work with
 * \param len the length of the character buffer
 * \param base the conversion base, e.g. 2,8,10,16
 * \param n the integer value to be converted
 * \return the character buffer if successful, otherwise null
 *****************************************************************************/

char*
int_to_str (char *buf, size_t len, int base, int n) {
   char h[100];
   int i; int r; int neg;
   char *s;
   if (!buf || len < 0)  return (char*)0;
   neg = 0;
   if (n < 0) { neg = neg + 1; n=-n; }
   i=0;
   while (i < 100 && (n != 0 || !i)) {
      r = n % base;
      n = n / base;
      if (base > 10 && r > 9)  r = r + 7;
      h[i] = (char)(48+r);
      i = i + 1;
   }
   h[i] = '\0';
   if (i >= len)  return (char*)0;
   s = buf;
   if (neg) { *s = '-'; s =  s + 1; }
   while (i > 0) {
      i = i - 1;
      *s = h[i];
      s =  s + 1;
   }
   *s = '\0';
   return buf;
}


/**
 * \brief a decimal number given as a string to its corresponding integer value
 * \param s the decimal number string
 * \return the calculated integer value
 *****************************************************************************/

int
dec_string_to_int (char * s) {
   int r;
   r = 0;
   while (s && *s && *s >= '0' && *s <= '9')  {
      r = 10*r + *s - '0';
      s = s + 1;
   }
   return r;
}


/**
 * \brief a octal number given as a string to its corresponding integer value
 * \param s the octal number string
 * \return the calculated integer value
 *****************************************************************************/

int
oct_string_to_int (char * s) {
   int r;
   r = 0;
   while (s && *s && *s >= '0' && *s <= '7')  {
      r = 8*r + *s - '0';
      s = s + 1;
   }
   return r;
}


/**
 * \brief a hexa decimal number given as a string to its corresponding integer value
 * \param s the hexa decimal number string
 * \return the calculated integer value
 *****************************************************************************/

int
hex_string_to_int (char * s) {
   int r;
   int h;
   r = 0;
   if (!s || *s == 0)  return 0;
   if (*s == '0') {
      s = s + 1;
      if (*s == 'x')  s = s + 1;
   }
   while (s && *s && ((*s >= '0' && *s <= '9') ||
                      (*s >= 'A' && *s <= 'F') ||
                      (*s >= 'a' && *s <= 'f')) ) {
      h = (int)(*s - '0'); if (*s > 58)  h=h-7;  if (*s > 70)  h=h-32;
      r = 16*r + h;
      s = s + 1;
   }
   return r;
}



