/**
 * \file cpp_path.h
 * \brief CKPM C pre-processor include path definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef _CKPM_CPP_PATH_H_
#define _CKPM_CPP_PATH_H_


#define MAX_INCLUDE_PATH        30      /*!< maximum number of directory entries */

struct _include_path {                  /*!< defined include path */
   int   len;                           /*!< number of directories */
   char* dirs[MAX_INCLUDE_PATH];        /*!< directory entries */
};


struct _include_path* Path_Create ();
void Path_Destroy (struct _include_path* l);
void Path_Dump (struct _include_path* l, int fd);
int Path_Add (struct _include_path* l, char *dir);
int Path_Remove (struct _include_path* l, char *id);
int Path_Search_And_Open (struct _include_path* l, char *name, int loc);
int Path_Index (struct _include_path* l, char *dir);



#endif /* _CKPM_CPP_PATH_H_ */

