/**
 * \file cpp_parse.c
 * \brief CKPM C pre-processor parser
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <unistd.h>
#include <string.h>
#include <strings.h>

#include "cpp_io.h"
#include "cpp_calc.h"
#include "cpp_conv.h"
#include "cpp_macros.h"
#include "cpp_path.h"
#include "cpp_scan.h"
#include "cpp_parse.h"


/* some declarations */
int simple_Expression (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st);
int defined_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st);
int if_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st);
int endif_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st);
int ifdef_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st);
int ifndef_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st);

/**
 * \brief write an error message with two strings and a newline to an open file
 * \param fd an already opened file to write to
 * \param t the actual token (including line number)
 * \param s1 the first string to be written
 * \param s2 the second string to be written
 * \return the response code from write(2)
 *****************************************************************************/

int
cpp_error (int fd, struct _token*t, char* s1, char* s2) {
   /* TODO: real implementation? */
   put_string (fd, "ERROR: in file '");
   put_string (fd, t->file);
   put_string (fd, "' in line ");
   put_int    (fd, t->line);
#ifdef DEBUG
// put_string (fd, ", sym=");
// put_string (fd, sym_to_string (t->sym));
// put_string (fd, ", id='");
// put_string (fd, t->id);
// put_string (fd, "'");
#endif
   put_string (fd, ": ");
   return put_two_string_nl (fd, s1, s2);
}


/**
 * \brief write an warning message with two strings and a newline to an open file
 * \param fd an already opened file to write to
 * \param t the actual token (including line number)
 * \param s1 the first string to be written
 * \param s2 the second string to be written
 * \return the response code from write(2)
 *****************************************************************************/

int
cpp_warning (int fd, struct _token*t, char* s1, char* s2) {
   /* TODO: real implementation? */
   put_string (fd, "WARNING: in file '");
   put_string (fd, t->file);
   put_string (fd, "' in line ");
   put_int    (fd, t->line);
#ifdef DEBUG
// put_string (fd, ", sym=");
// put_string (fd, sym_to_string (t->sym));
// put_string (fd, ", id='");
// put_string (fd, t->id);
// put_string (fd, "'");
#endif
   put_string (fd, ": ");
   return put_two_string_nl (fd, s1, s2);
}


/**
 * \brief write an info message with two strings and a newline to an open file
 * \param fd an already opened file to write to
 * \param t the actual token (including line number)
 * \param s1 the first string to be written
 * \param s2 the second string to be written
 * \return the response code from write(2)
 *****************************************************************************/

int
cpp_info (int fd, struct _token*t, char* s1, char* s2) {
   /* TODO: real implementation? */
   put_string (fd, "INFO: in file '");
   put_string (fd, t->file);
   put_string (fd, "' in line ");
   put_int    (fd, t->line);
   put_string (fd, ", sym=");
   put_string (fd, sym_to_string (t->sym));
   put_string (fd, ", id='");
   put_string (fd, t->id);
   put_string (fd, "'");
   put_string (fd, ": ");
   return put_two_string_nl (fd, s1, s2);
}


/**
 * \brief calculate expressions using the stack based calculator
 * \param fd_err file descriptor index of the error output file
 * \param sym the operation to be performed
 * \param st the calculator stack
 * \return
 *****************************************************************************/

void
calculate (int fd_err, int sym, struct _calc* st) {
   if      (sym == SYM_PLUS)          		Calc_Add (st);
   else if (sym == SYM_MINUS)         		Calc_Subtract (st);
   else if (sym == SYM_ASTERISK)      		Calc_Multiply (st);
   else if (sym == SYM_DIVIDE)        		Calc_Divide (st);
   else if (sym == SYM_REMINDER)       		Calc_Rem (st);
   else if (sym == SYM_LOGICAL_AND)   		Calc_And (st);
   else if (sym == SYM_LOGICAL_OR)    		Calc_Or (st);
   else if (sym == SYM_EXCLAMATION_MARK)	Calc_Not (st);
   else if (sym == SYM_LEFT_SHIFT)    		Calc_Shift_Left (st);
   else if (sym == SYM_RIGHT_SHIFT)    		Calc_Shift_Right (st);
   else if (sym == SYM_CMP_EQ)			Calc_Cmp_EQ (st);
   else if (sym == SYM_CMP_NEQ)			Calc_Cmp_NEQ (st);
   else if (sym == SYM_CMP_GE)			Calc_Cmp_GE (st);
   else if (sym == SYM_RIGHT_ANGLE_BRACK)	Calc_Cmp_GT (st);
   else if (sym == SYM_CMP_LE)			Calc_Cmp_LE (st);
   else if (sym == SYM_LEFT_ANGLE_BRACK)	Calc_Cmp_LT (st);
   else { 
      put_two_string_nl (fd_err, "unknown calc operation: ", sym_to_string (sym));
      Calc_Dump (st, fd_err);
   }
}


/**
 * \brief parse a logical and expression
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \return
 *****************************************************************************/
int
comp_Expression (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st) {
   int negate;
   int rc;
   int sym;

#ifdef DEBUG
   put_string (fd_err, "comp_Expression()\n");
#endif

   negate = 0;
   if (t->sym == SYM_EXCLAMATION_MARK) {
#ifdef DEBUG
      put_string (fd_err, "### defined_Statement() negation\n");
#endif
      negate = negate + 1;
      GetSymNoSpace (fd_in, t);
   }

   if (t->sym == SYM_IDENT && !strcmp (t->id, "defined")) {
      GetSymNoSpace (fd_in, t);
      rc = defined_Statement (fd_in, fd_out, fd_err, t, ml, st);
      if (negate)  Calc_Not (st);
      return rc;
   }

   if (negate) {
      cpp_error (fd_err, t, "symbol not allowed here: ", t->id);
      return 0;
   }

   rc = simple_Expression (fd_in, fd_out, fd_err, t, ml, st);

   while ( rc && (t->sym == SYM_CMP_EQ || t->sym == SYM_CMP_NEQ ||
                  t->sym == SYM_CMP_GE || t->sym == SYM_CMP_LE ||
                  t->sym == SYM_RIGHT_ANGLE_BRACK || t->sym == SYM_LEFT_ANGLE_BRACK ))
   {
      sym = t->sym;
      GetSymNoSpace (fd_in, t);
      rc = simple_Expression (fd_in, fd_out, fd_err, t, ml, st);
#ifdef DEBUG
      put_string (fd_err, "### defined_Statement() calculate\n");
#endif
      calculate (fd_err, sym, st);
#ifdef DEBUG
      Calc_Dump (st, fd_err);
#endif
   }

   return rc;

}


/**
 * \brief parse a logical and expression
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \return
 *****************************************************************************/
int
logical_And_Expression (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st) {
#ifdef DEBUG
   put_string (fd_err, "logical_And_Expression()\n");
#endif

   comp_Expression (fd_in, fd_out, fd_err, t, ml, st);

   while (t->sym == SYM_LOGICAL_AND) {
      GetSymNoSpace (fd_in, t);
      comp_Expression (fd_in, fd_out, fd_err, t, ml, st);
#ifdef DEBUG
      put_string (fd_err, "logical_And_Expression() calculate\n");
#endif
      calculate (fd_err, SYM_LOGICAL_AND, st);
#ifdef DEBUG
      Calc_Dump (st, fd_err);
#endif
   }

   return 1;
}


/**
 * \brief parse a logical or expression
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \return
 *****************************************************************************/
int
logical_Or_Expression (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st) {
#ifdef DEBUG
   put_string (fd_err, "logical_Or_Expression()\n");
#endif

   logical_And_Expression (fd_in, fd_out, fd_err, t, ml, st);

   while (t->sym == SYM_LOGICAL_OR) {
      GetSymNoSpace (fd_in, t);
      logical_And_Expression (fd_in, fd_out, fd_err, t, ml, st);
#ifdef DEBUG
      put_string (fd_err, "logical_Or_Expression() calculate\n");
#endif
      calculate (fd_err, SYM_LOGICAL_OR, st);
#ifdef DEBUG
      Calc_Dump (st, fd_err);
#endif
   }  

   return 1;
}


/**
 * \brief parse a factor
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \return
 *****************************************************************************/
int
factor (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st) {
   char *s;
   int rc;
   int negate;

#ifdef DEBUG
   put_string (fd_err, "factor()\n");
#endif

   negate = 0;
   if (t->sym == SYM_EXCLAMATION_MARK) {
      negate = 1;
      GetSymNoSpace (fd_in, t);
   }

   if (t->sym == SYM_LEFT_PAREN) {
      GetSymNoSpace (fd_in, t);
      rc = logical_Or_Expression (fd_in, fd_out, fd_err, t, ml, st);
      if (t->sym != SYM_RIGHT_PAREN) {
         cpp_error (fd_err, t, "missing right parenthesis: ", "");
         GetSymNoSpace (fd_in, t);
         return 0;
      }
      GetSymNoSpace (fd_in, t);
      if (negate)  Calc_Not (st);
      return rc;
   }


   if (t->sym == SYM_IDENT) {
#ifdef DEBUG
      put_two_string_nl (fd_err,"factor() SYM_IDENT: ", t->id);
#endif
      s = ML_Get (ml, t->id);
      if (s) {
         Calc_Push (st, dec_string_to_int (s));
         if (negate)  Calc_Not (st);
         GetSymNoSpace (fd_in, t);
         return 1;
      }

      cpp_error (fd_err, t, "macro not defined: ", t->id);
      Calc_Push (st, 0);
      GetSymNoSpace (fd_in, t);
      return 0;
   }

   if (t->sym == SYM_NUMBER) {
      Calc_Push (st, dec_string_to_int (t->id));
      GetSymNoSpace (fd_in, t);
      if (negate)  Calc_Not (st);
      return 1;
   }

   if (t->sym == SYM_OCT_NUMBER) {
      Calc_Push (st, oct_string_to_int (t->id));
      GetSymNoSpace (fd_in, t);
      if (negate)  Calc_Not (st);
      return 1;
   }

   if (t->sym == SYM_HEX_NUMBER) {
      Calc_Push (st, hex_string_to_int (t->id));
      GetSymNoSpace (fd_in, t);
      if (negate)  Calc_Not (st);
      return 1;
   }

   if (t->sym == SYM_LITERAL) {
      cpp_error (fd_err, t, "string not allowed here: ", "");
      GetSymNoSpace (fd_in, t);
      return 1;
   }

   if (t->sym == SYM_CHARACTER) {
      cpp_error (fd_err, t, "string not allowed here: ", "");
      GetSymNoSpace (fd_in, t);
      return 1;
   }
   
   cpp_error (fd_err, t, "missing identifier or constant: ", "");
   return 0;
}


/**
 * \brief parse a term
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \param neg if != 0 then negate the first factor
 * \return
 *****************************************************************************/
int
term (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st, int neg) {
   int rc;
   int sym;

#ifdef DEBUG
   put_string (fd_err, "term()\n");
#endif

   rc = factor (fd_in, fd_out, fd_err, t, ml, st);
   if (neg)  { Calc_Push (st, -1); Calc_Multiply (st); }
   
   while (t->sym == SYM_ASTERISK || t->sym == SYM_DIVIDE ||
          t->sym == SYM_REMINDER || t->sym == SYM_EXCLAMATION_MARK)
   {
      sym = t->sym;
      GetSymNoSpace (fd_in, t);
      rc = factor (fd_in, fd_out, fd_err, t, ml, st);

#ifdef DEBUG
      put_string (fd_err, "term() calculate\n");
#endif
      calculate (fd_err, sym, st);
#ifdef DEBUG
      Calc_Dump (st, fd_err);
#endif
   }

   return rc;
}


/**
 * \brief parse a simple expression
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \return
 *****************************************************************************/
int
simple_Expression (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st) {
   int negate;
   int sym;

   negate = 0;

#ifdef DEBUG
   put_string (fd_err, "simple_Expression()\n");
#endif

   if (t->sym == SYM_PLUS || t->sym == SYM_MINUS) {
      if (t->sym == SYM_MINUS) negate = negate + 1;
      GetSymNoSpace (fd_in, t);
   }

   term (fd_in, fd_out, fd_err, t, ml, st, negate);
   
   while (t->sym == SYM_PLUS || t->sym == SYM_MINUS ||
          t->sym == SYM_LEFT_SHIFT || t->sym == SYM_RIGHT_SHIFT)
   {
      sym = t->sym;
      GetSymNoSpace (fd_in, t);
      term (fd_in, fd_out, fd_err, t, ml, st, 0);

#ifdef DEBUG
      Calc_Dump (st, fd_err);
      put_two_string_nl (fd_err, "simple_Expression() calculate: ", sym_to_string (sym));
#endif
      calculate (fd_err, sym, st);
#ifdef DEBUG
      Calc_Dump (st, fd_err);
#endif
   }

   if (st->status == STACK_STATUS_OK)  return 1;
   return 0;
}


/**
 * \brief parse a elsif statement
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \return
 *****************************************************************************/
int
elsif_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st) {
   int ok;
#ifdef DEBUG
   put_string (fd_err, "elsif_Statement()\n");
#endif

   if (!Calc_Pop (st))		/* was the preceeding if/elsif false ? */
      return if_Statement (fd_in, fd_out, fd_err, t, ml, st);

   /* the was the preceeding if/elsif was true, so we eat all text until #endif */
   Calc_Push (st, 0);
   ok = 1;
   while (ok) {
      GetSymNoSpace (fd_in, t);
      if (t->stat <= 0) break;
      if (t->sym == SYM_NEWLINE)                { ok = 2; continue; }
      if (ok == 2 && t->sym == SYM_NUMBER_SIGN) { ok = 3; continue; }
      if (ok == 3 && t->sym == SYM_IDENT && !strcmp (t->id, "endif"))
         return endif_Statement (fd_in, fd_out, fd_err, t, ml, st);
      ok = 1;
   }

   cpp_error (fd_err, t, "'endif' missing.", "");
   return 0;
}


/**
 * \brief parse a else statement
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \return
 *****************************************************************************/
int
else_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st) {
   int ok;
#ifdef DEBUG
   put_string (fd_err, "else_Statement()\n");
#endif

   if (!Calc_Pop (st)) {	/* was the preceeding if/elsif false ? */
      Calc_Push (st, 1);
      GetSymNoSpace (fd_in, t);
      return 1;
   }

   /* the was the preceeding if/elsif was true, so we eat all text until #endif */
   Calc_Push (st, 0);
   ok = 1;
   while (ok) {
      GetSymNoSpace (fd_in, t);
      if (t->stat <= 0) break;
      if (t->sym == SYM_NEWLINE)                { ok = 2; continue; }
      if (ok == 2 && t->sym == SYM_NUMBER_SIGN) { ok = 3; continue; }
      if (ok == 3 && t->sym == SYM_IDENT && !strcmp (t->id, "endif"))
         return endif_Statement (fd_in, fd_out, fd_err, t, ml, st);
      ok = 1;
   }

   cpp_error (fd_err, t, "'endif' missing.", "");
   return 0;
}


/**
 * \brief parse a endif statement
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \return
 *****************************************************************************/
int
endif_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st) {
#ifdef DEBUG
   put_string (fd_err, "endif_Statement()\n");
#endif

   GetSymNoSpace (fd_in, t);

#ifdef DEBUG
   Calc_Dump (st, fd_err);
#endif

   Calc_Pop (st);
   return 1;
}


/**
 * \brief write the current line number and file name to the output file
 * \param fd_out file descriptor index of the output file
 * \param t the current token
 *****************************************************************************/
void
write_line (int fd_out, struct _token* t) {
   char buf[100];
   put_string (fd_out, "# ");
   put_string (fd_out, int_to_str (buf, 100, 10, t->line-1));
   put_string (fd_out, " \"");
   put_string (fd_out, t->file);
   put_string (fd_out, "\"");
}


/**
 * \brief parse a include statement
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \param pl include path list
 * \return
 *****************************************************************************/
int
include_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st, struct _include_path* pl) {
   char fn[256];
   int i;
   int rc;
   int fd_in_new;
   int loc;
   struct _token *tn;

   GetSymNoSpace (fd_in, t);

   if (t->sym == SYM_LITERAL) {
      loc = 1;
      strcpy (fn, t->id);
   } else {
      loc = 0;
      if (t->sym == SYM_LEFT_ANGLE_BRACK) {
         i=0;
         fn[0] = '\0';
         GetSymNoSpace (fd_in, t);
         while (t->sym == SYM_IDENT || t->sym == SYM_PERIOD || t->sym == SYM_DIVIDE) {
            strcat (fn, t->id);
            GetSymNoSpace (fd_in, t);
         }
         if (t->sym != SYM_RIGHT_ANGLE_BRACK) {
            cpp_error (fd_err, t, "malformed include file name: ", fn);
            GetSymNoSpace (fd_in, t);
            return 0;
         }
      }
   }

   tn = Token_Create (fn);

#ifdef DEBUG
   put_two_string_nl (fd_err, "### include file: ", fn);
#endif

   fd_in_new = Path_Search_And_Open (pl, fn, loc);
   if (fd_in_new < 0) {
      cpp_error (fd_err, t, "can not open file: ", fn);
      rc = 0;
   } else {
      rc = cpp_parse (fd_in_new, fd_out, fd_err, tn, ml, st, pl);
   }
   close (fd_in_new);
   Token_Destroy (tn);

   write_line (fd_out, t);
   GetSymNoSpace (fd_in, t);
   return rc;
}


/**
 * \brief parse a define statement
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \return
 *****************************************************************************/
int
define_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st) {
   char id[256];
   int r;
   char buf[1024];
#ifdef DEBUG
   put_string (fd_err, "define_Statement()\n");
#endif
   GetSymNoSpace (fd_in, t);

   if (t->sym == SYM_IDENT) {
#ifdef DEBUG
      put_two_string_nl (fd_err,"define_Statement(1) SYM_IDENT: ", t->id);
#endif
      strcpy (id, t->id);
      GetSymNoSpace (fd_in, t);
      while (t->sym == SYM_COMMENT) GetSymNoSpace (fd_in, t);
#ifdef DEBUG
      put_two_string_nl (fd_err,"define_Statement(2) SYM_IDENT: ", t->id);
#endif

      if (t->sym == SYM_IDENT) {
         if (ML_Add (ml, id, t->id) < 0)
            cpp_error (fd_err, t, "identifier already defined: ", t->id);
         GetSymNoSpace (fd_in, t);
         return 1;
      }

      if (t->sym == SYM_LITERAL) {
//       char buf[1024];
         strcpy (buf, "\"");  strcat (buf, t->id);  strcat (buf, "\""); 
         if (ML_Add (ml, id, buf) < 0)
            cpp_error (fd_err, t, "identifier already defined: ", id);
         GetSymNoSpace (fd_in, t);
         return 1;
      }

      if (t->sym == SYM_CHARACTER) {
         if (ML_Add (ml, id, t->id) < 0)
            cpp_error (fd_err, t, "identifier already defined: ", t->id);
         GetSymNoSpace (fd_in, t);
         return 1;
      }

      if (t->sym != SYM_NEWLINE) {
//       int r;
//       char buf[30];
         r = simple_Expression (fd_in, fd_out, fd_err, t, ml, st);
#ifdef DEBUG
         Calc_Dump (st, fd_err);
#endif
         strcpy (t->id, int_to_str (buf, 30, 10, Calc_Pop (st)));
         if (!r) {
            cpp_error (fd_err, t, "calculator error: ", t->id);
            GetSymNoSpace (fd_in, t);
            return 0;
         }
      } else {
         t->id[0] = '\0';
         put_string (fd_out, "\n");
      }

#ifdef DEBUG
      cpp_info (fd_err, t, "### id=", id);
      cpp_info (fd_err, t, "### id=", t->id);
#endif
      if (ML_Add (ml, id, t->id) < 0)
         cpp_error (fd_err, t, "identifier already defined: ", t->id);
      GetSymNoSpace (fd_in, t);
      return 1;
   }

   cpp_error (fd_err, t, "unexpected identifier: ", t->id);
   return 0;
}


/**
 * \brief parse a undef statement
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \return
 *****************************************************************************/
int
undef_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st) {
#ifdef DEBUG
   put_string (fd_err, "undef_Statement()\n");
#endif

   GetSymNoSpace (fd_in, t);

   if (t->sym == SYM_IDENT) {
      if (ML_Remove (ml, t->id) < 0)
         cpp_error (fd_err, t, "identifier not defined yet: ", t->id);
      GetSymNoSpace (fd_in, t);
      return 1;
   }

   cpp_error (fd_err, t, "identifier expected.", "");
   return 0;
}


/**
 * \brief parse a defined statement
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \return
 *****************************************************************************/
int
defined_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st) {
#ifdef DEBUG
   put_string (fd_err, "defined_Statement()\n");
#endif

   if (t->sym == SYM_IDENT) {
#ifdef DEBUG
      put_two_string_nl (fd_err,"### defined_Statement() SYM_IDENT: ", t->id);
#endif
      Calc_Push (st, ML_Get (ml, t->id) != 0);
      GetSymNoSpace (fd_in, t);
      return 1;
   }

   cpp_error (fd_err, t, "missing identifier: ", "");
   return 0;
}


/**
 * \brief parse a if statement
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \return
 *****************************************************************************/
int
if_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st) {
   int rc;
   int ok;
#ifdef DEBUG
   put_string (fd_err, "if_Statement()\n");
#endif

   GetSymNoSpace (fd_in, t);

   rc = logical_Or_Expression (fd_in, fd_out, fd_err, t, ml, st);

#ifdef DEBUG
   Calc_Dump (st, fd_err);
#endif

   if (!Calc_Pop(st)) {
      Calc_Push (st, 0);
      ok = 1;
      while (ok) {
         GetSymNoSpace (fd_in, t);
         if (t->stat <= 0) break;
         if (t->sym == SYM_NEWLINE)                { ok = 2; continue; }
         if (ok == 2 && t->sym == SYM_NUMBER_SIGN) { ok = 3; continue; }
         if (ok == 3 && t->sym == SYM_IDENT) {
            if (!strcmp (t->id, "if"))      if_Statement (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "ifdef"))   ifdef_Statement (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "ifndef"))  ifndef_Statement (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "elsif"))   return elsif_Statement (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "else"))    return else_Statement (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "endif"))   return endif_Statement (fd_in, fd_out, fd_err, t, ml, st);
         }
         ok = 1;
      }
   }

   Calc_Push (st, 1);
   return rc;
}


/**
 * \brief parse a ifdef statement
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \return
 *****************************************************************************/
int
ifdef_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st) {
   int ok;
#ifdef DEBUG
   put_string (fd_err, "ifdef_Statement()\n");
#endif

   GetSymNoSpace (fd_in, t);

   if (t->sym == SYM_IDENT) {
#ifdef DEBUG
      put_two_string_nl (fd_err,"SYM_IDENT: ", t->id);
#endif
      if (ML_Get (ml, t->id)) {
         Calc_Push (st, 1);
         GetSymNoSpace (fd_in, t);
         return 1;
      }

      Calc_Push (st, 0);

      ok = 1;
      while (ok) {
         GetSymNoSpace (fd_in, t);
         if (t->stat <= 0) break;
         if (t->sym == SYM_NEWLINE)                { ok = 2; continue; }
         if (ok == 2 && t->sym == SYM_NUMBER_SIGN) { ok = 3; continue; }
         if (ok == 3 && t->sym == SYM_IDENT) {
            if (!strcmp (t->id, "if"))      if_Statement (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "ifdef"))   ifdef_Statement (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "ifndef"))  ifndef_Statement (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "elsif"))   return elsif_Statement   (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "else"))    return else_Statement    (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "endif"))   return endif_Statement   (fd_in, fd_out, fd_err, t, ml, st);
         }
         ok = 1;
      }

      cpp_error (fd_err, t, "'endif' missing.", "");
      return 1;
   }

   cpp_error (fd_err, t, "missing identifier: ", "");
   return 0;
}


/**
 * \brief parse a ifndef statement
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token
 * \param ml the macro list
 * \param st the calculator stack
 * \return
 *****************************************************************************/
int
ifndef_Statement (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st) {
   int ok;
#ifdef DEBUG
   put_string (fd_err, "ifndef_Statement()\n");
#endif

   GetSymNoSpace (fd_in, t);

   if (t->sym == SYM_IDENT) {
#ifdef DEBUG
      put_two_string_nl (fd_err,"SYM_IDENT: ", t->id);
#endif
      if (!ML_Get (ml, t->id)) {
         Calc_Push (st, 1);
         GetSymNoSpace (fd_in, t);
         return 1;
      }

      Calc_Push (st, 0);
      ok = 1;
      while (ok) {
         GetSymNoSpace (fd_in, t);
         if (t->stat <= 0) break;
         if (t->sym == SYM_NEWLINE)                { ok = 2; continue; }
         if (ok == 2 && t->sym == SYM_NUMBER_SIGN) { ok = 3; continue; }
         if (ok == 3 && t->sym == SYM_IDENT) {
            if (!strcmp (t->id, "if"))      if_Statement (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "ifdef"))   ifdef_Statement (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "ifndef"))  ifndef_Statement (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "elsif"))   return elsif_Statement   (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "else"))    return else_Statement    (fd_in, fd_out, fd_err, t, ml, st);
            if (!strcmp (t->id, "endif"))   return endif_Statement   (fd_in, fd_out, fd_err, t, ml, st);
         }
         ok = 1;
      }

      cpp_error (fd_err, t, "'endif' missing.", "");
      return 1;
   }

   cpp_error (fd_err, t, "missing identifier: ", "");
   return 0;
}



/**
 * \brief parse a pre-processor line
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token 
 * \param ml the macro list
 * \param st the calculator stack
 * \param pl include path list
 * \return 
 *****************************************************************************/
int
PreProcLine (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st, struct _include_path* pl) {
   int rc; rc = 0;

#ifdef DEBUG
   put_string (fd_err, "PreProcLine()\n");
#endif

   GetSymNoSpace (fd_in, t);

   if (t->sym == SYM_IDENT) {
#ifdef DEBUG
      put_two_string_nl (fd_err,"### PreProcLine() SYM_IDENT: ", t->id);
#endif

      if (!strcmp (t->id, "include")) return include_Statement (fd_in, fd_out, fd_err, t, ml, st, pl);
      if (!strcmp (t->id, "define"))  return define_Statement  (fd_in, fd_out, fd_err, t, ml, st);
      if (!strcmp (t->id, "undef"))   return undef_Statement   (fd_in, fd_out, fd_err, t, ml, st);
      if (!strcmp (t->id, "if"))      return if_Statement      (fd_in, fd_out, fd_err, t, ml, st);
      if (!strcmp (t->id, "ifdef"))   return ifdef_Statement   (fd_in, fd_out, fd_err, t, ml, st);
      if (!strcmp (t->id, "ifndef"))  return ifndef_Statement  (fd_in, fd_out, fd_err, t, ml, st);
      if (!strcmp (t->id, "elsif"))   return elsif_Statement   (fd_in, fd_out, fd_err, t, ml, st);
      if (!strcmp (t->id, "else"))    return else_Statement    (fd_in, fd_out, fd_err, t, ml, st);
      if (!strcmp (t->id, "endif"))   return endif_Statement   (fd_in, fd_out, fd_err, t, ml, st);
   }

   cpp_error (fd_err, t, "unexpected identifier: ", t->id);
   return 0;
}


/**
 * \brief the C pre-processor parser
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \param t the current token 
 * \param ml the macro list
 * \param st the calculator stack
 * \param pl include path list
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
cpp_parse (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st, struct _include_path* pl) {
   int rc; int st_len;
   char *s; char n;
#ifdef DEBUG
   char buf[100];
#endif
   rc = 1;

   st_len = Calc_Stack_Length (st);

   while ( t->stat > 0 ) {
      GetSym (fd_in, t);

      if (t->sym == SYM_NEWLINE) {
         if (t->line == 1)  write_line (fd_out, t);

         while (t->stat > 0 && t->sym == SYM_NEWLINE) {
            put_string (fd_out, t->id);
#ifdef DEBUG
            put_string (STDERR_FILENO, "SYM_NEWLINE: ");
            put_string (STDERR_FILENO, int_to_str (buf, 100, 10, (int)t->id[0]));
            put_three_string_nl (STDERR_FILENO, " (#", 
                   int_to_str (buf, 100, 10, t->line), ")");
#endif
            GetSym (fd_in, t);
            while (t->sym == SYM_SPACE || t->sym == SYM_NEWLINE) {
               put_string (fd_out, t->id);
               GetSym (fd_in, t);
            }
#ifdef DEBUG
            put_two_string_nl (STDERR_FILENO, "After SYM_NEWLINE: sym=",
                                              sym_to_string(t->sym));
#endif
            while (t->sym == SYM_NUMBER_SIGN) {
#ifdef DEBUG
               put_string (STDERR_FILENO, "\nline: ");
               put_int (STDERR_FILENO, t->line);
               put_two_string_nl (STDERR_FILENO, "\nSYM_NUMBER_SIGN: ", t->id);
#endif
               if (!PreProcLine (fd_in, fd_out, fd_err, t, ml, st, pl)) rc=0;
            }
         }
      }

      if (t->sym == SYM_IDENT) {
#ifdef DEBUG
         put_two_string_nl (fd_err,"SYM_IDENT: ", t->id);
#endif
         if (!strcmp (t->id, "__LINE__"))  put_int (fd_out, t->line);
         else
         if (!strcmp (t->id, "__FILE__"))  put_string (fd_out, t->file);
         else {
            s = ML_Get (ml, t->id);
            if (s) {
               put_string (fd_out, s);
            } else {
               put_string (fd_out, t->id);
#ifdef DEBUG
               put_two_string_nl (fd_err,"Unknown macro: ", t->id);
#endif
            }
         }
         continue;
      } 

      if (t->sym == SYM_COMMENT) {
         s = t->id;
         n = '\n';
         while ( (s = index (s,(int)('\n'))) ) { s=s+1; write (fd_out, (void*)&n, 1); }
      } else {
         if (t->sym == SYM_LITERAL) put_string (fd_out, "\"");
         put_string (fd_out, t->id);
         if (t->sym == SYM_LITERAL) put_string (fd_out, "\"");
      }
   }

   if (Calc_Stack_Length (st) != st_len) {
      cpp_error (fd_err, t, "'endif' missing.", "");
      Calc_Pop (st);
      rc = 0;
   }

   return rc;
}

