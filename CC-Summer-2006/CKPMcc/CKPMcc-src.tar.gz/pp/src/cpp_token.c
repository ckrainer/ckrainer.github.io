/**
 * \file cpp_token.c
 * \brief CKPM C pre-processor token handling
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <stdlib.h>
#include <string.h>

#include "cpp_scan.h"
#include "cpp_token.h"


/**
 * \brief initialise a variable of struct _token
 * \param file_name the current scanned file name
 * \return the pointer to a struct _token variable
 *****************************************************************************/

struct _token*
Token_Create (char *file_name) {
   struct _token* t;
   t = (struct _token*) malloc (sizeof(struct _token));
   t->stat = 1;
   t->sym = SYM_NEWLINE;
   t->line = 0;
   t->num = 0;
   t->file = strdup (file_name);
   t->ch = '\n';
   t->id[0] = '\n';
   t->id[1] = '\0';
   return t;
}


/**
 * \brief destroy a variable of struct _token
 * \param t the pointer to a struct _token variable
 *****************************************************************************/

void
Token_Destroy (struct _token* t) {
   free ((void*)t->file);
   free ((void*)t);
}


/**
 * \brief duplicate a token
 * \param t the pointer to a struct _token variable
 * \return the pointer to the clone
 *****************************************************************************/

struct _token*
Token_Clone (struct _token* t) {
   struct _token* c;
   c = (struct _token*) malloc (sizeof(struct _token));
   c->stat = t->stat;
   c->sym  = t->sym;
   c->line = t->line;
   c->num  = t->num;
   c->file = strdup (t->file);
   c->ch   = t->ch;
   strcpy (c->id, t->id);
   return c;
}


/**
 * \brief compare two tokens
 * \param t1 the pointer to the first token
 * \param t2 the pointer to the first token
 * \return 1 on equal, otherwise 0
 *****************************************************************************/

int
Token_Equals (struct _token* t1, struct _token* t2) {
   int rc;
   if (
      t1->stat == t2->stat         && t1->sym == t2->sym &&
      t1->line == t2->line         && t1->num == t2->num &&
      !strcmp (t1->file, t2->file) && t1->ch  == t2->ch  &&
      !strcmp (t1->id, t2->id)
   ) return 1;
   return 0;
}

