/**
 * \file cpp_path_test.c
 * \brief CKPM C pre-processor include path routines tester
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "cpp_test.h"
#include "cpp_path.h"


/**
 * \brief run the include path routines tests
 * \return 0 on success, != 0 otherwise
 *****************************************************************************/

int
cpp_path_test () {
    int ok = 0;
    int fail = 0;
    int fd,r;

    struct _include_path* p = Path_Create();
    CHK_RESULT     ("Path_Add(1)", p->len, 0);
    r= Path_Add (p, "/usr/include");
    CHK_RESULT     ("Path_Add(2)", p->len, 1);
    r= Path_Add (p, "/usr/local/include");
    CHK_RESULT     ("Path_Add(3)", p->len, 2);
    r= Path_Add (p, "/opt/freeware/include");
    CHK_RESULT     ("Path_Add(4)", p->len, 3);
    r= Path_Add (p, ".");
    CHK_RESULT     ("Path_Add(5)", p->len, 4);
    r= Path_Add (p, "..");
    CHK_RESULT     ("Path_Add(6)", p->len, 5);

//  Path_Dump (p, STDOUT_FILENO);

    CHK_RESULT_STR ("Path_Add(7)", p->dirs[0], "/usr/include")
    CHK_RESULT_STR ("Path_Add(8)", p->dirs[1], "/usr/local/include")
    CHK_RESULT_STR ("Path_Add(9)", p->dirs[2], "/opt/freeware/include")
    CHK_RESULT_STR ("Path_Add(10)", p->dirs[3], ".")
    CHK_RESULT_STR ("Path_Add(11)", p->dirs[4], "..")
    CHK_RESULT     ("Path_Add(12)", p->len, 5);
//  Path_Dump (p, STDOUT_FILENO);

    r = Path_Remove (p, ".");
    CHK_RESULT     ("Path_Remove(1)", r, 4);
//  Path_Dump (p, STDOUT_FILENO);
    r = Path_Remove (p, "..");
    CHK_RESULT     ("Path_Remove(2)", r, 3);
//  Path_Dump (p, STDOUT_FILENO);

    r = Path_Remove (p, "/usr");
    CHK_RESULT     ("Path_Remove(3)", r, -1);
//  Path_Dump (p, STDOUT_FILENO);

    fd = Path_Search_And_Open (p, "cpp_path.h", 1);
    CHK_RESULT     ("Path_Search_And_Open(1)", (fd < 0), 1)

    r= Path_Add (p, "..");
    CHK_RESULT_STR ("Path_Add(13)", p->dirs[3], "..")
    CHK_RESULT     ("Path_Add(14)", p->len, 4)

    fd = Path_Search_And_Open (p, "cpp_path.h", 0);
    CHK_RESULT     ("Path_Search_And_Open(2)", (fd > 0), 1)
    
    CHK_RESULT     ("Path_Index (1)", Path_Index (p, "/opt/freeware/include"), 2);
    CHK_RESULT     ("Path_Index (2)", Path_Index (p, "/opt/freeware"), -1);

    Path_Destroy (p);

    printf ("%d subtests total, %d ok, %d failed\n", ok+fail, ok, fail);

    return fail;
}
