/**
 * \file cpp_conv_test.c
 * \brief CKPM C pre-processor converting routines tester
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cpp_test.h"
#include "cpp_conv.h"


/**
 * \brief run the converting routines tests
 * \return 0 on success, != 0 otherwise
 *****************************************************************************/

int
cpp_conv_test () {
    int ok = 0;
    int fail = 0;
    char buf[100];


    CHK_RESULT_STR ("int_to_str( 8)", int_to_str(buf,100, 8, 668), "1234")
    CHK_RESULT_STR ("int_to_str(10)", int_to_str(buf,100,10,   0),    "0")
    CHK_RESULT_STR ("int_to_str(10)", int_to_str(buf,100,10,1234), "1234")
    CHK_RESULT_STR ("int_to_str(16)", int_to_str(buf,100,16,4660), "1234")
    CHK_RESULT_STR ("int_to_str(16)", int_to_str(buf,100,16,   9), "9")
    CHK_RESULT_STR ("int_to_str(16)", int_to_str(buf,100,16,  10), "A")
    CHK_RESULT_STR ("int_to_str(16)", int_to_str(buf,100,16,  11), "B")
    CHK_RESULT_STR ("int_to_str(16)", int_to_str(buf,100,16,  12), "C")
    CHK_RESULT_STR ("int_to_str(16)", int_to_str(buf,100,16,  13), "D")
    CHK_RESULT_STR ("int_to_str(16)", int_to_str(buf,100,16,  14), "E")
    CHK_RESULT_STR ("int_to_str(16)", int_to_str(buf,100,16,  15), "F")
    CHK_RESULT_STR ("int_to_str(16)", int_to_str(buf,100,16,  16), "10")

    CHK_RESULT ("dec_string_to_int( 1)", dec_string_to_int("1234"), 1234)

    CHK_RESULT ("oct_string_to_int( 1)", oct_string_to_int("1234"), 668)
    CHK_RESULT ("oct_string_to_int( 2)", oct_string_to_int("01234"), 668)

    CHK_RESULT ("hex_string_to_int( 1)", hex_string_to_int("1234"), 4660)
    CHK_RESULT ("hex_string_to_int( 2)", hex_string_to_int("0x1234"), 4660)
    CHK_RESULT ("hex_string_to_int( 3)", hex_string_to_int("0x4"), 4)
    CHK_RESULT ("hex_string_to_int( 4)", hex_string_to_int("0x00000001"),  1)
    CHK_RESULT ("hex_string_to_int( 4)", hex_string_to_int("0x00000009"),  9)
    CHK_RESULT ("hex_string_to_int( 4)", hex_string_to_int("0x0000000A"), 10)
    CHK_RESULT ("hex_string_to_int( 4)", hex_string_to_int("0x0000000B"), 11)
    CHK_RESULT ("hex_string_to_int( 4)", hex_string_to_int("0x0000000C"), 12)
    CHK_RESULT ("hex_string_to_int( 4)", hex_string_to_int("0x0000000D"), 13)
    CHK_RESULT ("hex_string_to_int( 4)", hex_string_to_int("0x0000000E"), 14)
    CHK_RESULT ("hex_string_to_int( 4)", hex_string_to_int("0x0000000F"), 15)
    CHK_RESULT ("hex_string_to_int( 4)", hex_string_to_int("0x0000001A"), 26)


    printf ("%d subtests total, %d ok, %d failed\n", ok+fail, ok, fail);

    return fail;
}
