#!/bin/sh
#
# @(#) cpp_test.sh - run the pre-processor test scripts.
#

PP=${CKPMPP-../CKPMpp}
CPP_TEST=${CPP_TEST-./cpp_test}
CPP_FLAGS=${CPP_FLAGS-'-I ..'}
TMP=/tmp/cpp_test.1.$$;
OUT=/tmp/cpp_test.2.$$;

trap "rm -f $TMP $OUT;" 0 1 2 15

die () { echo "$*"; exit 1; }

[ ! -x "$PP" ] && die "Can not find pre-processor executable. Aborting.";

[ "$*" = "" ] && die "Usage: $(basename $0) test1 [test2] [test3] ...";

rc=0;
{
$CPP_TEST

for f in $*; do
   fo=${f/.src}.out;
   fe=${f/.src}.err;
   err=0;
   echo
   echo "Running tests $f";
   if $PP $CPP_FLAGS --in $f --out $TMP > $OUT 2>&1
   then
      echo "Preprocessor succeeded."
      err=$(grep '^ERROR: ' $OUT | wc -l);
      [ ! -f "$fe" -a "$err" -ne 0 ] && cat $OUT;
   else
      cat $OUT;
      echo "Preprocessor failed."
      [ ! -f "$fo" ] && echo "test\n\nerror" >> $TMP;
      rc=1;
   fi

   if [ ! -f "$fo" ]
   then
      awk '
         { p=1; }
         $1 == "test"  { p=0; n++; printf ("test #%02d (line %3d) ... ",n,NR); }
         $1 == "ok"    { p=0; o++; print "ok."; }
         $1 == "error" { p=0; e++; print "error."; }
         /# [0-9][0-9]* ".*"/ { p=0; }
         /^$/          { p=0; }
                       { if (p) { u++; print "unexpected line (" NR "): \"" $0 "\""; } }
         END {
            printf("%d subtests total, %d ok, %d errors, %d unexpected lines\n",n,o,e,u);
            exit (e?1:0);
         }' < $TMP || rc=1;
   else
      ok=0;
      loc=$(grep '[;{]' $TMP | wc -l)
      [ "$loc" -eq 0 ] && loc=1;
      diff $TMP $fo && ok=$loc || rc=1;
      if [ -f "$fe" ]
      then
         grep '^ERROR: ' $OUT > $TMP;
         echo -n "Expecting "$(wc -l < $fe)" lines with errors for file '$f' ... ";
         diff $TMP $fe && { ok=1; err=0; } || rc=1;
         [ "$err" -eq 0 ] && echo "ok" || echo "failed";
      else
         err=$( { diff $TMP $fo; grep '^ERROR: ' $OUT; } | wc -l)
      fi
      printf "%d subtests total, %d ok, %d errors\n" $loc $ok $err;
   fi

done
} | awk '
      {print;}
      /subtests total/ { t=t+$1; o=o+$4; e=e+$6; u=u+$8; }
      END {
            printf("\nSummary:  %d tests total, %d ok, %d errors, %d unexpected lines\n",t,o,e,u);
            exit (e+u?1:0);
      }' || rc=1;


[ "$rc" -eq 0 ] \
   && echo "All tests succeeded." \
   || echo "Tests failed, see above for details.";

exit $rc;
