/**
 * \file cpp_calc_test.c
 * \brief CKPM C pre-processor stack based calculator tester
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cpp_test.h"
#include "cpp_calc.h"


/**
 * \brief test the stack based calculator
 * \return 0 if successful, 1 otherwise
 *****************************************************************************/

int
cpp_calc_test () {
    int ok = 0;
    int fail = 0;

    struct _calc* s;
    s = Calc_Create ();
    Calc_Push (s, 3);
    Calc_Push (s, 4);
    Calc_Add (s);
    CHK_RESULT ("Calc_Add", Calc_Pop(s), 7)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);
       
    s = Calc_Create ();
    Calc_Push (s, 3);
    Calc_Push (s, 4);
    Calc_Subtract (s);
    CHK_RESULT ("Calc_Subtract", Calc_Pop(s), -1)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    s = Calc_Create ();
    Calc_Push (s, 3);
    Calc_Push (s, 4);
    Calc_Multiply (s);
    CHK_RESULT ("Calc_Multiply", Calc_Pop(s), 12)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    s = Calc_Create ();
    Calc_Push (s,12);
    Calc_Push (s, 4);
    Calc_Divide (s);
    CHK_RESULT ("Calc_Divide", Calc_Pop(s), 3)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    s = Calc_Create ();
    Calc_Push (s, 0);
    Calc_Push (s, 0);
    Calc_And (s);
    CHK_RESULT ("Calc_And", Calc_Pop(s), 0)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    s = Calc_Create ();
    Calc_Push (s, 1);
    Calc_Push (s, 0);
    Calc_And (s);
    CHK_RESULT ("Calc_And", Calc_Pop(s), 0)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    s = Calc_Create ();
    Calc_Push (s, 0);
    Calc_Push (s, 1);
    Calc_And (s);
    CHK_RESULT ("Calc_And", Calc_Pop(s), 0)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    s = Calc_Create ();
    Calc_Push (s, 1);
    Calc_Push (s, 1);
    Calc_And (s);
    CHK_RESULT ("Calc_And", Calc_Pop(s), 1)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    s = Calc_Create ();
    Calc_Push (s, 0);
    Calc_Push (s, 0);
    Calc_Or (s);
    CHK_RESULT ("Calc_Or", Calc_Pop(s), 0)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    s = Calc_Create ();
    Calc_Push (s, 1);
    Calc_Push (s, 0);
    Calc_Or (s);
    CHK_RESULT ("Calc_Or", Calc_Pop(s), 1)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    s = Calc_Create ();
    Calc_Push (s, 0);
    Calc_Push (s, 1);
    Calc_Or (s);
    CHK_RESULT ("Calc_Or", Calc_Pop(s), 1)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    s = Calc_Create ();
    Calc_Push (s, 1);
    Calc_Push (s, 1);
    Calc_Or (s);
    CHK_RESULT ("Calc_Or", Calc_Pop(s), 1)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    s = Calc_Create ();
    Calc_Push (s, 3);
    Calc_Not (s);
    CHK_RESULT ("Calc_Not", Calc_Pop(s), 0)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    s = Calc_Create ();
    Calc_Push (s, 0);
    Calc_Not (s);
    CHK_RESULT ("Calc_Not", Calc_Pop(s), 1)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);


    s = Calc_Create ();
    Calc_Push (s, 128);
    Calc_Push (s, 4);
    Calc_Shift_Left (s);
    CHK_RESULT ("Calc_Shift_Left", Calc_Pop(s), 2048)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    s = Calc_Create ();
    Calc_Push (s, 128);
    Calc_Push (s, 4);
    Calc_Shift_Right (s);
    CHK_RESULT ("Calc_Shift_Left", Calc_Pop(s), 8)
    CHK_RESULT ("Status Ok", s->status, STACK_STATUS_OK)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    s = Calc_Create ();
    Calc_Pop (s);
    CHK_RESULT ("Status Underflow", s->status, STACK_STATUS_UNDERFLOW)
    CHK_RESULT ("SP", s->sp, -1)
    Calc_Destroy (s);

    printf ("%d subtests total, %d ok, %d failed\n", ok+fail, ok, fail);

    return fail;
}
