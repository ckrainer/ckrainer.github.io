/**
 * \file cpp_scan.h
 * \brief CKPM C pre-processor scanner definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef	_CKPM_CPP_SCAN_H_
#define	_CKPM_CPP_SCAN_H_

#include "cpp_token.h"


#define	SYM_LEFT_PAREN  	3	/*!< '('  left parenthesis symbol */
#define	SYM_LEFT_BRACK  	4	/*!< '['  left bracket symbol */
#define	SYM_LEFT_BRACE  	5	/*!< '{'  left brace symbol */
#define	SYM_LEFT_ANGLE_BRACK	6	/*!< '<'  left angle bracket */
#define	SYM_LEFT_SHIFT		7	/*!< '<<' left shift symbol */
#define	SYM_BAR         	8	/*!< '|'  bar symbol */
#define	SYM_EQUAL       	9	/*!< '='  equal symbol */
#define	SYM_RIGHT_PAREN 	10	/*!< ')'  right parenthesis symbol */
#define	SYM_RIGHT_BRACK 	11	/*!< ']'  right bracket symbol */
#define	SYM_RIGHT_BRACE 	12	/*!< '}'  right brace symbol */
#define	SYM_RIGHT_ANGLE_BRACK	13	/*!< '>'  right angle bracket */
#define	SYM_RIGHT_SHIFT		14	/*!< '>>' right shift symbol */
#define	SYM_PERIOD      	15	/*!< '.'  period symbol */
#define	SYM_NUMBER_SIGN		18	/*!< '#'  number sign */
#define	SYM_DIVIDE		24	/*!< '/'  arithmetic division */
#define	SYM_REMINDER		25	/*!< '\%'  reminder of an integer division */
#define	SYM_SPACE		26	/*!< ' '  white space or tabulator */
#define	SYM_PLUS		27	/*!< '+'  positive sign / addition */
#define	SYM_MINUS		28	/*!< '-'  negative sign / subtraction */
#define	SYM_ASTERISK		29	/*!< '*'  multiplication */
#define	SYM_EXCLAMATION_MARK	30	/*!< '!'  exclamation mark */
#define	SYM_LOGICAL_OR		31	/*!< '||' logical or operator */
#define	SYM_LOGICAL_AND		32	/*!< '&&' logical and operator */
#define	SYM_AMPERSAND		33	/*!< '&'  ampersand symbol */
#define	SYM_CMP_EQ		34	/*!< '==' comparison equal symbol */
#define	SYM_CMP_NEQ		35	/*!< '!=' comparison not equal symbol */
#define	SYM_CMP_GE		36	/*!< '>=' comparison greater or equal */
#define	SYM_CMP_LE		37	/*!< '<=' comparison lower or equal */
#define	SYM_COLON		38	/*!< ':'  colon */
#define	SYM_SEMICOLON		39	/*!< ';'  semi colon */
#define	SYM_COMMA		40	/*!< ','  comma */

#define	SYM_COMMENT     	100	/*!< comment symbol */
#define	SYM_NEWLINE		101	/*!< newline symbol */
#define	SYM_NUMBER		102	/*!< decimal number */
#define	SYM_OCT_NUMBER		103	/*!< octal number */
#define	SYM_HEX_NUMBER		104	/*!< hexa decimal number */
#define	SYM_IDENT       	105	/*!< identifier symbol */
#define	SYM_LITERAL     	106	/*!< string literal symbol */
#define	SYM_CHARACTER		107	/*!< a single character */

#define	SYM_INCLUDE		200	/*!< include symbol */
#define	SYM_DEFINE		201	/*!< define symbol */
#define	SYM_DEFINED		202	/*!< defined symbol */
#define	SYM_IF			203	/*!< if symbol */
#define	SYM_IFDEF		204	/*!< ifdef symbol */
#define	SYM_ELSIF		205	/*!< elsif symbol */
#define	SYM_ELSE		206	/*!< else symbol */
#define	SYM_ENDIF		207	/*!< endif symbol */
#define	SYM_UNDEF		208	/*!< undef symbol */

#define	SYM_OTHER       	1000	/*!< other symbol */

/*
 * forward declarations
 */
void GetSymNoSpace (int fd, struct _token* t);
void GetSym (int fd, struct _token* t);
char* sym_to_string (int sym);

#endif /* _CKPM_CPP_SCAN_H_ */

