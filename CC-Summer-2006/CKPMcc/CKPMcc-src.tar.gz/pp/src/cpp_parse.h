/**
 * \file cpp_parse.h
 * \brief CKPM C pre-processor parser definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef	_CKPM_CPP_PARSE_H_
#define	_CKPM_CPP_PARSE_H_

#include "cpp_token.h"
#include "cpp_calc.h"
#include "cpp_macros.h"

/*
 * forward declarations
 */
int cpp_parse (int fd_in, int fd_out, int fd_err, struct _token* t, struct _macro_list* ml, struct _calc* st, struct _include_path* pl);
int cpp_error (int fd_err, struct _token*t, char* s1, char* s2);
int cpp_warning (int fd_err, struct _token*t, char* s1, char* s2);
int cpp_info (int fd_err, struct _token*t, char* s1, char* s2);

#endif /* _CKPM_CPP_PARSE_H_ */

