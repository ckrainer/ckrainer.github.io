/**
 * \file cpp_macros.h
 * \brief CKPM C pre-processor macro definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef	_CKPM_CPP_MACROS_H_
#define	_CKPM_CPP_MACROS_H_


/**
 * \struct _macro
 * \brief This structure contains one macro
 */
struct _macro {
   char    *id;				/*!< macro identifier */
   char    *val;			/*!< macro value */
};

#define	MAX_MACROS	1024		/*!< maximum number of allowed macros */

/**
 * \struct _macro_list
 * \brief This structure contains the parsed macros
 */
struct _macro_list {
   int     len;				/*!< number of macros in this list */
   struct  _macro m[MAX_MACROS];	/*!< array with parsed macros */
};


/*
 * forward declarations
 */
struct _macro_list* ML_Create ();
void ML_Destroy (struct _macro_list* l);
void ML_Dump (int fd, struct _macro_list* l);
int ML_Add (struct _macro_list* l, char *id, char *val);
int ML_Remove (struct _macro_list* l, char *id);
char* ML_Get (struct _macro_list* l, char *id);
int ML_Index (struct _macro_list* l, char *id);

#endif /* _CKPM_CPP_MACROS_H_ */

