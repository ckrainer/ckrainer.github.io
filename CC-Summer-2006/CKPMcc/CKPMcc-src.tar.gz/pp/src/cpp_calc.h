/**
 * \file cpp_calc.h
 * \brief CKPM C pre-processor calc based calculator definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef	_CKPM_CPP_CALC_H_
#define	_CKPM_CPP_CALC_H_

#define	MAX_STACK_LENGTH	40	/*!< maximal length of the calc */

#define STACK_STATUS_OK		0	/*!< calc calculation succeeded */
#define STACK_STATUS_UNDERFLOW	1	/*!< calc calculation failed */
#define STACK_STATUS_OVERFLOW	2	/*!< calc is too small */

/**
 * \struct _calc
 * \brief This structure describes the calculator calc
 */
struct _calc {
   int     status;			/*!< calc status */
   int     sp;				/*!< stack pointer */
   int     val[MAX_STACK_LENGTH];	/*!< scanned symbol */
};


struct _calc* Calc_Create ();
void Calc_Destroy (struct _calc* s);
void Calc_Dump ( struct _calc* s, int fd);

void Calc_Push (struct _calc* s, int n);
int Calc_Pop (struct _calc* s);
void Calc_Dup (struct _calc* s);
int Calc_Stack_Length (struct _calc* s);

void Calc_Add (struct _calc* s);
void Calc_Subtract (struct _calc* s);
void Calc_Multiply (struct _calc* s);
void Calc_Divide (struct _calc* s);
void Calc_Rem (struct _calc* s);

void Calc_And (struct _calc* s);
void Calc_Or (struct _calc* s);
void Calc_Not (struct _calc* s);

void Calc_Shift_Left (struct _calc* s);
void Calc_Shift_Right (struct _calc* s);

void Calc_Cmp_EQ (struct _calc* s);
void Calc_Cmp_NEQ (struct _calc* s);
void Calc_Cmp_GE (struct _calc* s);
void Calc_Cmp_GT (struct _calc* s);
void Calc_Cmp_LE (struct _calc* s);
void Calc_Cmp_LT (struct _calc* s);


#endif /* _CKPM_CPP_CALC_H_ */

