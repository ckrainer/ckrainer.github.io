/**
 * \file cpp_calc.c
 * \brief CKPM C pre-processor stack based calculator
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <stdlib.h>

#include "cpp_io.h"
#include "cpp_conv.h"
#include "cpp_calc.h"



/**
 * \brief create and initialise a struct _calc
 * \return a pointer to a new stack
 *****************************************************************************/

struct _calc*
Calc_Create () {
   struct _calc* s;
   s = (struct _calc*) malloc (sizeof (struct _calc));
   s->sp = -1;
   s->status = STACK_STATUS_OK;
   return s;
}


/**
 * \brief destroy a variable of struct _calc
 * \param s the pointer to a struct _calc variable
 *****************************************************************************/

void
Calc_Destroy (struct _calc* s) {
   free ((void*)s);
}


/**
 * \brief dump the stack to stderr
 * \param fd the file descriptor index of the output file
 * \param s the pointer to a struct _calc variable
 *****************************************************************************/
void
Calc_Dump (struct _calc* s, int fd) {
   char buf [100];
   int i;
   put_string (fd, "Calc dump: sp=");
   put_string (fd, int_to_str (buf, 100, 10, s->sp));
   put_string (fd, ", status=");
   put_string (fd, int_to_str (buf, 100, 10, s->status));
   put_string (fd, "\n");
   i = s->sp;
   while (i >= 0) {
      put_string (fd, "[");
      if (i < 100) put_string (fd, " ");
      if (i <  10) put_string (fd, " ");
      put_string (fd, int_to_str (buf, 100, 10, i));
      put_string (fd, "]: ");
      put_string (fd, int_to_str (buf, 100, 10, s->val[i]));
      put_string (fd, "\n");
      i = i - 1;
   }
}


/**
 * \brief push a value onto the stack
 *****************************************************************************/

void
Calc_Push (struct _calc* s, int n) {
   s->sp = s ->sp + 1;
   if (s->sp > MAX_STACK_LENGTH) { s->status = STACK_STATUS_OVERFLOW; return; }
   s->val[s->sp] = n;
}


/**
 * \brief pop a value from the top of the stack
 * \return the value from top of the stack
 *****************************************************************************/

int
Calc_Pop (struct _calc* s) {
   int x;
   x = s->sp;
   if (s->sp < 0) { s->status = STACK_STATUS_UNDERFLOW; return 0; }
   s->sp = s->sp - 1;
   return s->val[x];
}


/**
 * \brief duplicate the value from the top of the stack
 *****************************************************************************/

void
Calc_Dup (struct _calc* s) {
   if (s->sp < 0) { s->status = STACK_STATUS_UNDERFLOW; return; }
   s->sp = s ->sp + 1;
   if (s->sp > MAX_STACK_LENGTH) { s->status = STACK_STATUS_OVERFLOW; return; }
   s->val[s->sp] = s->val[s->sp-1];
}


/**
 * \brief return the current length of the calculator stack
 *****************************************************************************/

int
Calc_Stack_Length (struct _calc* s) {
   return s->sp+1;
}


/**
 * \brief add the two top values on the stack and push the result onto the
 * stack
 *****************************************************************************/

void
Calc_Add (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   s->val[s->sp-1] = s->val[s->sp-1] + s->val[s->sp];
   s->sp = s->sp - 1;
}


/**
 * \brief subtract the two top values on the stack and push the result onto
 * the stack
 *****************************************************************************/

void
Calc_Subtract (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   s->val[s->sp-1] = s->val[s->sp-1] - s->val[s->sp];
   s->sp = s->sp - 1;
}


/**
 * \brief multiply the two top values on the stack and push the result onto
 * the stack
 *****************************************************************************/

void
Calc_Multiply (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   s->val[s->sp-1] = s->val[s->sp-1] * s->val[s->sp];
   s->sp = s->sp - 1;
}


/**
 * \brief divide the two top values on the stack and push the result onto the
 * stack
 *****************************************************************************/

void
Calc_Divide (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   s->val[s->sp-1] = s->val[s->sp-1] / s->val[s->sp];
   s->sp = s->sp - 1;
}


/**
 * \brief divide the two top values on the stack and push the reminder onto the
 * stack
 *****************************************************************************/

void
Calc_Rem (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   s->val[s->sp-1] = s->val[s->sp-1] % s->val[s->sp];
   s->sp = s->sp - 1;
}


/**
 * \brief do a logical and of the two top values on the stack and push the
 * result onto the stack
 *****************************************************************************/

void
Calc_And (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   s->val[s->sp-1] = s->val[s->sp-1] && s->val[s->sp];
   s->sp = s->sp - 1;
}


/**
 * \brief do a logical or of the two top values on the stack and push the result
 * onto the stack
 *****************************************************************************/

void
Calc_Or (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   s->val[s->sp-1] = s->val[s->sp-1] || s->val[s->sp];
   s->sp = s->sp - 1;
}


/**
 * \brief logically negate the top value on the stack and push the result onto
 * the stack
 *****************************************************************************/

void
Calc_Not (struct _calc* s) {
   if (s->sp < 0) { s->status = STACK_STATUS_UNDERFLOW; return; }
   s->val[s->sp] = ! s->val[s->sp];
}


/**
 * \brief shift the top but one value on the stack left by the top value of
 * the stack and push the result onto the stack
 *****************************************************************************/

void
Calc_Shift_Left (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   s->val[s->sp-1] = s->val[s->sp-1] << s->val[s->sp];
   s->sp = s->sp - 1;
}


/**
 * \brief add the two top values on the stack and push the result onto the stack
 *****************************************************************************/

void
Calc_Shift_Right (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   s->val[s->sp-1] = s->val[s->sp-1] >> s->val[s->sp];
   s->sp = s->sp - 1;
}


/**
 * \brief compare the two top values on the stack and push the result onto the stack
 *****************************************************************************/

void
Calc_Cmp_EQ (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   if (s->val[s->sp-1] == s->val[s->sp])   s->val[s->sp-1] = 1;
   else                                    s->val[s->sp-1] = 0;
   s->sp = s->sp - 1;
}


/**
 * \brief compare the two top values on the stack and push the result onto the stack
 *****************************************************************************/

void
Calc_Cmp_NEQ (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   if (s->val[s->sp-1] != s->val[s->sp])   s->val[s->sp-1] = 1;
   else                                    s->val[s->sp-1] = 0;
   s->sp = s->sp - 1;
}


/**
 * \brief compare the two top values on the stack and push the result onto the stack
 *****************************************************************************/

void
Calc_Cmp_GE (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   if (s->val[s->sp-1] >= s->val[s->sp])   s->val[s->sp-1] = 1;
   else                                    s->val[s->sp-1] = 0;
   s->sp = s->sp - 1;
}


/**
 * \brief compare the two top values on the stack and push the result onto the stack
 *****************************************************************************/

void
Calc_Cmp_GT (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   if (s->val[s->sp-1] > s->val[s->sp])   s->val[s->sp-1] = 1;
   else                                   s->val[s->sp-1] = 0;
   s->sp = s->sp - 1;
}


/**
 * \brief compare the two top values on the stack and push the result onto the stack
 *****************************************************************************/

void
Calc_Cmp_LE (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   if (s->val[s->sp-1] <= s->val[s->sp])   s->val[s->sp-1] = 1;
   else                                    s->val[s->sp-1] = 0;
   s->sp = s->sp - 1;
}


/**
 * \brief compare the two top values on the stack and push the result onto the stack
 *****************************************************************************/

void
Calc_Cmp_LT (struct _calc* s) {
   if (s->sp < 1) { s->status = STACK_STATUS_UNDERFLOW; return; }
   if (s->val[s->sp-1] < s->val[s->sp])   s->val[s->sp-1] = 1;
   else                                   s->val[s->sp-1] = 0;
   s->sp = s->sp - 1;
}

