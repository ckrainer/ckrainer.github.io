/**
 * \file cpp_conv.h
 * \brief CKPM C pre-processor convert routines definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef _CKPM_CPP_CONV_H_
#define _CKPM_CPP_CONV_H_

#include <sys/types.h>

char *int_to_str (char *buf, size_t len, int base, int n);
int dec_string_to_int (char * s);
int oct_string_to_int (char * s);
int hex_string_to_int (char * s);

#endif /* _CKPM_CPP_CONV_H_ */

