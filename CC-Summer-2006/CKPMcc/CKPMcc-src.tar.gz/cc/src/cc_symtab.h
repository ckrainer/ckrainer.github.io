/**
 * \file cc_symtab.h
 * \brief CKPM C compiler symbol table definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef _CKPM_CC_SYMTAB_H_
#define _CKPM_CC_SYMTAB_H_

#define	class_t		int		/*!< object type class */
#define	CLASS_HEAD	0		/*!< head class */
#define	CLASS_VAR	1		/*!< variable */
#define	CLASS_PARAM	2		/*!< parameter */
#define	CLASS_CONST	3		/*!< constant */
#define	CLASS_FIELD	4		/*!< field */
#define	CLASS_TYPE	5		/*!< type */
#define	CLASS_FUNC	6		/*!< function with implementation */
#define	CLASS_SFUNC	7		/*!< predefined function */
#define	CLASS_FUNC_PR	8		/*!< function prototype */
#define	CLASS_IND	9		/*!< indirect addressing (pointers) */
#define	CLASS_IND_DATA	10		/*!< indirect addressing (pointers) to data area */
#define CLASS_STACK	11		/*!< stack */
#define CLASS_COND	12		/*!< conditional */
#define	CLASS_VOID	13		/*!< void */
#define	CLASS_LINK	14		/*!< fixup links */

#define	type_t		int		/*!< object type */
#define	TYPE_UNKNOWN	0		/*!< unknown type */
#define	TYPE_INT	1		/*!< integer */
#define	TYPE_CHAR	2		/*!< character */
#define	TYPE_VOID	3		/*!< void */

#define form_t		int		/*!< form */
#define FORM_UNKNOWN	0		/*!< unknown form */
#define	FORM_VOID	1		/*!< void form */
#define	FORM_BOOLEAN	2		/*!< boolean form */
#define	FORM_CHAR	3		/*!< character form */
#define	FORM_INTEGER	4		/*!< integer form */
#define	FORM_ARRAY	5		/*!< array form */
#define	FORM_STRUCTURE	6		/*!< structure form */
#define	FORM_POINTER	7		/*!< pointer form */

#define	reg_t		int		/*!< register / addressing mode */
#define	REG_UNKNOWN	0		/*!< unknown addressing mode */
#define	REG_ABSOLUTE	1		/*!< direct addressing via program counter */
#define REG_FRAME	2		/*!< indirect addressing via frame pointer */
#define REG_STACK	3		/*!< indirect addressing via stack pointer */
#define	STACK_NONE	0		/*!< leave no values left on the stack */
#define	STACK_DUP	4		/*!< leave the result also on the stack */
#define	STACK_ONLY	5		/*!< leave the result on the stack only */


/**
 * \struct _object
 * \brief This structure contains one object description
 */
struct _object {
   char*           name;		/*!< the name of the object */
   class_t         cls;			/*!< the object type class */
   int             lev;			/*!< declaration level */
   struct _type*   type;		/*!< the object's type */
   int             val;			/*!< constants: value */
   struct _object* next;		/*!< the next object entry */
   struct _object* dsc;			/*!< more description objects */
};


/**
 * \struct _type
 * \brief This structure contains one type description
 */
struct _type {
   form_t          form;		/*!< the form of the type description */
   int             len;			/*!< the length */
   int             size;		/*!< the size of this type */
   struct _object* fields;		/*!< a pointer to the fields */
   struct _type*   base;		/*!< the base type of this description */
};


/**
 * \struct _item
 * \brief This structure contains one item description
 */
struct _item {
   class_t         mode;		/*!< the item's mode */
   int             lev;			/*!< the item's level */
   struct _type*   type;		/*!< the item's type */
   int             a;			/*!< the item's (true) address */
   int             b;			/*!< the item's false address */
   int             c;			/*!< the item's condition code */
   int             w;			/*!< if != 0 exists a surrounding while loop */
   reg_t           r;			/*!< the item's register / addressing mode */
};


/**
 * \struct _symtab
 * \brief This structure contains the symbol table
 */
struct _symtab {
   struct _object*	universe;	/*!< pointer to the root of the symbol table */
   struct _object*	topScope;	/*!< pointer to the top scope */
   struct _object*	guard;		/*!< universe and topScope end with guard */
   struct _type*	boolType;	/*!< predefined enumeration boolean */
   struct _type*	intType;	/*!< predefined type int   */
   struct _type*	charType;	/*!< predefined type char  */
   struct _type*	charPtrType;	/*!< predefined type char* */
   struct _type*	charPtrPtrType;	/*!< predefined type char** */
   struct _type*	voidType;	/*!< predefined type void  */
   struct _type*	voidPtrType;	/*!< predefined type void* */
};


/*
 * conversion functions
 */
char* ClassToString (class_t cls);
char* FormToString (form_t f);
char* TypeToString (type_t t);

/*
 * Object function declarations
 */
struct _object* Object_Create (char* name, class_t cls, int lev, struct _type* type,
   int val, struct _object* next, struct _object* dsc);
void Object_Destroy (struct _object* o);
void Object_Dump (struct _object* o, int lev, int fd, struct _object* en);

/*
 * Type function declarations
 */
struct _type* Type_Create (form_t f, int l, int s, struct _object* fs, struct _type* b);
void Type_Destroy (struct _type* t);
void Type_Dump (struct _type* t, int lev, int fd, struct _object* en);

/*
 * Item function declarations
 */
struct _item* Item_Create ();
void Item_Destroy (struct _item* i);
void Item_Copy (struct _item* d, struct _item* s);
void Item_Dump (struct _item* i, int fd);

/*
 * Symbol Table function declarations
 */
struct _symtab* SymTab_Create ();
void SymTab_Destroy (struct _symtab* st);
void OpenScope (struct _symtab* st);
void CloseScope (struct _symtab* st);
void SymTab_Dump (struct _symtab* st, int lev, int fd);

/*
 * Some Code Generator prototypes:
 *
 * void FixLink (int L);
 * void IncLevel (int n);
 * void MakeConstItem (struct _item* x, type_t typ, int val);
 * void MakeItem (struct _item* x, struct _object* y);
 * void Field (struct _item* x, struct _object* y);
 */


#endif /* _CKPM_CC_SYMTAB_H_ */
