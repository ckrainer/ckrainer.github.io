/**
 * \file cc_parse.c
 * \brief CKPM C compiler parser
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include "cpp_io.h"
#include "cpp_conv.h"
#include "cpp_token.h"
#include "cc_scan.h"
#include "cc_parse.h"
#include "cc_message_list.h"
#include "cc_code_gen.h"


/* some forward declarations */
int Struct_Declaration (struct _parser* p, char* ident);
int Array_Declaration (struct _parser* p, char* typ, int pointer, char* name);
int Array_Initialisation (struct _parser* p, char* typ, int pointer, char* name, int dim);
int Variable_Declaration (struct _parser* p, char* typ, int pointer, char* name);
int Function_Declaration (struct _parser* p, char* typ, int pointer, char* name);
int extern_Declaration (struct _parser* p);
int Block (struct _parser* p, struct _item* s);
int Data_Declaration (struct _parser* p);
int if_Statement (struct _parser* p, struct _item* s);
int while_Statement (struct _parser* p, struct _item* s);
int break_Statement (struct _parser* p, struct _item* s);
int continue_Statement (struct _parser* p, struct _item* s);
int return_Statement (struct _parser* p, struct _item* s);
int Assignment_Expression (struct _parser* p, struct _item* x);
int Statement (struct _parser* p, struct _item* s);
// int List_Value (struct _parser* p, int sym, struct _item* x);
int Selector (struct _parser* p, struct _item* x);

int Logical_Or_Expression (struct _parser* p, struct _item* x);
int Logical_And_Expression (struct _parser* p, struct _item* x);
int Conditional_Expression (struct _parser* p, struct _item* x);
int Simple_Expression (struct _parser* p, struct _item* x);
int Term (struct _parser* p, struct _item* x);
int Factor (struct _parser* p, struct _item* x);


/**
 * \brief create and initialize a new parse
 * \param fd_in file descriptor index of the input file
 * \param fd_out file descriptor index of the output file
 * \param fd_err file descriptor index of the error output file
 * \return a pointer to the parser
 *****************************************************************************/

struct _parser*
Parser_Create (int fd_in, int fd_out, int fd_err) {
   struct _parser* p;
   p = (struct _parser*) malloc (sizeof(struct _parser));
   p->fd_in = fd_in;
   p->fd_out = fd_out;
   p->fd_err = fd_err;
   p->t = Token_Create ("");
   p->len = 0;
   p->rew = 1;
   p->errDist = MIN_ERROR_DIST + 1;
   p->infos = 0;
   p->warnings = 0;
   p->errors = 0;
   p->rd = (struct _token_list*)0;
   p->sp = (struct _token_list*)0;
   p->st = SymTab_Create ();
   p->cg = CodeGen_Create (fd_err);
   return p;
}

/**
 * \brief destroy a parser and all its components
 * \param p a pointer to the parser
 *****************************************************************************/

void
Parser_Destroy (struct _parser* p) {
   Token_Destroy (p->t);
   Message_List_Print (p->ml, p->fd_err, "old: ", (msgtype_t*)0);
   Message_Destroy (p->ml);
   free ((void*)p);
}


/**
 * \brief write a parser error message
 * \param p a pointer to the parser
 * \param s1 first string of the error message
 * \param s2 first string of the error message
 *****************************************************************************/

void
Parser_Error (struct _parser* p, char* s1, char* s2) {
   /* TODO: real implementation? */
   char nb [20];
   char buf [256];
   strcpy (buf, "ERROR: in file '");
   strcat (buf, p->t->file);
   strcat (buf, "' in line ");
   strcat (buf, int_to_str (nb, 100, 10, p->t->line));
// strcat (buf, ", sym=");
// strcat (buf, SymToStringCC (p->t->sym));
   strcat (buf, ", at '");
   strcat (buf, p->t->id);
   strcat (buf, "': ");
   strcat (buf, s1);
   strcat (buf, s2);
   strcat (buf, "\n");

   /* TODO: suppress spurious error messages if error-distance < 3 */
   if (p->errDist > MIN_ERROR_DIST) {
      if (p->rec)
         p->ml = Message_List_Append (p->ml, buf, MSG_TYPE_ERR);
      else {
         put_string (p->fd_err, buf);
         p->errors = p->errors + 1;
      }
   }
#ifdef DEBUG
   else {
      put_string (p->fd_err, "Suppressed: ");
      put_string (p->fd_err, buf);
   }
#endif

   p->errDist = 0;
}


/**
 * \brief write a parser warning message
 * \param p a pointer to the parser
 * \param s1 first string of the warning message
 * \param s2 first string of the warning message
 *****************************************************************************/

void
Parser_Warning (struct _parser* p, char* s1, char* s2) {
   /* TODO: real implementation? */
   char nb [20];
   char buf [256];
   strcpy (buf, "WARNING: in file '");
   strcat (buf, p->t->file);
   strcat (buf, "' in line ");
   strcat (buf, int_to_str (nb, 100, 10, p->t->line));
#ifdef DEBUG
   strcat (buf, ", sym=");
   strcat (buf, SymToStringCC (p->t->sym));
   strcat (buf, ", id='");
   strcat (buf, p->t->id);
   strcat (buf, "'");
#endif
   strcat (buf, ": ");
   strcat (buf, s1);
   strcat (buf, s2);
   strcat (buf, "\n");

   if (p->rec)
      p->ml = Message_List_Append (p->ml, buf, MSG_TYPE_WARN);
   else {
      put_string (p->fd_err, buf);
      p->warnings = p->warnings + 1;
   }
}


/**
 * \brief write a parser info message
 * \param p a pointer to the parser
 * \param s1 first string of the warning message
 * \param s2 first string of the warning message
 *****************************************************************************/

void
Parser_Info (struct _parser* p, char* s1, char* s2) {
   /* TODO: real implementation? */
   char nb [20];
   char buf [256];
   strcpy (buf, "INFO: in file '");
   strcat (buf, p->t->file);
   strcat (buf, "' in line ");
   strcat (buf, int_to_str (nb, 100, 10, p->t->line));
#ifdef DEBUG
   strcat (buf, ", sym=");
   strcat (buf, SymToStringCC (p->t->sym));
   strcat (buf, ", id='");
   strcat (buf, p->t->id);
   strcat (buf, "'");
#endif
   strcat (buf, ": ");
   strcat (buf, s1);
   strcat (buf, s2);
   strcat (buf, "\n");

   if (p->rec)
      p->ml = Message_List_Append (p->ml, buf, MSG_TYPE_INFO);
   else {
      put_string (p->fd_err, buf);
      p->infos = p->infos + 1;
   }
}


/**
 * \brief print a token
 * \param p a pointer to the parser
 *****************************************************************************/

void
Print_Token (struct _parser* p) {
   put_string (p->fd_err, "*** New Token: ");
   put_string (p->fd_err, SymToStringCC (p->t->sym));
   put_two_string_nl (p->fd_err, " ", p->t->id);
}


/**
 * \brief get next scanner symbol
 * \param p a pointer to the parser
 *****************************************************************************/

void
GetSymCC (struct _parser *p) {
   p->errDist = p->errDist + 1;

   if (p->rd) {
      Token_Destroy (p->t);
      p->t = Token_Clone (p->rd->t);
      p->rd = p->rd->next;
#ifdef DEBUG
      Print_Token (p);
#endif
      return;
   }

   if (p->rec) {
      GetSymIntCC (p->fd_in, p->t);
      p->sp = Token_List_Append (p->sp, p->t);
      p->len = p->len + 1;
#ifdef DEBUG
      Print_Token (p);
#endif
      return;
   }

   if (p->sp) {
      p->sp = Token_List_Shift (p->sp, p->t);
#ifdef DEBUG
      Print_Token (p);
#endif
      return;
   }

   GetSymIntCC (p->fd_in, p->t);
#ifdef DEBUG
   Print_Token (p);
#endif
}


/**
 * \brief skip symbols until the desired symbol is found or the file has ended
 * \param p a pointer to the parser
 * \param sym the symbol to skip to
 *****************************************************************************/

void
SkipToSymCC (struct _parser* p, int sym) {
   while (p->t->sym != sym && p->t->sym != SYM_END)  GetSymCC (p);
}


/**
 * \brief set save point for token saving
 * \param p a pointer to the parser
 * \returns a handle to the actual save point
 *****************************************************************************/

int
SetSavePoint (struct _parser* p) {
#ifdef DEBUG
   put_string (p->fd_err, "SetSavePoint() ");
   put_int (p->fd_err, p->len);
   put_string (p->fd_err, "\n");
#endif
   if (!p->rec) { p->oldpc = p->cg->pc;  p->olddidx = p->cg->didx; }
   if (!p->rec && !p->rd)  p->rd = p->sp;
   p->rec = 1;
   p->rew = 1;
   return p->len;
}


/**
 * \brief rewind to last save point and deliver the tokens again
 * \param p a pointer to the parser
 * \param sph the handle of the save point
 *****************************************************************************/

void
Rewind (struct _parser* p, int sph) {
   if (!p->rew) {
      Release (p, sph);
      return;
   }
   p->errDist = MIN_ERROR_DIST + 1;
#ifdef DEBUG
   put_string (p->fd_err, "Rewind() ");
   put_int (p->fd_err, sph);
   put_string (p->fd_err, "\n");
#endif
   p->rd = (struct _token_list*)0;
   if (sph) {
      p->rd = p->sp;
      while (sph) { p->rd = p->rd->next;  sph = sph -1; }
      return;
   }
   p->rec = 0;
   p->len = 0;
#ifdef DEBUG
   Message_List_Print (p->ml, p->fd_err, "Drop message: ", (msgtype_t*)0);
#endif
   Message_Destroy (p->ml);
   p->ml = (struct _message_list*)0;
   p->cg->pc = p->oldpc;
   p->cg->didx = p->olddidx;
}


/**
 * \brief disallow rewinding to last savepoint
 * \param p a pointer to the parser
 *****************************************************************************/

void
Block_Rewind (struct _parser* p) {
#ifdef DEBUG
   put_string (p->fd_err, "Block_Rewind().\n");
#endif
   p->rew = 0;
}


/**
 * \brief release last save point
 * \param p a pointer to the parser
 * \param sph the handle of the save point
 *****************************************************************************/

void
Release (struct _parser* p, int sph) {
   struct _token_list *l;
   msgtype_t ty[MSG_TYPE_MAX];
   int k;
#ifdef DEBUG
   put_string (p->fd_err, "Release() ");
   put_int (p->fd_err, sph);
   if (!p->rew) put_string (p->fd_err, " because of blocked rewind.");
   put_string (p->fd_err, "\n");
#endif
   p->rew = 1;
   if (!sph) {
      p->rec = 0;
      p->len = 0;
      if (p->rd) {
         while (p->sp != p->rd) {
            Token_Destroy (p->sp->t);
            l = p->sp->next;
            free ((void*)p->sp);
            p->sp = l;
         }
         p->rd = (struct _token_list*)0;
      } else {
         Token_List_Destroy (p->sp);
         p->sp = (struct _token_list*)0;
         p->rd = (struct _token_list*)0;
      }
   }
#ifdef DEBUG
   Message_List_Print (p->ml, p->fd_err, "Valid message: ", (msgtype_t*)0);
#endif
   k=0; while (k < MSG_TYPE_MAX) { ty[k] = 0; k = k + 1; }
   Message_List_Print (p->ml, p->fd_err, "", ty);
   p->infos = p->infos + ty[MSG_TYPE_INFO];
   p->warnings = p->warnings + ty[MSG_TYPE_WARN];
   p->errors = p->errors + ty[MSG_TYPE_ERR];
   Message_Destroy (p->ml);
   p->ml = (struct _message_list*)0;
}


/**
 * \brief check if a given symbol is a simple (builtin) type
 * \param sym the symbol
 * \return 1 if the symbol is a simple type, otherwise 0
 *****************************************************************************/

int
is_SimpleType (int sym) {
   if (sym == SYM_VOID || sym == SYM_CHAR || sym == SYM_INT ||
       sym == SYM_LONG || sym == SYM_DOUBLE || sym == SYM_FLOAT ||
       sym == SYM_SHORT)
      return 1;
   return 0;
}


/**
 * \brief handle a declaration statement
 * \param p a pointer to the parser
 * \param no_fct != 0 allows no function declaration
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
Declaration_Statement (struct _parser* p, int no_fct) {
   int rc;
   int is_extern;
   int is_static;
   int is_struct;
   int is_pointer;
   char ident[255];
   char ident2[255];
#ifdef DEBUG
   char buf[100];
   Parser_Info (p, "Declaration_Statement() ", int_to_str (buf, 100, 10, no_fct) );
#endif
   rc = 1;
   is_extern = 0;
   is_static = 0;
   is_struct = 0;
   is_pointer = 0;

   if (p->t->sym == SYM_EXTERN) {
      is_extern = is_extern + 1;
      GetSymCC (p);
      /* TODO: implement? */
      if (p->t->sym == SYM_LITERAL)  return extern_Declaration (p);
   } else
   if (p->t->sym == SYM_STATIC) {
      is_static = is_static + 1;
      GetSymCC (p);
      /* TODO: implement? */
   }

   if (p->t->sym == SYM_STRUCT) {
      is_struct = is_struct + 1;
      GetSymCC (p);
      Block_Rewind (p);
      /* TODO: implement? */
   }

   if (p->t->sym == SYM_IDENT || is_SimpleType (p->t->sym)) {
      if (is_SimpleType (p->t->sym))
         Block_Rewind (p);

      ident[0] = '\0';
      if (is_struct)
         strcat (ident, "struct ");
      strcat (ident, p->t->id);
      GetSymCC (p);

      if (p->t->sym == SYM_LEFT_BRACE && is_struct) {
         /* we have a struct declaration */
         rc = Struct_Declaration (p, ident);
#ifdef DEBUG
         Parser_Info (p, "Struct_Declaration() ", int_to_str (buf, 100, 10, rc) );
#endif
         return rc;
      }

      while (p->t->sym == SYM_ASTERISK) {
         is_pointer = is_pointer + 1;
         GetSymCC (p);
      }

      if (p->t->sym == SYM_IDENT) {
         /* we have a simple declaration or function declaration */
         strcpy (ident2, p->t->id);
         GetSymCC (p);

         if (p->t->sym == SYM_LEFT_BRACK) {
            /* we got an array declaration */
            rc = Array_Declaration (p, ident, is_pointer, ident2);
         } else

         if (p->t->sym == SYM_SEMICOLON || p->t->sym == SYM_EQUAL) {
            /* we got a variable declaration */
            rc = Variable_Declaration (p, ident, is_pointer, ident2);
         } else

         if (p->t->sym == SYM_LEFT_PAREN) {
            /* it is a function declaration */
            rc = Function_Declaration (p, ident, is_pointer, ident2);
            if (no_fct) {
               Parser_Error (p, "Function declaration not allowed here.", "");
               rc = 0;
            }
         } else {
            Parser_Error (p, "Error in declaration. sym=", SymToStringCC (p->t->sym));
            SkipToSymCC (p, SYM_SEMICOLON);
            GetSymCC (p);
         }

         return rc;
      }
   }

   Parser_Error (p, "Error in declaration. sym=", SymToStringCC (p->t->sym));
   SkipToSymCC (p, SYM_SEMICOLON);
   GetSymCC (p);

   return 0;
}


/**
 * \brief handle a struct declaration statement
 * \param p a pointer to the parser
 * \param name the name of the struct
 * \return 1 on success, otherwise 0
 * This subroutine is called after the left brace was recognised. It collects
 * the declarations of all struct members.
 *****************************************************************************/

int
Struct_Declaration (struct _parser* p, char* name) {
   int rc;
   int dim;
   int is_struct;
   int is_pointer;
   int is_simple;
   int k;
   char ident[255];
   char ident2[255];
   struct _object* str;
   struct _object* fld;
   struct _object* obj;
   struct _object* ts;
#ifdef DEBUG
   put_string (p->fd_err, "Struct_Declaration(). ");
   put_two_string_nl (p->fd_err, "  name=", name);
#endif
   rc = 1;
   is_struct = 0;

   str = Find (p, name, 0);
   if (str) {
      if (str->type->fields)
         Parser_Error (p, "Redefinition of: ", name);
   } else {
      str = NewObj (p, CLASS_TYPE, name);
      str->type = Type_Create (FORM_STRUCTURE, 0, 0, (struct _object*)0, (struct _type*)0);
   }

   fld = (struct _object*)0;
   OpenScope (p->st);

   GetSymCC (p);
   /* TODO: implement */

   while (p->t->sym != SYM_RIGHT_BRACE && p->t->sym != SYM_END) {
#ifdef DEBUG
      Parser_Info (p, "Struct_Declaration() check 1.", "");
#endif
      dim = 0;

      is_struct = 0;
      if (p->t->sym == SYM_STRUCT) {
         is_struct = is_struct + 1;
         GetSymCC (p);
         /* TODO: implement? */
      }

      is_simple = is_SimpleType (p->t->sym);

      if (p->t->sym == SYM_IDENT || is_simple) {
         ident[0] = '\0';
         if (is_struct)
            strcat (ident, "struct ");
         strcat (ident, p->t->id);
         GetSymCC (p);

         is_pointer = 0;
         while (p->t->sym == SYM_ASTERISK) {
            is_pointer = is_pointer + 1;
            GetSymCC (p);
         }

         if (p->t->sym == SYM_IDENT) {
            strcpy (ident2, p->t->id);
            GetSymCC (p);

            if (p->t->sym == SYM_LEFT_BRACK) {
               /* we got an array declaration */
               GetSymCC (p);
               if (p->t->sym == SYM_NUMBER ||
                   p->t->sym == SYM_OCT_NUMBER ||
                   p->t->sym == SYM_HEX_NUMBER)
               {
                  dim = p->t->num;
                  GetSymCC (p);
               } else {
                  Parser_Error (p, "Dimension in array declaration missing.","");
                  SkipToSymCC (p, SYM_RIGHT_BRACK);
                  rc = 0;
               }

               if (p->t->sym == SYM_RIGHT_BRACK) {
                  GetSymCC (p);
               } else {
                  Parser_Error (p, "']' expected.","");
                  rc = 0;
               }
            }

            if (p->t->sym == SYM_SEMICOLON) {
               GetSymCC (p);
            } else {
               Parser_Error (p, "';' expected.","");
               rc = 0;
            }

            /* TODO: implementation */
#ifdef DEBUG
            put_string (p->fd_err, "Add Field: type=");
            put_string (p->fd_err, ident);
            put_string (p->fd_err, ", pointer=");
            put_int    (p->fd_err, is_pointer);
            put_string (p->fd_err, ", name=");
            put_string (p->fd_err, ident2);
            put_string (p->fd_err, ", array dimension=");
            put_int    (p->fd_err, dim);
            put_string (p->fd_err, "\n");
#endif
            if (fld) {
               fld->next = NewObj (p, CLASS_FIELD, ident2);
               fld = fld->next;
            } else {
               fld = NewObj (p, CLASS_FIELD, ident2);
               str->type->fields = fld;
            }

            obj = Find (p, ident, !(is_struct && is_pointer));
            if (!obj && is_struct && is_pointer) {
               ts = p->st->topScope;
               p->st->topScope = p->st->topScope->dsc;
               obj = NewObj (p, CLASS_TYPE, ident);
               p->st->topScope = ts;
               obj->type = Type_Create (FORM_STRUCTURE, 0, 0, (struct _object*)0,
                                        (struct _type*)0);
#ifdef DEBUG
               put_two_string_nl (p->fd_err, "Forward declaration of: ", ident);
#endif
            }

            if (obj) {
               if (obj->cls == CLASS_TYPE) {
                  fld->type = obj->type;
                  fld->val = str->type->size;

                  k = is_pointer;
                  while (k) {
                     fld->type = Type_Create (FORM_POINTER, 0, SIZE_OF_PTR,
                                              (struct _object*)0, fld->type);
                     k = k - 1;
                  }

                  if (dim) {
                     fld->type = Type_Create (FORM_ARRAY, dim, 0,
                                              (struct _object*)0, fld->type);
                     fld->type->size = dim * fld->type->base->size;
                  } else if (is_pointer) fld->type->size = SIZE_OF_PTR;
// TODO:          str->type = str->type + Align (str->type->size, fld->type->size);
                  str->type->size = str->type->size + fld->type->size;
               } else {
                  Parser_Error (p, "Identifier is not a type: ",ident);
                  rc = 0;
               }
            }

         }
      }
   }

   if (p->t->sym == SYM_RIGHT_BRACE) {
      GetSymCC (p);
   } else {
      Parser_Error (p, "'}' expected.","");
      rc = 0;
   }

   if (p->t->sym == SYM_SEMICOLON) {
      GetSymCC (p);
   } else {
      Parser_Error (p, "';' expected.","");
      rc = 0;
   }

#if 0
   put_string (p->fd_err, "Struct_Declaration(): ");
   SymTab_Dump (p->st, 0, p->fd_err);
#endif
   CloseScope (p->st);
   return rc;
}


/**
 * \brief handle a array declaration statement
 * \param p a pointer to the parser
 * \param typ the name of the array variable type
 * \param pointer contains how many times the type has to be dereferenced
 * \param name the name of the array variable
 * \return 1 on success, otherwise 0
 * This subroutine is called after the left bracket was recognised.
 *****************************************************************************/

int
Array_Declaration (struct _parser* p, char* typ, int pointer, char* name) {
   int dim;
   int rc;
   struct _object* var;
   struct _object* obj;
   struct _type* ty;
   int k;
#ifdef DEBUG
   put_string (p->fd_err, "Array_Declaration(). type=");
   put_string (p->fd_err, typ);
   k=0;
   while (k < pointer) { put_string (p->fd_err, "*"); k = k + 1; }
   put_two_string_nl (p->fd_err, "  name=", name);
#endif
   dim = 0;
   rc = 1;

   /* TODO: implement */

   GetSymCC (p);
   if (p->t->sym == SYM_NUMBER ||
       p->t->sym == SYM_OCT_NUMBER ||
       p->t->sym == SYM_HEX_NUMBER)
   {
      dim = p->t->num;
   } else {
      Parser_Error (p, "Dimension in array declaration missing.","");
      SkipToSymCC (p, SYM_SEMICOLON);
      GetSymCC (p);
      return 0;
   }

   GetSymCC (p);
   if (p->t->sym != SYM_RIGHT_BRACK) {
      Parser_Error (p, "Dimension in array declaration missing.","");
      SkipToSymCC (p, SYM_SEMICOLON);
      GetSymCC (p);
      return 0;
   }

   var = NewObj (p, CLASS_VAR, name);
   obj = Find (p, typ, 1);
   if (obj) {
      if (obj->cls == CLASS_TYPE) {
         k = 0;
         ty = obj->type;
         while (k < pointer) {
            ty = Type_Create (FORM_POINTER, 0, SIZE_OF_PTR, (struct _object*)0, ty);
            k = k + 1;
         }
         ty = Type_Create (FORM_ARRAY, dim, 0, (struct _object*)0, ty);
         ty->size = dim * ty->base->size;
         var->type = ty;
      }
      else { Parser_Error (p, "Identifier is not a type: ", typ); rc = 0; }
   } else { Parser_Error (p, "Undefined type: ", typ); rc = 0; }

   GetSymCC (p);
   if (p->t->sym == SYM_EQUAL) {
      /* TODO: check if initialisation is allowed anyway (extern!) */
      rc = Array_Initialisation (p, typ, pointer, name, dim);
      if (!rc) {
         Type_Destroy (var->type);
         DelObj (p, var);
      }
      return rc;
   }
   
   if (p->t->sym == SYM_SEMICOLON) {
      GetSymCC (p);
      return 1;
   }

   Type_Destroy (var->type);
   DelObj (p, var);
   Parser_Error (p, "';' or array initialisation expected.","");
   SkipToSymCC (p, SYM_SEMICOLON);
   GetSymCC (p);
   return 0;
}


/**
 * \brief handle the initialisation of an array declaration statement
 * \param p a pointer to the parser
 * \param typ the name of the array variable type
 * \param pointer contains how many times the type has to be dereferenced
 * \param name the name of the array variable
 * \param dim the dimenstion of the array
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
Array_Initialisation (struct _parser* p, char* typ, int pointer, char* name, int dim) {
#ifdef DEBUG
   char buf [100];
#endif
   int rc;
   int cnt;
   int sign;
   int val;
   int skip;
#ifdef DEBUG
   int k;
   put_string (p->fd_err, "Array_Initialisation(). type=");
   put_string (p->fd_err, typ);
   k=0;
   while (k < pointer) { put_string (p->fd_err, "*"); k = k + 1; }
   put_string (p->fd_err, "  name=");
   put_string (p->fd_err, name);
   put_string (p->fd_err, "  dimension=");
   put_int    (p->fd_err, dim);
   put_string (p->fd_err, "\n");
#endif

   GetSymCC (p);

   if (p->t->sym == SYM_LITERAL) {
      if ( dim != (strlen (p->t->id)+1) ) {
         Parser_Error (p, "String length does not equal the specified array dimension.", "");
         GetSymCC (p);
         return 0;
      }

      /* TODO: implementation */
#ifdef DEBUG
      Parser_Info (p, "initialise with string: ", p->t->id);
#endif
      GetSymCC (p);
      return 1;
   }

   if (p->t->sym != SYM_LEFT_BRACE) {
      Parser_Error (p, "'{' expected.","");
      SkipToSymCC (p, SYM_SEMICOLON);
      GetSymCC (p);
      return 0;
   }

   cnt = 0;
   rc = 1;
   while (p->t->sym != SYM_RIGHT_BRACE) {
      cnt = cnt + 1;
      skip = 0;
      sign = 0;
      GetSymCC (p);
      if (p->t->sym == SYM_MINUS) { GetSymCC (p); sign=-1; } else
      if (p->t->sym == SYM_PLUS)  { GetSymCC (p); sign=1;  }

      if (p->t->sym == SYM_NUMBER ||
          p->t->sym == SYM_OCT_NUMBER ||
          p->t->sym == SYM_HEX_NUMBER)
      {
         val = 0;
         if (sign == 0) sign = 1;
         val = sign * p->t->num;
         /* TODO: implementation */
#ifdef DEBUG
         Parser_Info (p, "initialise with number: ", int_to_str (buf, 100, 10, val));
#endif

      } else

      if (p->t->sym == SYM_LITERAL) {
         if (sign) {
            Parser_Error (p, "Signs are not allowed for string literals.", "");
            skip = skip + 1;
         }
         /* TODO: implementation */
#ifdef DEBUG
         Parser_Info (p, "initialise with string: ", p->t->id);
#endif

      } else

      if (p->t->sym == SYM_CHARACTER) {
         if (sign) {
            Parser_Error (p, "Signs are not allowed for character constants.", "");
            skip = skip + 1;
         }
         /* TODO: implementation */
#ifdef DEBUG
         Parser_Info (p, "initialise with character: ", p->t->id);
#endif

      } else {
         Parser_Error (p, "Unexpected initialiser found: ", p->t->id);
         skip = skip + 1;
      }

      GetSymCC (p);
      if (p->t->sym == SYM_RIGHT_BRACE) break;

      if (p->t->sym != SYM_COMMA) {
         Parser_Error (p, "',' expected and not: ", SymToStringCC (p->t->sym));
         skip = skip + 1;
      }

      if (skip) {
         while (p->t->sym != SYM_COMMA     && p->t->sym != SYM_RIGHT_BRACE &&
                p->t->sym != SYM_SEMICOLON && p->t->sym != SYM_END           )
            GetSymCC (p);
         rc = 0;
      } else {
         /* TODO: ??? */
      }

   }

   if (dim != cnt) {
      Parser_Error (p, "Incorrect number of initialisers specified.", "");
      rc = 0;
   }

   GetSymCC (p);
   if (p->t->sym != SYM_SEMICOLON) {
      Parser_Error (p, "';' expected.","");
#ifdef DEBUG
      Parser_Error (p, "';' expected.", int_to_str (buf, 100, 10, __LINE__) );
#endif
      SkipToSymCC (p, SYM_SEMICOLON);
      return 0;
   }

   /* TODO: implementation */

   Parser_Error (p, "Initialisation of array is not implemented.","");
   rc = 0;

   return rc;
}


/**
 * \brief handle a function declaration statement
 * \param p a pointer to the parser
 * \param typ the name of the variable type
 * \param pointer contains how many times the type has to be dereferenced
 * \param name the name of the variable
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
Variable_Declaration (struct _parser* p, char* typ, int pointer, char* name) {
   int rc;
   int adr;
   int skip;
   int sign;
   int val;
   struct _object* var;
   struct _object* obj;
   struct _type* type;
   struct _type* tp;
   struct _item x;
   struct _item y;
   int k;
#ifdef DEBUG
   char buf[100];
   put_string (p->fd_err, "Variable_Declaration(). type=");
   put_string (p->fd_err, typ);
   k=pointer;
   while (k) { put_string (p->fd_err, "*"); k = k - 1; }
   put_two_string_nl (p->fd_err, "  name=", name);
#endif

   rc = 1;
   skip = 0;

   var = NewObj (p, CLASS_VAR, name);
   var->lev = p->cg->curlev;	/* TODO: check ! */
   obj = Find (p, typ, 1);
   if (obj) {
      if (obj->cls == CLASS_TYPE) {
         if (pointer) {
            k = pointer;
            type = (struct _type*)0;
            tp = type;
            while (k) {
               if (tp) {
                  tp->base = Type_Create (FORM_POINTER, 0, SIZE_OF_PTR,
                                          (struct _object*)0, (struct _type*)0);
                  tp = tp->base;
               } else {
                  tp = Type_Create (FORM_POINTER, 0, SIZE_OF_PTR,
                                    (struct _object*)0, (struct _type*)0);
                  type = tp;
               }
               k = k - 1;
            }
            var->type = type;
            tp->base = obj->type;
         } else
            var->type = obj->type;
      } else { Parser_Error (p, "Identifier is not a type: ", typ); rc = 0; }
   } else { Parser_Error (p, "Undefined type: ", typ); rc = 0; }

   if (p->t->sym == SYM_EQUAL) {
      /* TODO: handle the variable initialiser. Problem: variables are allocated later */
//    if (!var->lev)
         Parser_Error (p, "Initialisation of variables not implemented.", "");

      sign = 0;
      GetSymCC (p);
      if (p->t->sym == SYM_MINUS) { GetSymCC (p); sign=-1; } else
      if (p->t->sym == SYM_PLUS)  { GetSymCC (p); sign=1;  }

      if (p->t->sym == SYM_NUMBER ||
          p->t->sym == SYM_OCT_NUMBER ||
          p->t->sym == SYM_HEX_NUMBER)
      {
         val = 0;
         if (sign == 0) sign = 1;
         val = sign * p->t->num;
         /* TODO: implementation */
#ifdef DEBUG
         Parser_Info (p, "initialise with number: ", int_to_str (buf, 100, 10, val));
#endif
         if (var) {
            Make_Item (p, &x, var);
            Make_Const_Item (p, &y, p->st->intType, val);
            Store (p, &x, &y);
         }

         GetSymCC (p);

      } else

      if (p->t->sym == SYM_LITERAL) {
         if (sign) {
            Parser_Error (p, "Signs are not allowed for string literals.", "");
            skip = skip + 1;
         }
         /* TODO: implementation */
#ifdef DEBUG
         Parser_Info (p, "initialise with string: ", p->t->id);
#endif
         if (var) {
            Make_Item (p, &x, var);
            adr = CG_Put_Global_Data (p->cg, p->t->id, p->t->num, 1);
            Make_Const_Item (p, &y, p->st->charPtrType, adr);
            Store (p, &x, &y);
         }
         GetSymCC (p);

      } else

      if (p->t->sym == SYM_CHARACTER) {
         if (sign) {
            Parser_Error (p, "Signs are not allowed for character constants.", "");
            skip = skip + 1;
         }
         /* TODO: implementation */
#ifdef DEBUG
         Parser_Info (p, "initialise with character: ", p->t->id);
#endif
         GetSymCC (p);
      } else

      if (p->t->sym == SYM_IDENT) {

         /* TODO: implementation */
#ifdef DEBUG
         Parser_Info (p, "initialise with variable: ", p->t->id);
#endif
//       GetSymCC (p);
         rc = Logical_Or_Expression (p, &x);
//       rc = Assignment_Expression (p, &x);

         /* TODO: implement initialisation */
      } else

      if (p->t->sym == SYM_LEFT_PAREN) {
#ifdef DEBUG
         Parser_Info (p, "initialise with an assignment expression.", "");
#endif
         rc = Assignment_Expression (p, &x);
         /* TODO: implement initialisation */

      } else {
         Parser_Error (p, "Unexpected initialiser found: ", p->t->id);
         skip = skip + 1;
      }
   }

   if (skip) {
      SkipToSymCC (p, SYM_SEMICOLON);
      GetSymCC (p);
      DelObj (p, var);
      return 0;
   }

   if (p->t->sym == SYM_SEMICOLON) {
      /* TODO: implement */
      GetSymCC (p);
   } else {
      Parser_Error (p, "';' expected.", "");
#ifdef DEBUG
      Parser_Error (p, "';' expected.", int_to_str (buf, 100, 10, __LINE__) );
#endif
      SkipToSymCC (p, SYM_SEMICOLON);
      rc = 0;
   }

   if (!rc)  DelObj (p, var);

   return rc;
}


/**
 * \brief handle a function declaration statement
 * \param p a pointer to the parser
 * \param typ the name of the return type
 * \param pointer contains how many times the return type has to be dereferenced
 * \param name the name of the function
 * \return 1 on success, otherwise 0
 * This subroutine is called after the left parenthesis was recognised.
 *****************************************************************************/

int
Function_Declaration (struct _parser* p, char* typ, int pointer, char* name) {
   int is_const;
   int is_struct;
   int is_pointer;
   int has_proto;
   char ident[1024];
   char ident2[1024];
   int skip;
   int rc;
   int param;
   int stack_addr;
   int parblk_size;
   int locblk_addr;
   char buf[100];
   struct _object* fun;
   struct _object* obj;
   struct _object* var;
   struct _type* type;
   struct _item s;
   int k;
#ifdef DEBUG
   put_string (p->fd_err, "Function_Declaration(). type=");
   put_string (p->fd_err, typ);
   k = 0;
   while (k < pointer) { put_string (p->fd_err, "*"); k = k + 1; }
   put_two_string_nl (p->fd_err, "  function name=", name);
#endif
   has_proto = 0;
   rc = 1;
   param = 0;
   stack_addr = 0;

   fun = NewObj (p, CLASS_FUNC, name);

   if (fun->cls == CLASS_FUNC_PR) {
      /* function already has a prototype */
#ifdef DEBUG
      put_two_string_nl (p->fd_err, "Function_Declaration(). prototype found for name=",
                         name);
#endif
      has_proto = 1;
      k = 0;
      obj = Find (p, typ, 1);
//    type = fun->type->base;
      type = fun->type;
      if (type) {
         while (type->base && type->form == FORM_POINTER) { k = k + 1; type = type->base; }
         if (k != pointer) {
            Parser_Error (p, "Mismatch of '*' with prototype return value for function: ",
                          name);
            rc = 0;
         }
//       if (obj->type != type->base) {}
         if (obj->type != type) {
            Parser_Error (p, "Type mismatch with prototype return value for function: ",
                          name);
            rc = 0;
         }
      } else {
         if (obj->type != fun->type) {
            Parser_Error (p, "Type mismatch with prototype return value for function: ",
                          name);
            rc = 0;
         }
      }
   } else {
      /* first declaration of function */
      obj = Find (p, typ, 1);
      if (obj) {
         if (fun->type) {
            Parser_Error (p, "Redefinition of function: ", name);
            rc = 0;
         }
         fun->type = obj->type;
         k = pointer;
         while (k) {
            fun->type = Type_Create (FORM_POINTER, 0, SIZE_OF_PTR,
                                     (struct _object*)0, fun->type);
            k = k - 1;
         }
      } else rc=0;
   }

   Increment_Level (p->cg);
   OpenScope (p->st);

   /* TODO: implement */
   GetSymCC (p);

   while (rc && p->t->sym != SYM_RIGHT_PAREN && p->t->sym != SYM_END) {
      param = param + 1;
      skip = 0;

      is_const = 0;
      if (p->t->sym == SYM_CONST) {
         is_const = is_const + 1;
         Parser_Warning (p, "Keyword 'const' not implemented (ignored).", "");
         GetSymCC (p);
         /* TODO: implement? */
      }

      is_struct = 0;
      if (p->t->sym == SYM_STRUCT) {
         is_struct = is_struct + 1;
         GetSymCC (p);
         /* TODO: implement? */
      }

      if (p->t->sym == SYM_IDENT || is_SimpleType (p->t->sym)) {
         ident[0] = '\0';
         if (is_struct)
            strcat (ident, "struct ");
         strcat (ident, p->t->id);
         GetSymCC (p);
      } else {
         Parser_Error (p, "Type name or struct name expected for parameter ",
                       int_to_str(buf, 100, 10, param) );
         skip = skip + 1;
      }

      is_pointer = 0;
      while (p->t->sym == SYM_ASTERISK) {
         is_pointer = is_pointer + 1;
         GetSymCC (p);
      }

      if (p->t->sym == SYM_IDENT) {
         strcpy (ident2, p->t->id);
         GetSymCC (p);
         /* TODO: handle parameter */
      } else {
          Parser_Error (p, "Parameter name expected for parameter ", 
                        int_to_str(buf, 100, 10, param) );
          skip = skip + 1;
      }

      if (p->t->sym != SYM_COMMA && p->t->sym != SYM_RIGHT_PAREN) {
         Parser_Error (p, "')' or ',' expected after parameter ", 
                       int_to_str(buf, 100, 10, param) );
         skip = skip + 1;
      } else {
#ifdef DEBUG
//       put_two_string_nl (p->fd_err, "  symbol=", SymToStringCC (p->t->sym) );
         put_string (p->fd_err, "Parameter [");
         put_string (p->fd_err, int_to_str (buf, 100, 10, param) );
         put_string (p->fd_err, "] type=");
         put_string (p->fd_err, ident);
         k = 0;
         while (k < is_pointer) { put_string (p->fd_err, "*"); k = k + 1; }
         put_two_string_nl (p->fd_err, "  name=", ident2);
#endif

         /* insert the parameter as variables in the symbol table */
         var = NewObj (p, CLASS_PARAM, ident2);
         obj = Find (p, ident, 1);
         if (obj) {
            if (obj->cls == CLASS_TYPE) {
               var->type = obj->type;
               k = is_pointer;
               while (k) {
                  var->type = Type_Create (FORM_POINTER, 0, SIZE_OF_PTR,
                                           (struct _object*)0, var->type);
                  k = k - 1;
               }
               var->val = stack_addr;
               if (is_pointer)  stack_addr = stack_addr + SIZE_OF_PTR;
               else             stack_addr = stack_addr + obj->type->size;
               var->lev = p->cg->curlev;
            } else { Parser_Error (p, "Identifier is not a type: ", typ); rc = 0; }
         } else { Parser_Error (p, "Undefined type: ", typ); rc = 0; }

         if (p->t->sym == SYM_RIGHT_PAREN) break;
         GetSymCC (p);
      }

      if (skip) {
         while (p->t->sym != SYM_COMMA     && p->t->sym != SYM_RIGHT_PAREN &&
                p->t->sym != SYM_SEMICOLON && p->t->sym != SYM_END           )
            GetSymCC (p);
         rc = 0;
      }

   }

   if (rc && p->t->sym == SYM_RIGHT_PAREN) {
      GetSymCC (p);
      if (p->t->sym == SYM_SEMICOLON) {
#ifdef DEBUG
         put_string (p->fd_err, "Function_Declaration(). Checking Prototype not implemented.\n");
#endif
         /* we change the symbol table object class to a function prototype */
         fun->cls = CLASS_FUNC_PR;
         fun->dsc = p->st->topScope->next;
         CG_New_ExpImp (p->cg, fun->name, STB_GLOBAL, STT_NOTYPE);
         Decrement_Level (p->cg);
         CloseScope (p->st);
         GetSymCC (p);
         return 1;
      }

      if (p->t->sym == SYM_LEFT_BRACE) {
#ifdef DEBUG
         put_string (p->fd_err, "Function_Declaration(). Checking Prototype not implemented.\n");
#endif
         /* we change the symbol table object class to an implemented function */
         fun->cls = CLASS_FUNC;
         fun->dsc = p->st->topScope->next;
         if (stack_addr % SIZE_OF_INT)
            stack_addr = stack_addr + SIZE_OF_INT - stack_addr % SIZE_OF_INT;
         parblk_size = stack_addr;
         stack_addr = stack_addr + FRAME_ADMIN_SIZE;

         Make_Link_Item (p, &s, fun->type, p->cg->pc, 0, 0, 0);
         /* TODO: local binding for not exported functions */
         CG_New_ExpImp (p->cg, fun->name, STB_GLOBAL, STT_FUNC);
         locblk_addr = CG_Function_Prolog (p->cg, parblk_size);

         GetSymCC (p);
         s.lev = stack_addr;
         rc = Block (p, &s);
         
         CG_Fix (p->cg, locblk_addr, s.lev - stack_addr);
         CG_Fix_Link (p->cg, s.c);
         CG_Function_Epilog (p->cg, stack_addr, s.lev - stack_addr, fun->type->form);
         Decrement_Level (p->cg);
         CloseScope (p->st);
         return rc;
      }

      Parser_Error (p, "';' or '{' expected after parameter list.", "");
      SkipToSymCC (p, SYM_SEMICOLON);
      Decrement_Level (p->cg);
      CloseScope (p->st);
      return 0;
   }


   /* TODO: check / skip */
   Decrement_Level (p->cg);
   CloseScope (p->st);
   return 0;
}


/**
 * \brief handle a extern declaration statement
 * \param p a pointer to the parser
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
extern_Declaration (struct _parser* p) {
   char *typ;
   strcpy (typ, p->t->id);
#ifdef DEBUG
   put_two_string_nl (p->fd_err, "extern_Declaration(). type=", typ);
#endif

   GetSymCC (p);
   if (p->t->sym != SYM_LEFT_BRACE) {
      Parser_Error (p, "'{' expected after extern declaratio type.", "");
   }
   SkipToSymCC (p, SYM_RIGHT_BRACE);
   Parser_Warning (p, "'extern' declaration not implemented for type: ", typ);
   GetSymCC (p); /* TODO: check */
   return 1;
}


/**
 * \brief handle a function declaration statement
 * \param p a pointer to the parser
 * \param s the associated link item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
Block (struct _parser* p, struct _item* s) {
   int rc;
   int sp;
   struct _token *tok;
   struct _object *obj;
   int varsize;
#ifdef DEBUG
   put_string (p->fd_err, "Block().\n");
#endif
   tok = (struct _token*)0;
   varsize = 0;

   OpenScope (p->st);

   tok = Token_Clone (p->t);

   rc = 1;
   while (rc) {
      sp = SetSavePoint (p);
      rc = Data_Declaration (p);
      if (rc) {
         Release (p, sp);
         Token_Destroy (tok);
         tok = Token_Clone (p->t);
      } else {
         Rewind (p, sp);
      }
   }

#ifdef DEBUG
   Parser_Info (p, "Block() after data declaration.\n", "");
#endif

   varsize = s->lev;
   obj = p->st->topScope->next;
   while (obj != p->st->guard) {
      if (obj->cls == CLASS_VAR) {
         obj->val = s->lev;
         s->lev = s->lev + obj->type->size;
         if (s->lev % SIZE_OF_INT)
            s->lev = s->lev + SIZE_OF_INT - s->lev % SIZE_OF_INT;
         obj->lev = p->cg->curlev;
#ifdef DEBUG
         put_string (p->fd_err, "Block() variable name='");
         put_string (p->fd_err, obj->name);
         put_string (p->fd_err, "', size=");
         put_int    (p->fd_err, obj->type->size);
         put_string (p->fd_err, ", addr=");
         put_int    (p->fd_err, obj->val);
         put_string (p->fd_err, ", lev=");
         put_int    (p->fd_err, obj->lev);
         put_string (p->fd_err, "\n");
#endif
      }
      obj = obj->next;
   }

   rc = 1;
   Token_Destroy(p->t);
   p->t = tok;
#ifdef DEBUG
   put_string (p->fd_err, "Block(), size of all variables is: ");
   put_int    (p->fd_err, s->lev - varsize);
   put_string (p->fd_err, "\n");
#endif

   while (p->t->sym != SYM_RIGHT_BRACE) {
      if (!Statement (p, s)) rc = 0;
   }

   CloseScope (p->st);

   if (p->t->sym == SYM_RIGHT_BRACE) {
      GetSymCC (p);
      return rc;
   }

   Parser_Error (p, "'}' expected at the end of this block.", "");
   return 0;
}


/**
 * \brief handle a statement
 * \param p a pointer to the parser
 * \param s the statement item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
Statement (struct _parser* p, struct _item* s) {
   int rc;
   struct _item x;
#ifdef DEBUG
   put_string (p->fd_err, "\n");
   Parser_Info (p, "Statement().","");
#endif

   if (p->t->sym == SYM_LEFT_BRACE)  { GetSymCC (p); return Block (p, s); }
   if (p->t->sym == SYM_IF        )  return if_Statement (p, s);
   if (p->t->sym == SYM_WHILE     )  return while_Statement (p, s);
   if (p->t->sym == SYM_BREAK     )  return break_Statement (p, s);
   if (p->t->sym == SYM_CONTINUE  )  return continue_Statement (p, s);
   if (p->t->sym == SYM_RETURN    )  return return_Statement (p, s);

   Make_Void_Item (p, &x);
   rc = Assignment_Expression (p, &x);
   if (p->t->sym != SYM_SEMICOLON) {
      Parser_Error (p, "';' expected at the end of this statement.", "");
      SkipToSymCC (p, SYM_SEMICOLON);
      rc = 0;
   }
   GetSymCC (p);
   return rc;
}


/**
 * \brief handle a data declaration statement
 * \param p a pointer to the parser
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
Data_Declaration (struct _parser* p) {
#ifdef DEBUG
   put_string (p->fd_err, "Data_Declaration().\n");
#endif

   return Declaration_Statement (p, 1);
}


/**
 * \brief handle a if statement
 * \param p a pointer to the parser
 * \param s the statement item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
if_Statement (struct _parser* p, struct _item* s) {
   int rc;
   int l;
   struct _item x;
#ifdef DEBUG
   put_string (p->fd_err, "if_Statement().\n");
#endif
   rc = 1;

   GetSymCC (p);

   if (p->t->sym == SYM_LEFT_PAREN) {
      GetSymCC (p);
   } else {
      Parser_Error (p, "'(' expected.", "");
      rc = 0;
   }

   Make_Boolean_Item (p, &x);  x.r = STACK_ONLY;
   if (!Assignment_Expression (p, &x))  rc = 0;
   Conditional_Jump (p, &x);

   if (p->t->sym != SYM_RIGHT_PAREN) {
      Parser_Error (p, "')' expected.", "");
      while (p->t->sym != SYM_RIGHT_PAREN && p->t->sym != SYM_LEFT_BRACE &&
             p->t->sym != SYM_ELSE        && p->t->sym != SYM_SEMICOLON  &&
             p->t->sym != SYM_END         )
         GetSymCC (p);
   }
   
   GetSymCC (p);
   if (!Statement (p, s))  rc = 0;
   l = 0;

   if (p->t->sym == SYM_ELSE) {
      GetSymCC (p);
      l = CG_Forward_Jump (p->cg, l);
      CG_Fix_Link (p->cg, x.a);
      if (!Statement (p, s))  rc = 0;
   } else CG_Fix_Link (p->cg, x.a);

   CG_Fix_Link (p->cg, l);
   return rc;
}


/**
 * \brief handle a while statement
 * \param p a pointer to the parser
 * \param s the statement item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
while_Statement (struct _parser* p, struct _item* s) {
   int rc;
   struct _item x;
   struct _item ls;
   int l;
#ifdef DEBUG
   put_string (p->fd_err, "while_Statement().\n");
#endif
   rc = 1;

   s->w = s->w + 1;
   GetSymCC (p);

   if (p->t->sym == SYM_LEFT_PAREN) {
      GetSymCC (p);
   } else {
      Parser_Error (p, "'(' expected.", "");
      rc = 0;
   }

   l = p->cg->pc;

   Make_Boolean_Item (p, &x);  x.r = STACK_ONLY;
   if (!Assignment_Expression (p, &x))  rc = 0;
   Conditional_Jump (p, &x);

   Make_Link_Item (p, &ls, s->type, l, x.a, s->c, s->w);

   if (p->t->sym != SYM_RIGHT_PAREN) {
      Parser_Error (p, "')' expected at the end of the while condition.", "");
      while (p->t->sym != SYM_RIGHT_PAREN && p->t->sym != SYM_LEFT_BRACE &&
             p->t->sym != SYM_ELSE        && p->t->sym != SYM_SEMICOLON  &&
             p->t->sym != SYM_END         )
         GetSymCC (p);
   }

   GetSymCC (p);
   if (!Statement (p, &ls))  rc = 0;

   CG_Backward_Jump (p->cg, l);
   CG_Fix_Link (p->cg, ls.b);	/* end of while loop */
   s->c = ls.c;
   s->w = s->w - 1;
   return rc;
}


/**
 * \brief handle a break statement
 * \param p a pointer to the parser
 * \param s the associated link item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
break_Statement (struct _parser* p, struct _item* s) {
#ifdef DEBUG
   put_string (p->fd_err, "break_Statement().\n");
#endif
   if (!s->w)
      Parser_Error (p, "No surrounding while loop available.", "");

   GetSymCC (p);
   if (p->t->sym == SYM_SEMICOLON) {
      GetSymCC (p);
      if (s->w)   s->b = CG_Forward_Jump (p->cg, s->b);
      return 1;
   }

   Parser_Error (p, "';' expected.", "");  
   return 0;
}


/**
 * \brief handle a continue statement
 * \param p a pointer to the parser
 * \param s the associated link item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
continue_Statement (struct _parser* p, struct _item* s) {
#ifdef DEBUG
   put_string (p->fd_err, "continue_Statement().\n");
#endif
   if (!s->w)
      Parser_Error (p, "No surrounding while loop available.", "");

   GetSymCC (p);
   if (p->t->sym == SYM_SEMICOLON) {
      GetSymCC (p);
      if (s->w)  CG_Backward_Jump (p->cg, s->a);
      return 1;
   }

   Parser_Error (p, "';' expected.", "");  
   return 0;
}


/**
 * \brief handle a return statement
 * \param p a pointer to the parser
 * \param s the associated link item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
return_Statement (struct _parser* p, struct _item* s) {
   int rc;
   struct _item x;
#ifdef DEBUG
   char buf[100];
   put_string (p->fd_err, "return_Statement().\n");
#endif

   GetSymCC (p);
   if (p->t->sym == SYM_SEMICOLON) {
      if (s->type != p->st->voidType)
         Parser_Error (p, "Expected a value for return.", "");
      s->c = CG_Forward_Jump (p->cg, s->c);
      GetSymCC (p);
      return 1;
   }

   rc = 1;
   x.mode = CLASS_STACK;
   x.type = s->type;
   x.a = 0;
   x.b = 0;
   x.c = 0;
   x.w = 0;
   x.r = STACK_ONLY;
   if (!Assignment_Expression (p, &x)) rc = 0; 

#ifdef DEBUG
   put_string (p->fd_err, "return_Statement() before ';'.\n");
#endif

   if (p->t->sym == SYM_SEMICOLON)  {
      GetSymCC (p);
      if (x.mode != CLASS_STACK)  CG_Load (p->cg, &x);
      s->c = CG_Forward_Jump (p->cg, s->c);
      return rc;
   }

   Parser_Error (p, "';' expected.", "");
#ifdef DEBUG
   Parser_Error (p, "';' expected.", int_to_str (buf, 100, 10, __LINE__) );  
#endif
   SkipToSymCC (p, SYM_SEMICOLON);
   GetSymCC (p);

   return 0;
}


/**
 * \brief handle an assignment expression
 * \param p a pointer to the parser
 * \param sx the statement item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
Assignment_Expression (struct _parser* p, struct _item* sx) {
   int rc;
   int is_pointer;
   int is_struct;
   int is_type_cast;
   char ident[1024];
   int sp;
   struct _token* tok;
   struct _item x;
   struct _item y;
   struct _object* obj;
   int k;
#ifdef DEBUG
   put_string (p->fd_err, "Assignment_Expression().\n");
#endif

   tok = Token_Clone (p->t);

   rc = 1;
#if 0
   while (1) {
#endif
      sp = SetSavePoint (p);
#ifdef DEBUG
      put_string (p->fd_err, "Assignment_Expression() (loop).\n");
#endif
      is_pointer = 0;
      while (p->t->sym == SYM_ASTERISK) {
         is_pointer = is_pointer + 1;
         GetSymCC (p);
      }

      if (p->t->sym == SYM_INCREMENT) { Pre_Increment (p, &x); GetSymCC (p); } else
      if (p->t->sym == SYM_DECREMENT) { Pre_Decrement (p, &x); GetSymCC (p); }

      if (p->t->sym == SYM_IDENT) {
         strcpy (ident, p->t->id);
#ifdef DEBUG
         Parser_Info (p, "Identifier=", ident);
#endif
         GetSymCC (p);

         obj = Find (p, ident, 1);
         if (obj) {
            if (obj->cls == CLASS_VAR || obj->cls == CLASS_PARAM)  Make_Item (p, &x, obj);
            else Parser_Error (p, "Variable expected for item: ", ident);
         }

         rc = Selector (p, &x);

         if (p->t->sym == SYM_INCREMENT) { Post_Increment (p, &x); GetSymCC (p); } else
         if (p->t->sym == SYM_DECREMENT) { Post_Decrement (p, &x); GetSymCC (p); }
      }

      if (rc && p->t->sym == SYM_EQUAL) {
         Release (p, sp);
         GetSymCC (p);
         Token_Destroy (tok);
         tok = Token_Clone (p->t);
         k = is_pointer;
         while (k)  {
            Unary_Operator (p, SYM_ASTERISK, &x);
            k = k - 1;
        }
      } else {
         Rewind (p, sp);
         x.mode = CLASS_VOID;
#if 0
         break;
#endif
      }
#if 0
   }
#endif

#ifdef DEBUG
   put_string (p->fd_err, "Assignment_Expression() after loop.\n");
#endif
   rc = 1;
   if (tok) {
      Token_Destroy(p->t);
      p->t = tok;
      tok = (struct _token*)0;
#ifdef DEBUG
      Print_Token (p);
#endif
   } else {
      GetSymCC (p);
   }

   is_type_cast = 0;
   if (p->t->sym == SYM_LEFT_PAREN) {	/* Typecast or Assignment ? */
      tok = Token_Clone (p->t);
      sp = SetSavePoint (p);
      GetSymCC (p);
      is_struct = 0;
      if (p->t->sym == SYM_STRUCT) {
         is_struct = is_struct + 1;
         GetSymCC (p);
         /* TODO: implement? */
      }
   
      if (p->t->sym == SYM_IDENT || is_SimpleType (p->t->sym)) {
         ident[0] = '\0';
         if (is_struct)
            strcat (ident, "struct ");
         strcat (ident, p->t->id);
         obj = Find (p, ident, 1);
         if (obj) {
            if (obj->cls != CLASS_TYPE)  rc = 0;
         } else rc = 0;
         GetSymCC (p);

         is_pointer = 0;
         while (p->t->sym == SYM_ASTERISK) {
            is_pointer = is_pointer + 1;
            GetSymCC (p);
         }

         if (p->t->sym != SYM_RIGHT_PAREN)  rc = 0;
      } else {
         rc = 0;
      }

      if (rc) {
         Token_Destroy(tok);
         Release (p, sp);
         is_type_cast = 1;
#ifdef DEBUG
         put_string (p->fd_err, "Assignment_Expression() typecast found to: (");
         put_string (p->fd_err, ident);
         k = is_pointer;  while (k) { put_string (p->fd_err, "*"); k = k - 1; }
         put_string (p->fd_err, ")\n");
#endif
         GetSymCC (p);
      } else {
         Rewind (p, sp);
         Token_Destroy(p->t);
         p->t = tok;
      }
   }

   if (sx->mode == CLASS_VOID && x.mode == CLASS_VOID)
      Make_Void_Item (p, &y);
   else
      Make_Boolean_Item (p, &y);        // y.r = STACK_ONLY;
   rc = Logical_Or_Expression (p, &y);

   if (is_type_cast) {
      obj = Find (p, ident, 1);
      if (obj) {
         if (y.type->form == FORM_ARRAY && y.lev > 0) {
            if (y.mode != CLASS_STACK)  CG_Load (p->cg, &y);
            CG_Put (p->cg, INSTR_PUSH_FP, 0, 0);
            CG_Put (p->cg, INSTR_ADD_I, 0, 0);
         }
         y.type = obj->type;
         k = is_pointer;
         while (k) {
            y.type = Type_Create (FORM_POINTER, 0, SIZE_OF_PTR,
                                  (struct _object*)0, y.type);
            k = k - 1;
         }
         if (y.mode == CLASS_COND)  y.mode = CLASS_STACK;
      } else Parser_Error (p, "Can not cast to unknown type: ", ident);
      /* TODO: consider the stack if using long and double */
   }

   if (x.mode == CLASS_VOID) {
      Store (p, sx, &y);
   } else {
      if (sx->mode != CLASS_VOID)  x.r = STACK_DUP;
      Store (p, &x, &y);
   }
   sx->a = y.a;
   sx->b = y.b;
   sx->c = y.c;

   return rc;
}

#if 0
/**
 * \brief handle a list value
 * \param p a pointer to the parser
 * \param sym the previous symbol
 * \param x a pointer to the actual item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
List_Value (struct _parser* p, int sym, struct _item* x) {
   int rc;
   char ident[64];
   struct _object* obj;
#ifdef DEBUG
   put_string (p->fd_err, "List_Value().\n");
#endif

   rc = 1;
   if (p->t->sym == SYM_IDENT) {
      strcpy (ident, p->t->id);
#ifdef DEBUG
      Parser_Info (p, "Identifier=", ident);
#endif
      GetSymCC (p);

      obj = Find (p, ident, 1);
      if (obj) {
         if (obj->cls == CLASS_VAR || x->mode == CLASS_PARAM) {
            Make_Item (p, x, obj);
         } else {
            Parser_Error (p, "Variable expected for item: ", ident);
         }
      }

      if (p->t->sym == SYM_LEFT_BRACK) {
         GetSymCC (p);
         rc = Logical_Or_Expression (p, x);
         if (p->t->sym == SYM_RIGHT_BRACK) {
            GetSymCC (p);
         } else {
            Parser_Error (p, "']' expected instead of: ", p->t->id);
            rc = 0;
         }
      }
      /* TODO: implement ? */
   }

   return rc;
}
#endif


/**
 * \brief handle a selector
 * \param p a pointer to the parser
 * \param x a pointer to the actual item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
Selector (struct _parser* p, struct _item* x) {
   int rc;
   char ident[64];
   struct _object* obj;
   struct _item y;
   struct _type* type;

   rc = 1;
   strcpy (ident, p->t->id);
#ifdef DEBUG
   Parser_Info (p, "Selector(). Identifier=", ident);
#endif

   while (rc && (p->t->sym == SYM_LEFT_BRACK ||
                 p->t->sym == SYM_PERIOD     ||
                 p->t->sym == SYM_ARROW        ) )
   {
      if (p->t->sym == SYM_LEFT_BRACK) {
         GetSymCC (p);
//       rc = Assignment_Expression (p, &y);
         rc = Logical_Or_Expression (p, &y);
         if (x->type->form == FORM_ARRAY || x->type->form == FORM_POINTER) Index (p, x, &y);
         else Parser_Error (p, "Expected an array or pointer for identifier ", ident);
         if (p->t->sym == SYM_RIGHT_BRACK) {
            GetSymCC (p);
         } else {
            Parser_Error (p, "']' expected instead of: ", p->t->id);
            rc = 0;
         }
      } else

      if (p->t->sym == SYM_PERIOD) {
         GetSymCC (p);

         if (p->t->sym == SYM_IDENT) {
            if (x->type->form == FORM_STRUCTURE) {
               strcpy (ident, p->t->id);
               obj = FindField (p, x->type->fields);
               if (obj != p->st->guard)  Field (p, x, obj);
               else Parser_Error (p, "Undefined field item: ", ident);
               GetSymCC (p);
            } else Parser_Error (p, "Expected a struct or union for identifier ", ident);
         } else Parser_Error (p, "Expected an identifier instead of ", p->t->id);
      } else

      { /* p->t->sym == SYM_ARROW */
         GetSymCC (p);
         if (p->t->sym == SYM_IDENT) {
            if (x->type->form == FORM_POINTER) {
               strcpy (ident, p->t->id);
//             type = x->type;
//             while (type->form == FORM_POINTER)	/* TODO: check: only once? */
//                type = type->base;
               type = x->type->base;			/* TODO: check */
               obj = FindField (p, type->fields);
               if (obj != p->st->guard)  PointerField (p, x, obj);
               else Parser_Error (p, "Undefined field item: ", ident);
               GetSymCC (p);
            } else Parser_Error (p, "Expected a pointer to a struct or union for identifier ", ident);
         } else Parser_Error (p, "Expected an identifier instead of ", p->t->id);
      }
      
   }

   return rc;
}



/**
 * \brief handle a logical or expression
 * \param p a pointer to the parser
 * \param x the statement item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
Logical_Or_Expression (struct _parser* p, struct _item* x) {
   int rc;
   struct _item y;
#ifdef DEBUG
   put_string (p->fd_err, "Logical_Or_Expression().\n");
#endif
   Item_Copy (&y, x);

   rc = Logical_And_Expression (p, x);
   while (p->t->sym == SYM_LOGICAL_OR) {
      GetSymCC (p);
      Unary_Operator (p, SYM_LOGICAL_OR, x);
      if (!Logical_And_Expression (p, &y))  rc = 0;
      Dual_Operator (p, SYM_LOGICAL_OR, x, &y);
   }

   return rc;
}


/**
 * \brief handle a logical and expression
 * \param p a pointer to the parser
 * \param x the statement item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
Logical_And_Expression (struct _parser* p, struct _item* x) {
   int rc;
   struct _item y;
#ifdef DEBUG
   put_string (p->fd_err, "Logical_And_Expression().\n");
#endif
   Item_Copy (&y, x);

   rc = Conditional_Expression (p, x);
   while (p->t->sym == SYM_LOGICAL_AND) {
      GetSymCC (p);
      Unary_Operator (p, SYM_LOGICAL_AND, x);
      if (!Conditional_Expression (p, &y))  rc = 0;
      Dual_Operator (p, SYM_LOGICAL_AND, x, &y);
   }

   return rc;
}


/**
 * \brief handle a conditional expression
 * \param p a pointer to the parser
 * \param x the statement item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
Conditional_Expression (struct _parser* p, struct _item* x) {
   int rc;
   int op;
   struct _item y;
   int cnd;
#ifdef DEBUG
   put_string (p->fd_err, "Conditional_Expression().\n");
#endif
   Item_Copy (&y, x);

   cnd = 0;
   if (x->mode == CLASS_COND)	/* if, while with only one bool variable ? */
      cnd = 1;

   rc = Simple_Expression (p, x);

   if (p->t->sym == SYM_LEFT_ANGLE_BRACK ||
       p->t->sym == SYM_CMP_LE ||
       p->t->sym == SYM_CMP_EQ ||
       p->t->sym == SYM_CMP_NEQ ||
       p->t->sym == SYM_CMP_GE ||
       p->t->sym == SYM_RIGHT_ANGLE_BRACK)
   {
      op = p->t->sym;
      GetSymCC (p);
      if (!Simple_Expression (p, &y)) rc = 0;
      Relation (p, op, x, &y);
      cnd = 0;
   }

   if (!x->c && cnd)		/* this ensures emiting a branch instruction */
      x->c = SYM_CMP_NEQ;	/* without having called Relation() below */

   return rc;
}


/**
 * \brief handle a simple expression
 * \param p a pointer to the parser
 * \param x a pointer to the actual item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
Simple_Expression (struct _parser* p, struct _item* x) {
   int rc;
   int unary_op;
   struct _item y;
   int sym;
#ifdef DEBUG
   put_string (p->fd_err, "Simple_Expression().\n");
#endif
   Item_Copy (&y, x);

   unary_op = Get_Unary_Operator (p);
   rc = Term (p, x);
   Unary_Operator (p, unary_op, x);
   if (x->mode == CLASS_IND)  CG_Load (p->cg, x);

   while (p->t->sym == SYM_PLUS ||
          p->t->sym == SYM_MINUS ||
          p->t->sym == SYM_BAR)
   {
      sym = p->t->sym;
      GetSymCC (p);
      unary_op = Get_Unary_Operator (p);
      if (!Term (p, &y)) rc = 0;
      Unary_Operator (p, unary_op, &y);
      Dual_Operator (p, sym, x, &y);
   }

   return rc;
}


/**
 * \brief handle a term
 * \param p a pointer to the parser
 * \param x the statement item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
Term (struct _parser* p, struct _item* x) {
   int rc;
   struct _item y;
   int sym;
#ifdef DEBUG
   put_string (p->fd_err, "Term().\n");
#endif
   Item_Copy (&y, x);

   rc = Factor (p, x);

   if (p->t->sym == SYM_ASTERISK   || p->t->sym == SYM_DIVIDE     ||
       p->t->sym == SYM_REMINDER   || p->t->sym == SYM_AMPERSAND  ||
       p->t->sym == SYM_LEFT_SHIFT || p->t->sym == SYM_RIGHT_SHIFT  )
   {
      sym = p->t->sym;
      GetSymCC (p);
      if (!Factor (p, &y))  rc = 0;
      Dual_Operator (p, sym, x, &y);
   }

   return rc;
}


/**
 * \brief check if object is a function parameter
 * \param par a pointer to the parameter object
 * \return != 0 if par is a parameter, otherwise 0
 *****************************************************************************/

int
Is_Parameter (struct _object* par) {
   if (!par)  return 0;
   if (par->cls == CLASS_PARAM)  return 1;
   return 0;
}


/**
 * \brief check if two type descriptions are equivalent
 * \param a pointer to the first type description
 * \param b a pointer to the second type description
 * \return != 0 if the two type descriptions are equivalent
 *****************************************************************************/

int
Is_Type_Equal (struct _type* a, struct _type* b) {
   while (a->form == FORM_POINTER && (b->form == FORM_POINTER || b->form == FORM_ARRAY) ) {
      a = a->base;  b = b->base;
   }
   if (a == b)  return 1;
   return 0;
}


/**
 * \brief handle a factor
 * \param p a pointer to the parser
 * \param x the statement item
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
Factor (struct _parser* p, struct _item* x) {
   int rc;
   int adr;
   int pre_inc;
   char ident[64];
   struct _object* obj;
   struct _object* par;
   struct _item y;
#ifdef DEBUG
   put_string (p->fd_err, "Factor().\n");
#endif

   rc = 1;
   if (p->t->sym == SYM_SIZEOF) {
      GetSymCC (p);
      if (p->t->sym == SYM_LEFT_PAREN) {
         GetSymCC (p);
      } else {
         Parser_Error (p, "'(' expected.", "");
         rc = 0;
      }
      ident[0] = '\0';
      obj = (struct _object*)0;
      if (p->t->sym == SYM_STRUCT) {
         strcat (ident, "struct ");
         GetSymCC (p);
      }
      if (p->t->sym == SYM_IDENT || is_SimpleType (p->t->sym)) {
         strcat (ident, p->t->id);
         GetSymCC (p);
         obj = Find (p, ident, 1);
      }
      if (p->t->sym == SYM_RIGHT_PAREN) {
         if (!ident[0]) {
            Parser_Error (p, "type name missing before ')'.", "");
            rc = 0;
         }
         GetSymCC (p);
         Make_Const_Item (p, x, p->st->intType, obj->type->size);
      } else {
         Parser_Error (p, "')' expected.", "");
         rc = 0;
         Make_Const_Item (p, x, p->st->intType, 0);
      }
      return rc;
   }

   if (p->t->sym == SYM_LITERAL) {
//    adr = CG_Put_Global_Data (p->cg, p->t->id, strlen (p->t->id)+1, 1);
      adr = CG_Put_Global_Data (p->cg, p->t->id, p->t->num, 1);
      Make_Const_Item (p, x, p->st->charPtrType, adr);
      x->mode = CLASS_IND_DATA;
      GetSymCC (p);
      return 1;
   }

   if (p->t->sym == SYM_CHARACTER) {
      Make_Const_Item (p, x, p->st->charType, (int)p->t->id[0]);
      GetSymCC (p);
      return 1;
   }

   if (p->t->sym == SYM_NUMBER || 
       p->t->sym == SYM_OCT_NUMBER ||
       p->t->sym == SYM_HEX_NUMBER)
   {
      Make_Const_Item (p, x, p->st->intType, p->t->num);
      GetSymCC (p);
      return 1;
   }

   if (p->t->sym == SYM_LEFT_PAREN) {
      GetSymCC (p);
#if 1
      Make_Boolean_Item (p, x);  x->r = STACK_ONLY;	// TODO: just a guess.
#else
//    x->mode = CLASS_STACK;
//    x->a = 0; x->b = 0; x->c = 0; x->w = 0;
      x->r = STACK_ONLY;
#endif
//    rc = Logical_Or_Expression (p, x);
      rc = Assignment_Expression (p, x);
      if (p->t->sym == SYM_RIGHT_PAREN) {
         GetSymCC (p);
         /* TODO: implementation */
      } else {
         Parser_Error (p, "')' expected.", "");
         rc = 0;
      }
      return rc;
   }

   pre_inc = 0;
   if (p->t->sym == SYM_INCREMENT) { pre_inc = 1;  GetSymCC (p); } else
   if (p->t->sym == SYM_DECREMENT) { pre_inc = -1; GetSymCC (p); }

   if (p->t->sym == SYM_IDENT) {
      strcpy (ident, p->t->id);
#ifdef DEBUG
      Parser_Info (p, "Factor(): Identifier=", ident);
#endif
      obj = Find (p, ident, 1);
      if (obj) Make_Item (p, x, obj);
      else Parser_Error (p, "Undefinded item ", ident);

      GetSymCC (p);
      if (p->t->sym == SYM_LEFT_PAREN) {	/* a function call */
         /* TODO: check for predefined functions */

         if (pre_inc)
            Parser_Error (p, "Pre increment/decrement is not allowed with functions.", "");

         par = (struct _object*)0;
         if (obj) {
            if (obj->cls != CLASS_FUNC && obj->cls != CLASS_SFUNC && obj->cls != CLASS_FUNC_PR)
               Parser_Error (p, "Item is not a function: ", ident);
            par = obj->dsc;
         }

         GetSymCC (p);
         while (p->t->sym != SYM_RIGHT_PAREN) {
            Make_Item (p, &y, par); y.r = STACK_ONLY;
//          if (!Logical_Or_Expression (p, &y))  rc = 0;
            if (!Assignment_Expression (p, &y))  rc = 0;
            if (obj) {
               if (Is_Parameter (par))  {
                  if (Is_Type_Equal (y.type, par->type)) {
//                   if (y.mode != CLASS_STACK)  CG_Load (p->cg, &y);
                  } else Parser_Error (p, "Bad parameter type for function ", ident);
                  par = par->next;
               } else Parser_Error (p, "Too many parameters for function ", ident);
            }
            if (p->t->sym != SYM_COMMA) break;
            GetSymCC (p);
         }

         if (p->t->sym == SYM_RIGHT_PAREN) {
            GetSymCC (p);
            if (obj) {
               if (obj->val < 0)  Parser_Error (p, "Forward Call ??", "");
               else if (!Is_Parameter (par)) {
                  if (obj->cls == CLASS_FUNC || obj->cls == CLASS_FUNC_PR)
                     CG_Call (p->cg, x, ident);
                  else CG_Call_Predefined (p->cg, x, ident);
               } else Parser_Error (p, "To few parameters specified for function ", ident);
            }
         } else {
            Parser_Error (p, "')' expected.", "xx");
            GetSymCC (p);
            rc = 0;
         }

      } else {
         rc = Selector (p, x);

         if (p->t->sym == SYM_INCREMENT) {
            Post_Increment (p, x); GetSymCC (p);
         } else
         if (p->t->sym == SYM_DECREMENT) {
            Post_Decrement (p, x); GetSymCC (p);
         }
      }

#ifdef DEBUG
      put_string (p->fd_err, "Factor(): identifier 2.\n");
#endif
      return rc;
   }

   /* TODO: check: delete from here to the end of the function */
// Parser_Error (p, "Factor(): I cannot come here!", "");
   Parser_Error (p, "Unexpected literal found: ", p->t->id);
#if 0
   if (p->t->sym == SYM_INCREMENT) {
      Pre_Increment (p, x); GetSymCC (p);
   } else
   if (p->t->sym == SYM_DECREMENT) {
      Pre_Decrement (p, x); GetSymCC (p);
   }

   rc = List_Value (p, SYM_OTHER, x);

   rc = Selector (p, x);

   if (p->t->sym == SYM_INCREMENT) {
      Post_Increment (p, x); GetSymCC (p);
   } else
   if (p->t->sym == SYM_DECREMENT) {
      Post_Decrement (p, x); GetSymCC (p);
   }
#endif
   return rc;
}


/**
 * \brief the C compiler parser
 * \param p a pointer to the parser
 * \return 1 on success, otherwise 0
 *****************************************************************************/

int
cc_parse (struct _parser* p) {
   int rc;
   rc = 1;

   GetSymCC (p);
   while ( p->t->sym != SYM_END) {
      if (!Declaration_Statement (p, 0))  rc = 0;
      if (p->t->sym == SYM_SEMICOLON)  GetSymCC (p);
   }

#ifdef DEBUG
   SymTab_Dump (p->st, 0, p->fd_err);
   put_string (p->fd_err, "\n\n");
   CodeGen_Dump (p->cg, p->fd_err);
#endif

   /* TODO: check symbol table for incomplete forward declarated types */
   if (p->errors || p->warnings) {
      put_string (p->fd_err, "Compilation summary: ");
      put_int    (p->fd_err, p->errors);
      put_string (p->fd_err, " errors, ");
      put_int    (p->fd_err, p->warnings);
      put_string (p->fd_err, " warnings");
#ifdef DEBUG
      put_string (p->fd_err, ", ");
      put_int    (p->fd_err, p->infos);
      put_string (p->fd_err, " infos ");
#endif
      put_string (p->fd_err, ".\n");
   }

   if (p->errors)  return 0;

   return rc;
}


/**
 * \brief create a new object node
 * \param p a pointer to the parser
 * \param cls the object class
 * \param ident the name of the identifier
 * \return a pointer to the new object
 *****************************************************************************/

struct _object*
NewObj (struct _parser* p, class_t cls, char* ident) {
   struct _object* new;
   struct _object* x;

   x = p->st->topScope;
   if (p->st->guard->name)  free ((void*)p->st->guard->name);
   p->st->guard->name = strdup (ident);

   while ( strcmp (x->next->name, ident) != 0 )  x = x->next;
   if (x->next == p->st->guard) {
      new = Object_Create (ident, cls, 0, (struct _type*)0, 0,
                           p->st->guard, (struct _object*)0 );
      x->next = new;
      return new;
   }

   /* this is how we handle a forward declaration of pointers to types:
    * the type field remains empty and is filled whenever the real
    * declaration appears in the code.
    */
   if (x->next->type && x->next->cls != CLASS_FUNC_PR)
      Parser_Error (p, "multiple defined symbol: ", ident);

   return x->next;
}


/**
 * \brief delete an object from the symbol table
 * \param p a pointer to the parser
 * \param o a pointer to the object to be deleted
 *****************************************************************************/

void
DelObj (struct _parser* p, struct _object* o) {
   struct _object* s;
   struct _object* x;

   s = p->st->topScope;

   while (1) {
      x = s;
      while (x->next != o && x->next != p->st->guard)  x = x->next;
      if (x->next == o) {
         x->next = o->next;
         Object_Destroy (o);
         break;
      }
      if (s == p->st->universe) break;
      s = s->dsc;
   }

}


/**
 * \brief find an object
 * \param p a pointer to the parser
 * \param ident the name of the identifier
 * \param err print an error message if the identifier is not found
 * \return a pointer to the found object
 *****************************************************************************/

struct _object*
Find (struct _parser* p, char* ident, int err) {
   struct _object* s;
   struct _object* x;

   s = p->st->topScope;
   if (p->st->guard->name)  free ((void*)p->st->guard->name);
   p->st->guard->name = strdup (ident);

   while (1) {
      x = s->next;
      while ( strcmp (x->name, ident) )
         x = x->next;
      if (x != p->st->guard)  return x;
      if (s == p->st->universe) {
         if (err) Parser_Error (p, "undefined symbol: ", ident);
//       return x;
         return (struct _object*)0;
      }
      s = s->dsc;
   }
}


/**
 * \brief find an object field
 * \param p a pointer to the parser
 * \param list the field list
 * \return a pointer to the found object field
 *****************************************************************************/

struct _object*
FindField (struct _parser* p, struct _object* list) {
   if (p->st->guard->name)  free ((void*)p->st->guard->name);
   p->st->guard->name = strdup (p->t->id);

   while ( strcmp (list->name, p->t->id) != 0 )  list = list->next;
   return list;
}


/**
 * \brief compare the types of two field lists
 * \param p a pointer to the parser
 * \param f1 the first field list
 * \param f2 the second field list
 * \return 1 if the field list have the same types in the same order, otherwise 0
 *****************************************************************************/

int
Compare_Field_Types (struct _parser* p, struct _object* f1, struct _object* f2) {
   struct _type* t1;
   int is_ptr1;
   struct _type* t2;
   int is_ptr2;
   int rc;
   int n;
   char buf[20];
#ifdef DEBUG
   put_string (p->fd_err, "Compare_Field_Types().\n");
#endif
   rc = 1;
   n = 0;

   while (f1 != p->st->guard && f2 != p->st->guard) {
      t1 = f1->type;
      t2 = f2->type;
      is_ptr1 = 0;  while (t1->form == FORM_POINTER) { is_ptr1 = is_ptr1 + 1; t1 = t1->base; }
      is_ptr2 = 0;  while (t2->form == FORM_POINTER) { is_ptr2 = is_ptr2 + 1; t2 = t2->base; }
      if (t1->form != t2->form || is_ptr1 != is_ptr2) {
         Parser_Error (p, "Type mismatch for parameter: ", int_to_str(buf, 20, 10, n) );
         rc = 0;
      }
      f1 = f1->next;
      f2 = f2->next;
   }

   if (f1 != p->st->guard || f2 != p->st->guard) {
      Parser_Error (p, "The number of parameters differ.", "");
      rc = 0;
   }

   return rc;
}


/**
 * \brief destroy a field list
 * \param p a pointer to the parser
 * \param f the field list to be destroyed
 *****************************************************************************/

void
Destroy_Fields (struct _parser* p, struct _object* f) {
#if 0
   struct _object* o;
   struct _type* t;
#endif
#ifdef DEBUG
   put_string (p->fd_err, "Destroy_Fields(). not implemented.\n");
#endif
#if 0
   while (f != p->st->guard) {
      o = f;
      f = f->next;
      while (o->type->form == FORM_POINTER) {
         t = o->type;
         o->type = o->type->base;
         free ((void*)t);
      }
      if (o->name)  free ((void*)o->name);
      free ((void*)o);
   }
#endif
}


/**
 * \brief create a named item
 * \param p a pointer to the parser structure
 * \param x a pointer to the item structure
 * \param obj a pointer to the corresponding object
 *****************************************************************************/

void
Make_Item (struct _parser* p, struct _item* x, struct _object* obj) {
   if (!obj)  return;

   x->mode = obj->cls;
   x->type = obj->type;
   x->lev = obj->lev;
   x->a = obj->val;
   x->b = 0;
   x->c = 0;
   x->w = 0;
   x->r = STACK_NONE;

   if (!obj->lev) {			/* load immediate from main memory */
      x->r = REG_ABSOLUTE;
   } else
   if (obj->lev == p->cg->curlev) {	/* load indirect with FP */
      x->r = REG_FRAME;
   } else {
      Parser_Error (p, "Invalid levels at item creation!\n", "");
#ifdef DEBUG
      put_string (p->fd_err, "Levels are: obj->lev = ");
      put_int    (p->fd_err, obj->lev);
      put_string (p->fd_err, ",  p->cg->curlev = ");
      put_int    (p->fd_err, p->cg->curlev);
      put_string (p->fd_err, "\n");
#endif
      x->r = REG_UNKNOWN;
   }
}


/**
 * \brief create a named item
 * \param p a pointer to the parser
 * \param x a pointer to the item structure
 * \param typ a pointer to the type description of the constant
 * \param val the address in the data segment ?
 *****************************************************************************/

void
Make_Const_Item (struct _parser* p, struct _item* x, struct _type* typ, int val) {
   x->mode = CLASS_CONST;
   x->type = typ;
   x->a = val;
   x->b = 0;
   x->c = 0;
   x->w = 0;
   x->r = STACK_NONE;
}


/**
 * \brief create a link item
 * \param p a pointer to the parser
 * \param x a pointer to the item structure
 * \param typ a pointer to the type description of the function
 * \param st the start address of the surrounding block
 * \param end the end address of the surrounding block
 * \param ret the return address of the surrounding subroutine
 * \param wl if != 0 a surrounding while loop exists
 *****************************************************************************/

void
Make_Link_Item (struct _parser* p, struct _item* x, struct _type* typ, int st,
                int end, int ret, int wl)
{
   x->mode = CLASS_LINK;
   x->type = typ;
   x->a = st;
   x->b = end;
   x->c = ret;
   x->w = wl;
   x->r = STACK_NONE;
}


/**
 * \brief create a void item
 * \param p a pointer to the parser
 * \param x a pointer to the item structure
 *****************************************************************************/

void
Make_Void_Item (struct _parser* p, struct _item* x) {
   x->mode = CLASS_VOID;
   x->type = p->st->voidType;
   x->a = 0;
   x->b = 0;
   x->c = 0;
   x->w = 0;
   x->r = STACK_NONE;
}


/**
 * \brief create a boolean item
 * \param p a pointer to the parser
 * \param x a pointer to the item structure
 *****************************************************************************/

void
Make_Boolean_Item (struct _parser* p, struct _item* x) {
   x->mode = CLASS_COND;
   x->type = p->st->boolType;
   x->a = 0;
   x->b = 0;
   x->c = 0;
   x->w = 0;
   x->r = STACK_NONE;
}


/**
 * \brief create a temporary item
 * \param p a pointer to the parser
 * \param x a pointer to the item structure
 * \param md the item's mode
 * \param ty the item's type
 *****************************************************************************/

void
Make_Temp_Item (struct _parser* p, struct _item* x, class_t md, struct _type* ty) {
   x->mode = md;
   x->type = ty;
   x->lev = p->cg->curlev;	/* TODO: check this */
   x->a = 0;
   x->b = 0;
   x->c = 0;
   x->w = 0;
   x->r = STACK_NONE;
}


/**
 * \brief increment a given variable before its use
 * \param p a pointer to the parser
 * \param x a pointer to the item structure
 *****************************************************************************/

void
Pre_Increment (struct _parser* p, struct _item* x) {
#ifdef DEBUG
   Parser_Error (p, "Pre_Increment() is not (yet) implemented.", "");
#endif
}

/**
 * \brief decrement a given variable before its use
 * \param p a pointer to the parser
 * \param x a pointer to the item structure
 *****************************************************************************/

void
Pre_Decrement (struct _parser* p, struct _item* x) {
#ifdef DEBUG
   Parser_Error (p, "Pre_Decrement() is not (yet) implemented.", "");
#endif
}


/**
 * \brief increment a given variable after its use
 * \param p a pointer to the parser
 * \param x a pointer to the item structure
 *****************************************************************************/

void
Post_Increment (struct _parser* p, struct _item* x) {
#ifdef DEBUG
   Parser_Error (p, "Post_Increment() is not (yet) implemented.", "");
#endif
}


/**
 * \brief decrement a given variable after its use
 * \param p a pointer to the parser
 * \param x a pointer to the item structure
 *****************************************************************************/

void
Post_Decrement (struct _parser* p, struct _item* x) {
#ifdef DEBUG
   Parser_Error (p, "Post_Decrement() is not (yet) implemented.", "");
#endif
}


/**
 * \brief array access
 * \param p a pointer to the parser
 * \param x a pointer to the item structure
 * \param y a pointer to the item structure
 *
 * this subroutine is responsible to emit code for this construct x = x[y]
 *****************************************************************************/

void
Index (struct _parser* p, struct _item* x, struct _item* y) {
   if (y->type != p->st->intType)
      Parser_Error (p, "Array index is not of type integer!", "");

   if (y->mode == CLASS_CONST && x->type->form == FORM_ARRAY) {
      if (y->a < 0 || y->a >= x->type->len)
         Parser_Error (p, "Bad array index!", "");
      x->a = x->a + y->a * x->type->base->size;
      if (x->mode == CLASS_IND) {
         if (x->a) {
            CG_Put (p->cg, INSTR_PUSH_I, x->a, 0);
            CG_Put (p->cg, INSTR_ADD_I, 0, 0);
         }
         x->a = 0;
      }
   } else {
#ifdef DEBUG
   Parser_Warning (p, "Index() is not (yet) fully implemented.", "");
#endif
      if (x->mode != CLASS_STACK && y->mode == CLASS_STACK) {
         if (x->type->base->size > 1) {
            CG_Put (p->cg, INSTR_PUSH_I, x->type->base->size, 0);
            CG_Put (p->cg, INSTR_MUL_I, 0, 0);
         }
         CG_Load (p->cg, x);
      } else {
         if (x->mode != CLASS_STACK)  CG_Load (p->cg, x);
         if (y->mode != CLASS_STACK)  CG_Load (p->cg, y);
         /* TODO: check array bounds at runtime */
         if (x->type->base->size > 1) {
            CG_Put (p->cg, INSTR_PUSH_I, x->type->base->size, 0);
            CG_Put (p->cg, INSTR_MUL_I, 0, 0);
         }
      }
      CG_Put (p->cg, INSTR_ADD_I, 0, 0);
      if (x->type->form == FORM_ARRAY && x->lev > 0) {
         CG_Put (p->cg, INSTR_PUSH_FP, 0, 0);
         CG_Put (p->cg, INSTR_ADD_I, 0, 0);
      }
      x->mode = CLASS_IND;
   }
   x->type = x->type->base;
}


/**
 * \brief struct field access x = x.y
 * \param p a pointer to the parser
 * \param x a pointer to the item structure
 * \param y a pointer to the object structure
 *****************************************************************************/

void
Field (struct _parser* p, struct _item* x, struct _object* y) {
   x->a = x->a + y->val;
   x->type = y->type;
   if (x->mode == CLASS_IND) {
      if (x->a) {
         CG_Put (p->cg, INSTR_PUSH_I, x->a, 0);
         CG_Put (p->cg, INSTR_ADD_I, 0, 0);
      }
//    x->mode = CLASS_STACK;
      x->a = 0;
      x->lev = 0;
   }
}


/**
 * \brief struct field access x = x->y
 * \param p a pointer to the parser
 * \param x a pointer to the item structure
 * \param y a pointer to the object structure
 *****************************************************************************/

void
PointerField (struct _parser* p, struct _item* x, struct _object* y) {
   int cl;
#ifdef DEBUG
   Parser_Warning (p, "PointerField() is not (yet) fully implemented.", "");
#endif
   cl = x->mode;
   if (x->mode != CLASS_STACK)  CG_Load (p->cg, x);
   if (y->val) {
      CG_Put (p->cg, INSTR_PUSH_I, y->val, 1);
      CG_Put (p->cg, INSTR_ADD_I, 0, 0);
   }
   if ( (cl == CLASS_PARAM || cl == CLASS_VAR) &&
        (x->type->form == FORM_POINTER || x->type->form == FORM_ARRAY) ) {
      x->lev = 0;
   }
   x->mode = CLASS_IND;
   x->r = REG_STACK;
   x->type = y->type;
}


/**
 * \brief load a boolean variable onto the stack
 * \param p a pointer to the parser
 * \param x the item to be loaded
 *****************************************************************************/

void
Load_Boolean (struct _parser* p, struct _item* x) {
   if (x->type->form != FORM_BOOLEAN  &&
       x->type->form != FORM_CHAR     &&
       x->type->form != FORM_INTEGER  &&
       x->type->form != FORM_POINTER     )
      Parser_Error (p, "This is no boolean expression!", "");

   CG_Load (p->cg, x);
/*
   if (x->type->form != FORM_BOOLEAN) {
      CG_Put_Branch (p->cg, INSTR_BEQ, 5);
      CG_Put (p->cg, INSTR_LDC_I_1, 0, 0);
      CG_Put (p->cg, INSTR_LDC_I_0, 0, 0);
      CG_Put_Branch (p->cg, INSTR_BEQ, 1);
      CG_Put (p->cg, INSTR_LDC_I_0, 0, 0);
   }
*/

   x->mode = CLASS_COND;
   x->a = 0;
   x->b = 0;
   x->c = SYM_CMP_NEQ;
}


/**
 * \brief store a variable x = y;
 * \param p a pointer to the parser
 * \param x the item where y should be stored
 * \param y the item of the calculated value
 *****************************************************************************/

void
Store (struct _parser* p, struct _item* x, struct _item* y) {
#ifdef DEBUG
   char buf[50];
#endif
   if (x->mode == CLASS_VOID) {
      if (y->type->form != FORM_VOID)
         CG_Put (p->cg, INSTR_POP, 0, 0);	/* TODO: check for long and double */
      return;
   }
#ifdef DEBUG
   put_string (p->fd_err, "Store() x->type=0x");
   put_string (p->fd_err, int_to_str (buf, 50, 16, (int)(x->type)));
   put_two_string_nl (p->fd_err, "   y->type=0x", int_to_str (buf, 50, 16, (int)(y->type)));
#endif

   if (x->type->form == y->type->form                                        ||
       (x->type->form == FORM_POINTER && y->type->form == FORM_ARRAY)        ||
       (x->type->form == FORM_BOOLEAN && 
          (y->type->form == FORM_CHAR || y->type->form == FORM_INTEGER ||
           y->type->form == FORM_POINTER || y->type->form == FORM_ARRAY)   ) ||
       ( (x->type->form == FORM_CHAR || x->type->form == FORM_INTEGER) &&
          y->type->form == FORM_BOOLEAN)    )
   {
      if (y->mode == CLASS_COND) {
         if (x->r == STACK_ONLY)  return;
         /* TODO: check the whole thing */
         CG_Put_Cond_Operator (p->cg, CG_Negated_Operator (y->c), y->a, 0);
         y->a = p->cg->pc - 2;
         CG_Fix_Link (p->cg, y->b);
         CG_Put (p->cg, INSTR_LDC_I_1, 0, 0);
         CG_Put (p->cg, INSTR_LDC_I_0, 0, 0);
         CG_Put_Branch (p->cg, INSTR_BEQ, 1);
         CG_Fix_Link (p->cg, y->a);
         CG_Put (p->cg, INSTR_LDC_I_0, 0, 0);
         y->mode = CLASS_STACK;
//       if (x->type->form == FORM_CHAR || x->type->form == FORM_INTEGER) {
//          /* implicit cast to char or int */
//          return;
//       }
      } else if (y->mode != CLASS_STACK)  CG_Load (p->cg, y);

      if (x->mode == CLASS_COND && x->r == STACK_ONLY && 
          (y->type->form == FORM_CHAR || y->type->form == FORM_INTEGER ||
           y->type->form == FORM_POINTER || y->type->form == FORM_ARRAY) ) {
         /* implicit down cast to bool for 'if' and 'while' conditions */
//       if (y->mode != CLASS_STACK)  CG_Load (p->cg, y);
         x->type = y->type;
         x->mode = CLASS_STACK;
         return;
      }


      if (!Is_Type_Equal (x->type, y->type))
         Parser_Error (p, "Incompatible assignment (type)!", "");

      if (y->mode == CLASS_COND)  return;

      if (x->type->form == FORM_POINTER && y->type->form == FORM_ARRAY && y->lev > 0) {
         CG_Put (p->cg, INSTR_PUSH_FP, 0, 0);
         CG_Put (p->cg, INSTR_ADD_I, 0, 0);
      }

      if (x->r == STACK_ONLY)  return;

      if (x->mode == CLASS_IND) {
         if (x->r == STACK_DUP) {
            CG_Put (p->cg, INSTR_SWAP, 0, 0);
            CG_Put (p->cg, INSTR_PUSH_SP, 0, 0);
            CG_Put (p->cg, INSTR_PUSH_B, SIZE_OF_PTR, 1);
            CG_Put (p->cg, INSTR_SUB_I, 0, 0);
            CG_Put (p->cg, INSTR_LD_I_SP, 0, SIZE_OF_PTR);
//          CG_Put (p->cg, INSTR_SWAP, 0, 0);
         }
         CG_Put (p->cg, INSTR_ST_B_SP, 0, x->type->size);
      } else
      if (x->mode == CLASS_VAR || x->mode == CLASS_PARAM) {
         if (!x->lev) {
            CG_Put (p->cg, INSTR_ST_B, x->a, x->type->size);
            if (x->r == STACK_DUP)
               CG_Put (p->cg, INSTR_LD_B, x->a, x->type->size);
         } else {
            CG_Put (p->cg, INSTR_ST_B_FP, x->a, x->type->size);
            if (x->r == STACK_DUP)
               CG_Put (p->cg, INSTR_LD_B_FP, x->a, x->type->size);
         }
      } else
      if (x->mode == CLASS_STACK) {
         if (x->r == STACK_DUP) {
//          CG_Put (p->cg, INSTR_DUP, 0, 0);
            CG_Put (p->cg, INSTR_SWAP, 0, 0);
            CG_Put (p->cg, INSTR_PUSH_SP, 0, 0);
            CG_Put (p->cg, INSTR_PUSH_B, SIZE_OF_PTR, 1);
            CG_Put (p->cg, INSTR_SUB_I, 0, 0);
            CG_Put (p->cg, INSTR_LD_I_SP, 0, SIZE_OF_PTR);
//          CG_Put (p->cg, INSTR_SWAP, 0, 0);
         }
         CG_Put (p->cg, INSTR_ST_B_SP, 0, x->type->size);
      } else Parser_Error (p, "Illegal assignment!", "");
   } else Parser_Error (p, "Incompatible assignment (form)!", "");
}


/**
 * \brief store a variable x = y;
 * \param p a pointer to the parser
 * \param op the operation to be performed
 * \param x the item where y should be stored
 * \param y the item of the calculated value
 *****************************************************************************/

void
Relation (struct _parser* p, int op, struct _item* x, struct _item* y) {
   form_t fx;
   form_t fy;

   fx = x->type->form;
   fy = y->type->form;
   if ((fx == FORM_BOOLEAN || fx == FORM_CHAR || fx == FORM_INTEGER || fx == FORM_POINTER) &&
       (fy == FORM_BOOLEAN || fy == FORM_CHAR || fy == FORM_INTEGER || fy == FORM_POINTER)) {
      if (x->mode == CLASS_CONST && y->mode == CLASS_CONST) {
         if (op == SYM_LEFT_ANGLE_BRACK)  { if (x->a <   y->a) x->a=1; else x->a=0; } else
         if (op == SYM_CMP_LE)            { if (x->a <=  y->a) x->a=1; else x->a=0; } else
         if (op == SYM_CMP_EQ)            { if (x->a ==  y->a) x->a=1; else x->a=0; } else
         if (op == SYM_CMP_NEQ)           { if (x->a !=  y->a) x->a=1; else x->a=0; } else
         if (op == SYM_CMP_GE)            { if (x->a >=  y->a) x->a=1; else x->a=0; } else
         if (op == SYM_RIGHT_ANGLE_BRACK) { if (x->a >   y->a) x->a=1; else x->a=0; }
         x->type = p->st->boolType;
         return;
      } else {
//       CG_Put_Operator (p->cg, op, x, y);
         CG_Put_Operator (p->cg, SYM_CMP_EQ, x, y);
         x->c = op;
      }
   } else Parser_Error (p, "Bad type in logical operation.", "");

   x->mode = CLASS_COND;
   x->type = p->st->boolType;
   x->a = 0;
   x->b = 0;
}


/**
 * \brief get an unary operator
 * \param p a pointer to the parser
 * \return if present the unary operator, otherwise SYM_OTHER
 *****************************************************************************/

int
Get_Unary_Operator (struct _parser* p) {
   int o;

   o = SYM_OTHER;
   if (p->t->sym == SYM_PLUS ||
       p->t->sym == SYM_MINUS ||
       p->t->sym == SYM_EXCLAMATION_MARK ||
       p->t->sym == SYM_AMPERSAND ||
       p->t->sym == SYM_ASTERISK ||
       p->t->sym == SYM_TILDE)
   {
      o = p->t->sym;
      GetSymCC (p);
   }

   return o;
}


/**
 * \brief generate code for unary operators: x = op x;
 * \param p a pointer to the parser
 * \param op the operator
 * \param x the item
 *****************************************************************************/

void
Unary_Operator (struct _parser* p, int op, struct _item* x) {
   int t;

   if (op == SYM_PLUS) {
      if (x->type->form != FORM_INTEGER)
         Parser_Error (p, "Wrong type for unary operator '+'.", "");
   } else

   if (op == SYM_MINUS) {
      if (x->type->form != FORM_INTEGER)
         Parser_Error (p, "Wrong type for unary operator '-'.", "");
      else 
         if (x->mode == CLASS_CONST)  x->a = - x->a;
         else {
            if (x->mode == CLASS_VAR || x->mode == CLASS_PARAM)  CG_Load (p->cg, x);
            CG_Put (p->cg, INSTR_NEG_I, 0, 0);
         }
   } else

   if (op == SYM_EXCLAMATION_MARK) {
      if (x->mode != CLASS_COND)  Load_Boolean (p, x);
      x->c = CG_Negated_Operator (x->c);  t = x->a;  x->a = x->b;  x->b = t;
   } else

   if (op == SYM_TILDE) {
      if (x->type->form != FORM_INTEGER)
         Parser_Error (p, "Wrong type for unary operator '~'.", "");
      else 
         if (x->mode == CLASS_CONST)  x->a = ~ x->a;
         else {
            if (x->mode == CLASS_VAR || x->mode == CLASS_PARAM)  CG_Load (p->cg, x);
            CG_Put (p->cg, INSTR_LDC_I_M1, 0, 0);
            CG_Put (p->cg, INSTR_XOR_I, 0, 0);
         }
   } else

   if (op == SYM_AMPERSAND) {
      if (x->mode == CLASS_IND || x->mode == CLASS_VAR || x->mode == CLASS_PARAM) {
         x->type = Type_Create (FORM_POINTER, 0, SIZE_OF_PTR, (struct _object*)0, x->type);
         if (x->a)  CG_Put (p->cg, INSTR_PUSH_I, x->a, 0);
         if (x->lev > 0) {
            CG_Put (p->cg, INSTR_PUSH_FP, 0, 0);
            CG_Put (p->cg, INSTR_ADD_I, 0, 0);
         }
         x->mode = CLASS_STACK;
         x->r = REG_STACK;
      } else Parser_Error (p, "Wrong type for unary operator '&'.", "");
   } else

   if (op == SYM_ASTERISK) {
      if (x->type->form == FORM_POINTER)
      {
         CG_Load (p->cg, x);
//       CG_Put (p->cg, INSTR_LD_B_SP, 0, x->type->size);
         x->type = x->type->base;
         x->mode = CLASS_IND;
      } else Parser_Error (p, "Can only dereference pointer types with operator '*'", "");
   } else

   if (op == SYM_LOGICAL_AND) {
      if (x->mode != CLASS_COND)  Load_Boolean (p, x);
      CG_Put_Cond_Operator (p->cg, CG_Negated_Operator(x->c), x->a, 0);
      x->a = p->cg->pc - 2;
      CG_Fix_Link (p->cg, x->b);
      x->b = 0;
   } else

   if (op == SYM_LOGICAL_OR) {
      if (x->mode != CLASS_COND)  Load_Boolean (p, x);
      CG_Put_Cond_Operator (p->cg, x->c, x->b, 0);
      x->b = p->cg->pc - 2;
      CG_Fix_Link (p->cg, x->a);
      x->a = 0;
   }
}


/**
 * \brief generate code for dual operators: x = y op z;
 * \param p a pointer to the parser
 * \param op the operator
 * \param x the first item
 * \param y the second item
 *****************************************************************************/

void
Dual_Operator (struct _parser* p, int op, struct _item* x, struct _item* y) {
   form_t fx;
   form_t fy;

   fx = x->type->form;
   fy = y->type->form;

   if (op != SYM_LOGICAL_AND && op != SYM_LOGICAL_OR) {

      if ((fx == FORM_CHAR || fx == FORM_INTEGER || fx == FORM_POINTER) &&
          (fy == FORM_CHAR || fy == FORM_INTEGER || fy == FORM_POINTER)) {
         if (x->mode == CLASS_CONST && y->mode == CLASS_CONST) {
            if (op == SYM_PLUS)         x->a = x->a +  y->a;  else
            if (op == SYM_MINUS)        x->a = x->a -  y->a;  else
            if (op == SYM_ASTERISK)     x->a = x->a *  y->a;  else
            if (op == SYM_DIVIDE)       x->a = x->a /  y->a;  else
            if (op == SYM_REMINDER)     x->a = x->a %  y->a;  else
            if (op == SYM_AMPERSAND)    x->a = x->a &  y->a;  else
            if (op == SYM_BAR)          x->a = x->a |  y->a;  else
            if (op == SYM_LEFT_SHIFT)   x->a = x->a << y->a;  else
            if (op == SYM_RIGHT_SHIFT)  x->a = x->a >> y->a;
         } else {
            CG_Put_Operator (p->cg, op, x, y);
            x->c = op;
         }
      } else Parser_Error (p, "Bad type for dual operator: ", SymToStringCC (op));

   } else {

      if ((fx == FORM_BOOLEAN || fx == FORM_CHAR || fx == FORM_INTEGER || fx == FORM_POINTER) &&
          (fy == FORM_BOOLEAN || fy == FORM_CHAR || fy == FORM_INTEGER || fy == FORM_POINTER)) {
         if (x->mode == CLASS_CONST && y->mode == CLASS_CONST) {
            if (op == SYM_LOGICAL_AND)  x->a = x->a && y->a;  else
            if (op == SYM_LOGICAL_OR)   x->a = x->a || y->a;
         } else {
            if (y->mode != CLASS_COND)  Load_Boolean (p, y);
            if (op == SYM_LOGICAL_OR) {
               x->a = y->a;  x->b = CG_Merged (p->cg, y->b, x->b);  x->c = y->c;
            } else
            if (op == SYM_LOGICAL_AND) {
               x->a = CG_Merged (p->cg, y->a, x->a);  x->b = y->b;  x->c = y->c;
            }
         }
      } else Parser_Error (p, "Bad type for dual operator: ", SymToStringCC (op));
   }
}


/**
 * \brief handle a conditional jump
 * \param p a pointer to the parser
 * \param x jump target
 *****************************************************************************/

void
Conditional_Jump (struct _parser* p, struct _item* x) {
   if (x->type->form == FORM_BOOLEAN || x->type->form == FORM_CHAR ||
       x->type->form == FORM_INTEGER || x->type->form == FORM_POINTER)
   {
      if (x->mode != CLASS_COND)  Load_Boolean (p, x);
      CG_Put_Cond_Operator (p->cg, CG_Negated_Operator (x->c), x->a, 0);
      CG_Fix_Link (p->cg, x->b);
      x->a = p->cg->pc - 2;
   } else {
      Parser_Error (p, "Need a boolean expression for a conditional statement.", "");
      x->a = p->cg->pc;
   }
}

