/**
 * \file cc_symtab.c
 * \brief CKPM C compiler symbol table implementation
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/


#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "cpp_io.h"
#include "cpp_conv.h"
#include "cc_symtab.h"

/**
 * \brief write a string of blanks according to the indentation level
 * \param fd the filedesciptor index of the output file
 * \param lev level of indentation
 *****************************************************************************/

void
Indend (int fd, int lev) {
   while (lev) {
      put_string (fd, "  ");
      lev = lev - 1;
   }
}


/**
 * \brief create an Object description
 * \param name the name of the object
 * \param cls the object type class
 * \param lev declaration level
 * \param type the object's type
 * \param val constants: value
 * \param next the next object entry
 * \param dsc 
 * \return a pointer to a newly created and initialized Object description
 *****************************************************************************/

struct _object*
Object_Create (char* name, class_t cls, int lev, struct _type* type,
   int val, struct _object* next, struct _object* dsc)
{
   struct _object* o;
   o = (struct _object*) malloc (sizeof (struct _object));
   o->name = (char*)0;
   if (name) o->name = strdup (name); else o->name = strdup ("(no name)");
   o->cls = cls;
   o->lev = lev;
   o->type = type;
   o->val = val;
   o->next = next;
   o->dsc = dsc;
   return o;
}


/**
 * \brief destroy an Object description
 * \param o a ointer to an Object description
 *****************************************************************************/

void
Object_Destroy (struct _object* o) {
#ifdef DEBUG
   char buf[20];
   put_three_string_nl (STDERR_FILENO, "Object_Destroy():  0x",
                        int_to_str(buf,20,16,(int)(o->next)),"");
#endif
   if (!o) return;
   if (o->name)  free ((void*)o->name);
// if (o->next)  Object_Destroy (o->next);
// if (o->dsc)   Object_Destroy (o->dsc);
   free ((void*)o);
   return;
}


/**
 * \brief dump an Object description
 * \param o a pointer to an Object description
 * \param lev level of indentation
 * \param fd the filedesciptor index of the output file
 * \param en the pointer to the end of the list, i.e. guard object
 *****************************************************************************/

void
Object_Dump (struct _object* o, int lev, int fd, struct _object* en) {
   char buf[20];
   if (!o || lev > 4) return;
   put_string (fd, "\n");
   Indend (fd, lev);
   put_three_string_nl (fd, "Object description: 0x", int_to_str(buf,20,16,(int)(o)), "");
   Indend (fd, lev);
   put_three_string_nl (fd, "name:  '",  o->name,  "'");
   Indend (fd, lev);
   put_three_string_nl (fd, "cls:   ",  ClassToString (o->cls), "");
   Indend (fd, lev);
   put_three_string_nl (fd, "lev:   '",  int_to_str (buf,20,10,o->lev),         "'");
   Indend (fd, lev);
   put_three_string_nl (fd, "type:  0x", int_to_str (buf,20,16,(int)(o->type)),  "");
   Indend (fd, lev);
   put_three_string_nl (fd, "val:   '",  int_to_str (buf,20,10,o->val),         "'");
   Indend (fd, lev);
   put_three_string_nl (fd, "next:  0x", int_to_str (buf,20,16,(int)(o->next)),  "");
   Indend (fd, lev);
   put_three_string_nl (fd, "dsc:   0x", int_to_str (buf,20,16,(int)(o->dsc)),   "");

   if (o->type) Type_Dump (o->type, lev+1, fd, en);
   if (o->dsc) Object_Dump (o->dsc, lev+1, fd, en);
   if (o->next != en) Object_Dump (o->next, lev, fd, en);
}


/*
 * \brief create a Type description
 * \param f the form of the type description
 * \param l the length
 * \param s the size of this type
 * \param fs a pointer to the fields
 * \param b the base type of this description
 * \return a pointer to a newly created and initialized Type description
 *****************************************************************************/

struct _type* Type_Create (form_t f, int l, int s, struct _object* fs, struct _type* b) {
   struct _type* t;
   t = (struct _type*) malloc (sizeof (struct _type));
   t->form = f;
   t->len = l;
   t->size = s;
   t->fields = fs;
   t->base = b;
   return t;
}


/**
 * \brief destroy a Type description
 * \param t a pointer to a Type desription
 *****************************************************************************/

void Type_Destroy (struct _type* t) {
   if (!t) return;
   if (t->fields)  Object_Destroy (t->fields);
   free ((void*)t);
}


/**
 * \brief dump a Type description
 * \param t a pointer to an Type description
 * \param lev level of indentation
 * \param fd the filedesciptor index of the output file
 * \param en the pointer to the end of the list, i.e. guard object
 *****************************************************************************/

void
Type_Dump (struct _type* t, int lev, int fd, struct _object* en) {
   char buf[20];
   put_string (fd, "\n");
   Indend (fd, lev);
   put_three_string_nl (fd, "Type description: 0x", int_to_str(buf,20,16,(int)(t)), "");
   Indend (fd, lev);
   put_three_string_nl (fd, "form:   ",   FormToString (t->form),                  "");
   Indend (fd, lev);
   put_three_string_nl (fd, "len:    ",   int_to_str (buf,20,10,t->len),           "");
   Indend (fd, lev);
   put_three_string_nl (fd, "size:   ",   int_to_str (buf,20,10,t->size),          "");
   Indend (fd, lev);
   put_three_string_nl (fd, "fields: 0x", int_to_str (buf,20,16,(int)(t->fields)), "");
   Indend (fd, lev);
   put_three_string_nl (fd, "base:   0x", int_to_str (buf,20,16,(int)(t->base)),   "");

   if (t->fields)  Object_Dump (t->fields, lev, fd, en); 
// if (t->base)    Type_Dump (t->base, fd, en);   // don't -> endless loop!
   if (t->form == FORM_POINTER && t->base)
      Type_Dump (t->base, lev+1, fd, en);
}


/**
 * \brief create an Item description
 * \return a pointer to a newly created and initialized Item description
 *****************************************************************************/

struct _item* Item_Create () {
   struct _item* i;
   i = (struct _item*) malloc (sizeof (struct _item));
   i->mode = 0;
   i->lev = 0;
   i->type = (struct _type*)0;
   i->a = 0;
   i->b = 0;
   i->c = 0;
   i->r = 0;
   return i;
}


/**
 * \brief destroy an Item description
 * \param i a pointer to a Item desription
 *****************************************************************************/

void Item_Destroy (struct _item* i) {
   if (!i) return;
   free ((void*)i);
}


/**
 * \brief copy an Item description
 * \param d a pointer to the destination Item
 * \param s a pointer to the source Item
 *****************************************************************************/

void
Item_Copy (struct _item* d, struct _item* s) {
   d->mode = s->mode ;
   d->lev = s->lev ;
   d->type = s->type ;
   d->a = s->a ;
   d->b = s->b ;
   d->c = s->c ;
   d->r = s->r ;
}


/**
 * \brief dump an Item description
 * \param i a pointer to an Item description
 * \param fd the filedesciptor index of the output file
 *****************************************************************************/

void
Item_Dump (struct _item* i, int fd) {
   char buf[20];
   put_three_string_nl (fd, "\nItem description: 0x", int_to_str(buf,20,16,(int)(i)), "");
   put_three_string_nl (fd, "mode:   '",  int_to_str (buf,20,10,i->mode), "");
   put_three_string_nl (fd, "lev:    '",  int_to_str (buf,20,10,i->lev),  "");
   put_three_string_nl (fd, "type:   0x", int_to_str (buf,20,16, (int)(i->type)), "");
   put_three_string_nl (fd, "a:      '",  int_to_str (buf,20,10,i->a),    "");
   put_three_string_nl (fd, "r:      '",  int_to_str (buf,20,10,i->r),    "");
}


/**
 * \brief enter an entry to the symbol table
 * \param st the pointer to the symbol table
 * \param cls the object type class
 * \param n the value of the object
 * \param name the name of the object
 * \param type the object's basic type
 * \param dsc a pointer to a detailed desctiption
 * \return a pointer to a newly created and initialized Object description
 *****************************************************************************/

void
SymTab_Enter (struct _symtab* st, class_t cls, int n, char* name,
              struct _type* type, struct _object* dsc)
{
   struct _object* obj;
   obj = Object_Create (name, cls, 0, type, n, st->topScope->next, dsc);
   st->topScope->next = obj;
}


/**
 * \brief create a symbol table
 * \return a pointer to a newly created and initialized symbol table
 *****************************************************************************/

struct _symtab* SymTab_Create () {
   struct _symtab* st;
   struct _object* obj;
   
   st = (struct _symtab*) malloc (sizeof (struct _symtab));

   /* predefined types */
   st->boolType       = Type_Create (FORM_BOOLEAN, 0, 4, (struct _object*)0, (struct _type*)0);
   st->intType        = Type_Create (FORM_INTEGER, 0, 4, (struct _object*)0, (struct _type*)0);
   st->charType       = Type_Create (FORM_CHAR,    0, 1, (struct _object*)0, (struct _type*)0);
   st->charPtrType    = Type_Create (FORM_POINTER, 0, 4, (struct _object*)0, st->charType);
   st->charPtrPtrType = Type_Create (FORM_POINTER, 0, 4, (struct _object*)0, st->charPtrType);
   st->voidType       = Type_Create (FORM_VOID,    0, 0, (struct _object*)0, (struct _type*)0);
   st->voidPtrType    = Type_Create (FORM_POINTER, 0, 4, (struct _object*)0, st->voidType);

   st->guard = Object_Create ("", CLASS_VAR, 0, st->intType, 0,
                              (struct _object*)0, (struct _object*)0);

   /* open first scope and insert predefined types to the symbol table */
   st->topScope = (struct _object*)0;
   OpenScope (st);

   SymTab_Enter (st, CLASS_TYPE,  1, "bool",   st->boolType,    (struct _object*)0);
   SymTab_Enter (st, CLASS_TYPE,  2, "int",    st->intType,     (struct _object*)0);
   SymTab_Enter (st, CLASS_TYPE,  3, "char",   st->charType,    (struct _object*)0);
   SymTab_Enter (st, CLASS_TYPE,  4, "void",   st->voidType,    (struct _object*)0);

   SymTab_Enter (st, CLASS_CONST, 0, "false",  st->boolType,    (struct _object*)0);
   SymTab_Enter (st, CLASS_CONST, 1, "true",   st->boolType,    (struct _object*)0);

   obj = Object_Create ("size",     CLASS_PARAM, 1, st->intType,        0, st->guard, (struct _object*)0);
   SymTab_Enter (st, CLASS_SFUNC, 1, "malloc", st->voidPtrType, obj);

   obj = Object_Create ("ptr",      CLASS_PARAM, 1, st->voidPtrType,    0, st->guard, (struct _object*)0);
   SymTab_Enter (st, CLASS_SFUNC, 2, "free",   st->voidType,    obj);

   obj = Object_Create ("mode",     CLASS_PARAM, 1, st->intType,        0, st->guard, (struct _object*)0);
   obj = Object_Create ("flags",    CLASS_PARAM, 1, st->intType,        0, obj,       (struct _object*)0);
   obj = Object_Create ("pathname", CLASS_PARAM, 1, st->charPtrType,    0, obj,       (struct _object*)0);
   SymTab_Enter (st, CLASS_SFUNC, 3, "open",   st->intType,     obj);

   obj = Object_Create ("fd",       CLASS_PARAM, 1, st->intType,        0, st->guard, (struct _object*)0);
   SymTab_Enter (st, CLASS_SFUNC, 4, "close",  st->intType,     obj);
   
   obj = Object_Create ("count",    CLASS_PARAM, 1, st->intType,        0, st->guard, (struct _object*)0);
   obj = Object_Create ("buf",      CLASS_PARAM, 1, st->voidPtrType,    0, obj,       (struct _object*)0);
   obj = Object_Create ("fd",       CLASS_PARAM, 1, st->intType,        0, obj,       (struct _object*)0);
   SymTab_Enter (st, CLASS_SFUNC, 5, "read",   st->intType,     obj);

   obj = Object_Create ("count",    CLASS_PARAM, 1, st->intType,        0, st->guard, (struct _object*)0);
   obj = Object_Create ("buf",      CLASS_PARAM, 1, st->voidPtrType,    0, obj,       (struct _object*)0);
   obj = Object_Create ("fd",       CLASS_PARAM, 1, st->intType,        0, obj,       (struct _object*)0);
   SymTab_Enter (st, CLASS_SFUNC, 6, "write",  st->intType,     obj);

   obj = Object_Create ("argv",     CLASS_PARAM, 1, st->charPtrPtrType, 0, st->guard, (struct _object*)0);
   obj = Object_Create ("argc",     CLASS_PARAM, 1, st->intType,        0, obj,       (struct _object*)0);
   SymTab_Enter (st, CLASS_FUNC_PR, 7, "main",   st->intType,     obj);
#if 0
   obj = Object_Create ("char",     CLASS_PARAM, 1, st->intType,     0, st->guard, (struct _object*)0);
   obj = Object_Create ("fd",       CLASS_PARAM, 1, st->intType,     0, obj,       (struct _object*)0);
   SymTab_Enter (st, CLASS_SFUNC, 5, "vmputc", st->intType,     obj);

   obj = Object_Create ("fd",       CLASS_PARAM, 1, st->intType,     0, st->guard, (struct _object*)0);
   SymTab_Enter (st, CLASS_SFUNC, 6, "vmgetc", st->intType,     obj);
#endif

   st->universe = st->topScope;
   return st;
}


/**
 * \brief destroy a symbol table
 * \param st pointer to a symbol table
 *****************************************************************************/

void
SymTab_Destroy (struct _symtab* st) {
#ifdef DEBUG
   put_string (STDERR_FILENO, "SymTab_Destroy(): not implemented!\n");
#endif
}


/**
 * \brief open a new scope
 * \param st pointer to a symbol table
 *****************************************************************************/

void OpenScope (struct _symtab* st) {
   struct _object* s;
   s = Object_Create ("", CLASS_HEAD, 0, (struct _type*)0, 0, st->guard, st->topScope);
   st->topScope = s;
}


/**
 * \brief close a the topmost scope
 * \param st pointer to a symbol table
 *****************************************************************************/

void CloseScope (struct _symtab* st) {
   st->topScope = st->topScope->dsc;
}


/**
 * \brief dump the content of a symbol table
 * \param st pointer to a symbol table
 * \param lev level of indentation
 * \param fd the filedesciptor index of the output file
 *****************************************************************************/

void
SymTab_Dump (struct _symtab* st, int lev, int fd) {
   char buf[20];
   int n;
   struct _object* obj;

   n = 0;
   Indend (fd, lev);
   put_string (fd, "SymTab_Dump():\n");
   Indend (fd, lev);
   put_three_string_nl (fd, "guard:   0x", int_to_str(buf,20,16,(int)(st->guard)), "");
 
   obj = st->topScope;

   while (obj) {
      n = n + 1;
      put_string (fd, "\n\n");
      Indend (fd, lev);
      put_string (fd, "Scope: ");
      put_int    (fd, n);
      put_string (fd, "\n");
      Object_Dump (obj, lev+1, fd, st->guard);
      obj = obj->dsc;
   }
}


/**
 * \brief convert class numbers to strings
 * \param cls the class number
 * \return the class name as a string
 *****************************************************************************/

char*
ClassToString (class_t cls) {
  if (cls == CLASS_HEAD)     return  "head";
  if (cls == CLASS_VAR)      return  "variable";
  if (cls == CLASS_PARAM)    return  "parameter";
  if (cls == CLASS_CONST)    return  "constant";
  if (cls == CLASS_FIELD)    return  "field";
  if (cls == CLASS_TYPE)     return  "type";
  if (cls == CLASS_FUNC)     return  "function";
  if (cls == CLASS_SFUNC)    return  "predefined function";
  if (cls == CLASS_FUNC_PR)  return  "function prototype";
  if (cls == CLASS_IND)      return  "indirect";
  if (cls == CLASS_STACK)    return  "stack";
  if (cls == CLASS_COND)     return  "conditional";
  return "unknown";
}


/**
 * \brief convert form numbers to strings
 * \param f the form number
 * \return the form name as a string
 *****************************************************************************/

char*
FormToString (form_t f) {
   if (f == FORM_UNKNOWN)   return "unknown (0)";
   if (f == FORM_VOID)      return "void";
   if (f == FORM_BOOLEAN)   return "boolean";
   if (f == FORM_CHAR)      return "character";
   if (f == FORM_INTEGER)   return "integer";
   if (f == FORM_ARRAY)     return "array";
   if (f == FORM_STRUCTURE) return "structure";
   if (f == FORM_POINTER)   return "pointer";
   return "unknown";
}


/**
 * \brief convert type numbers to strings
 * \param t the type number
 * \return the type name as a string
 *****************************************************************************/

char*
TypeToString (type_t t) {
   if (t == TYPE_UNKNOWN)   return "unknown (0)";
   if (t == TYPE_INT)       return "int";
   if (t == TYPE_CHAR)      return "char";
   if (t == TYPE_VOID)      return "void";
   return "unknown";
}

