/**
 * \file cc_code_gen.h
 * \brief CKPM C compiler code generator
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef	_CKPM_CC_CODE_GEN_H_
#define	_CKPM_CC_CODE_GEN_H_

#include "vm_instr.h"
#include "cc_symtab.h"
#include "ld_object.h"

#define	SIZE_OF_PTR		4
#define	SIZE_OF_CHAR		1
#define	SIZE_OF_INT		4

#define	FRAME_ADMIN_SIZE	8	/*!< space for old fp and return address */

#define	MAX_CODE		100000	/*!< maximum code size of one object file */
#define	MAX_DATA		10000	/*!< maximum size of the clobal data area */


/**
 * \struct _codegen
 * \brief code generator administrative variables
 *****************************************************************************/

struct _codegen {
   int fd;				/*!< file descriptor index for error messages */
   int curlev;				/*!< current nesting level */
   int pc;				/*!< actual program counter in code */
   char code[MAX_CODE];			/*!< generated code */
   int didx;				/*!< last index in data area */
   char gd[MAX_DATA];			/*!< global data area */
   struct _ld_sym* code_sym;		/*!< a linked list of symbols for imports and exports */
};

/*
 * forward declarations
 */
struct _codegen* CodeGen_Create (int fd);
void CodeGen_Destroy (struct _codegen* cg);
void CodeGen_Dump (struct _codegen* cg, int fd);
void Increment_Level (struct _codegen* cg);
void Decrement_Level (struct _codegen* cg);
// int CG_Instr_Parms (int i);
// void CG_Param (struct _codegen* cg, int p, int sz);

int CG_Put_Global_Data (struct _codegen* cg, char* dat, int len, int align);
void CG_Link_Global_Data (struct _codegen* cg, char* name, int l1);

// void CG_Put_Relocate (struct _codegen* cg, int i, int par, st_bind_t b, st_type_t t);
void CG_Put (struct _codegen* cg, int i, int p, int sz);
void CG_Put_Branch (struct _codegen* cg, int i, int p);
void CG_Put_Cond_Operator (struct _codegen* cg, int i, int p, int sz);
void CG_Load (struct _codegen* cg, struct _item* x);
int CG_Read_Short (struct _codegen* cg, int at);
int CG_Read_Long (struct _codegen* cg, int at);
void CG_Fix (struct _codegen* cg, int at, int with);
void CG_Fix_Long (struct _codegen* cg, int at, int with);
int CG_Merged (struct _codegen* cg, int l0, int l1);
void CG_Fix_With (struct _codegen* cg, int l0, int l1);
void CG_Fix_Link (struct _codegen* cg, int l);
void CG_Fix_Link_Long (struct _codegen* cg, int l);
void CG_Put_Operator (struct _codegen* cg, int op, struct _item* x, struct _item* y);
int CG_Negated_Operator (int op);
void CG_Call (struct _codegen* cg, struct _item* x, char* name);
void CG_Call_Predefined (struct _codegen* cg, struct _item* x, char* name);
int CG_Forward_Jump (struct _codegen* cg, int l);
void CG_Backward_Jump (struct _codegen* cg, int l);
int CG_Function_Prolog (struct _codegen* cg, int par);
void CG_Function_Epilog (struct _codegen* cg, int par, int loc, int f);
void CG_New_ExpImp (struct _codegen* cg, char* name, st_bind_t b, st_type_t t);
void CG_Link_ExpImp (struct _codegen* cg, char* name);


#endif /* _CKPM_CC_CODE_GEN_H_ */

