/**
 * \file cc_code_gen.c
 * \brief CKPM C compiler code generator
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/


#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include "cpp_io.h"

#include "cc_scan.h"
#include "cc_symtab.h"	
#include "cc_code_gen.h"

#ifdef DEBUG
#include <stdio.h>
#include "vm_asm.h"
#endif

/**
 * \brief create a code generator structure
 * \param fd a filedescriptor index for error messages
 * \return a pointer to the newly created code generator
 *****************************************************************************/

struct _codegen*
CodeGen_Create (int fd) {
   struct _codegen* cg;
   cg = (struct _codegen*) malloc (sizeof (struct _codegen));
   cg->fd = fd;
   cg->curlev = 0;
   cg->pc = 0;
   cg->didx = 0;
   cg->code_sym = (struct _ld_sym*)0;
   return cg;
}


/**
 * \brief destroy a code generator structure
 * \param cg a pointer to the code generator
 *****************************************************************************/

void
CodeGen_Destroy (struct _codegen* cg) {
   free ((void*)cg);
}


#ifdef DEBUG
/**
 * \brief this subroutine writes a disassembled instruction to fd
 * \param fd a file descriptor index to an open file
 * \param e the pointer to the current instruction description
 * \param arg the argument value of the instruction
 * \param pc the actual program counter
 *****************************************************************************/

inline void
dump_instruction (int fd, struct instr_set_entry* e, int arg, int pc)
{
   char buf[50];
   snprintf (buf, 50, "0x%08X:   ", pc);
   put_string (fd, buf);
   snprintf (buf, 50, e->asm_code, arg);
   put_string (fd, buf);
   put_string (fd, "\n");
}

void
dump_data (int fd, char* s, int len) {
   int k, x;
   char buf[50];

   k = 0;
   while (k < len) {
      snprintf (buf, 50, "0x%08x:   ", k);  put_string (fd, buf);
      x = 0;
      while (x < 16) {
         if (k+x < len) {
            snprintf (buf, 50, "%02x ", s[k+x] & 0xFF);
            put_string (fd, buf);
         } else
            put_string (fd, "   ");
         x = x + 1;
         if (x == 8)  put_string (fd, "  ");
      }
      put_string (fd, "  ");
      x = 0;
      while (x < 16) {
         buf[0] = ' '; buf[1] = '\0';
         if (k+x < len) { if (s[k+x] < 32)  buf[0] = '.';  else  buf[0] = s[k+x]; }
         put_string (fd, buf);
         x = x + 1;
         if (x == 8)  put_string (fd, " ");
      }
      k = k + 16;
      put_string (fd, "\n");
   }
}
#endif


/**
 * \brief dump the code generator structure
 * \param cg a pointer to the code generator
 * \param fd a file descriptor index to an open file
 *****************************************************************************/

void
CodeGen_Dump (struct _codegen* cg, int fd) {
#ifdef DEBUG
   int save_pc, pc, instr;
   char a, b, c, d;
   int arg_i;
   struct instr_set_entry* e;

   put_string (fd, "\nCodeGen_Dump(): code segment, length=");
   put_int    (fd, cg->pc);
   put_string (fd, "\n");
   dump_data (fd, cg->code, cg->pc);
   put_string (fd, "\n");

   put_string (fd, "\nCodeGen_Dump(): code segment, length=");
   put_int    (fd, cg->pc);
   put_string (fd, "\n");

   pc = 0;
   while (pc < cg->pc) {
      save_pc = pc;
      instr = cg->code[pc] & 0xFF;  pc = pc + 1;
      e = &(instruction_set[instr]);
      switch (e->params) {
         case 1:
            arg_i = cg->code[pc] & 0xFF;  pc = pc + 1;
            dump_instruction (fd, e, arg_i, save_pc);
            break;
         case 2:
            a = cg->code[pc];  pc = pc + 1;
            b = cg->code[pc];  pc = pc + 1;
            arg_i = (((int)a << 8) & 0xFF00) | ((int)b & 0xFF);
            dump_instruction (fd, e, arg_i & 0xFFFF, save_pc);
            break;
         case 4:
            a = cg->code[pc];  pc = pc + 1;
            b = cg->code[pc];  pc = pc + 1;
            c = cg->code[pc];  pc = pc + 1;
            d = cg->code[pc];  pc = pc + 1;
            arg_i = (((int)a << 24) & 0xFF000000) |
                    (((int)b << 16) & 0xFF0000) |
                    (((int)c <<  8) & 0xFF00) |
                    ( (int)d  & 0xFF);
            dump_instruction (fd, e, arg_i, save_pc);
            break;
         default:
            dump_instruction (fd, e, 0, save_pc);
            break;
      }
   }

   put_string (fd, "\nCodeGen_Dump(): data segment, length=");
   put_int    (fd, cg->didx);
   put_string (fd, "\n");

   dump_data (fd, cg->gd, cg->didx);

   LdSym_Dump (cg->code_sym, fd);
   put_string (fd, "\n");
#endif
}


/**
 * \brief increment the current level by one
 * \param cg a pointer to the code generator
 *****************************************************************************/

void
Increment_Level (struct _codegen* cg) {
   cg->curlev = cg->curlev + 1;
}


/**
 * \brief decrement the current level by one
 * \param cg a pointer to the code generator
 *****************************************************************************/

void
Decrement_Level (struct _codegen* cg) {
   cg->curlev = cg->curlev - 1;
}


/**
 * \brief determine the length of the parameter of an instruction
 * \param i the given instruction
 * \return the length of the parameter
 *****************************************************************************/

int
CG_Instr_Parms (int i) {
   if (i == INSTR_PUSH_B)    return  1;
   if (i == INSTR_PUSH_S)    return  2;
   if (i == INSTR_PUSH_I)    return  4;
   if (i == INSTR_LD_B)      return  4;
   if (i == INSTR_LD_S)      return  4;
   if (i == INSTR_LD_I)      return  4;
   if (i == INSTR_LD_L)      return  4;
   if (i == INSTR_LD_F)      return  4;
   if (i == INSTR_LD_D)      return  4;
   if (i == INSTR_LD_B_FP)   return  2;
   if (i == INSTR_LD_S_FP)   return  2;
   if (i == INSTR_LD_I_FP)   return  2;
   if (i == INSTR_LD_L_FP)   return  2;
   if (i == INSTR_LD_F_FP)   return  2;
   if (i == INSTR_LD_D_FP)   return  2;
   if (i == INSTR_LD_B_IND)  return  4;
   if (i == INSTR_LD_S_IND)  return  4;
   if (i == INSTR_LD_I_IND)  return  4;
   if (i == INSTR_LD_L_IND)  return  4;
   if (i == INSTR_LD_F_IND)  return  4;
   if (i == INSTR_LD_D_IND)  return  4;
   if (i == INSTR_ST_B)      return  4;
   if (i == INSTR_ST_S)      return  4;
   if (i == INSTR_ST_I)      return  4;
   if (i == INSTR_ST_L)      return  4;
   if (i == INSTR_ST_F)      return  4;
   if (i == INSTR_ST_D)      return  4;
   if (i == INSTR_ST_B_FP)   return  2;
   if (i == INSTR_ST_S_FP)   return  2;
   if (i == INSTR_ST_I_FP)   return  2;
   if (i == INSTR_ST_L_FP)   return  2;
   if (i == INSTR_ST_F_FP)   return  2;
   if (i == INSTR_ST_D_FP)   return  2;
   if (i == INSTR_ST_B_IND)  return  4;
   if (i == INSTR_ST_S_IND)  return  4;
   if (i == INSTR_ST_I_IND)  return  4;
   if (i == INSTR_ST_L_IND)  return  4;
   if (i == INSTR_ST_F_IND)  return  4;
   if (i == INSTR_ST_D_IND)  return  4;
   if (i == INSTR_DEC_FP)    return  2;
   if (i == INSTR_INC_SP)    return  2;
   if (i == INSTR_DEC_SP)    return  2;
   if (i == INSTR_INC_I)     return  4;
   if (i == INSTR_INC_L)     return  4;
   if (i == INSTR_JMP)       return  4;
   if (i == INSTR_JSR)       return  4;
   if (i == INSTR_BEQ)       return  2;
   if (i == INSTR_BNE)       return  2;
   if (i == INSTR_BGE)       return  2;
   if (i == INSTR_BGT)       return  2;
   if (i == INSTR_BLE)       return  2;
   if (i == INSTR_BLT)       return  2;
   return 0;
}


/**
 * \brief emit a parameter of an instruction
 * \param cg a pointer to the code generator
 * \param p the parameter value
 * \param sz the size of the parameter value
 *****************************************************************************/

void
CG_Param (struct _codegen* cg, int p, int sz) {
   if (sz == 1) {
      cg->code[cg->pc] = (char)p;                    cg->pc = cg->pc + 1;
   } else
   if (sz == 2) {
      cg->code[cg->pc] = (char)((p >> 8) & 0xFF);    cg->pc = cg->pc + 1;
      cg->code[cg->pc] = (char)(p & 0xFF);           cg->pc = cg->pc + 1;
   } else
   if (sz == 4) {
      cg->code[cg->pc] = (char)((p >> 24) & 0xFF);   cg->pc = cg->pc + 1;
      cg->code[cg->pc] = (char)((p >> 16) & 0xFF);   cg->pc = cg->pc + 1;
      cg->code[cg->pc] = (char)((p >> 8) & 0xFF);    cg->pc = cg->pc + 1;
      cg->code[cg->pc] = (char)(p & 0xFF);           cg->pc = cg->pc + 1;
   }
}


/**
 * \brief emit an instruction
 * \param cg a pointer to the code generator
 * \param i the instruction code
 * \param p the parameter value
 * \param sz the size of the parameter value (optional)
 *****************************************************************************/

void
CG_Put (struct _codegen* cg, int i, int p, int sz) {
   if (i == INSTR_PUSH_B || i == INSTR_PUSH_S || i == INSTR_PUSH_I) {
      if (sz < 2 && p >= -127 && p <= 128) {
         cg->code[cg->pc] = (char)INSTR_PUSH_B;   cg->pc = cg->pc + 1;
         CG_Param (cg, p, 1);
      } else
      if (sz < 4 && p >= -32767 && p <= 32768) {
         cg->code[cg->pc] = (char)INSTR_PUSH_S;   cg->pc = cg->pc + 1;
         CG_Param (cg, p, 2);
      } else {
         cg->code[cg->pc] = (char)INSTR_PUSH_I;   cg->pc = cg->pc + 1;
         CG_Param (cg, p, 4);
      }
   } else 

   if (i == INSTR_LD_B || i == INSTR_LD_S || i == INSTR_LD_I || i == INSTR_LD_L) {
      if (sz == 1)  { cg->code[cg->pc] = (char)INSTR_LD_B;  cg->pc = cg->pc + 1; }    else
      if (sz == 2)  { cg->code[cg->pc] = (char)INSTR_LD_S;  cg->pc = cg->pc + 1; }    else
      if (sz == 4)  { cg->code[cg->pc] = (char)INSTR_LD_I;  cg->pc = cg->pc + 1; }    else
      if (sz == 8)  { cg->code[cg->pc] = (char)INSTR_LD_L;  cg->pc = cg->pc + 1; }
      CG_Param (cg, p, 4);
   } else

   if (i == INSTR_LD_B_FP || i == INSTR_LD_S_FP || i == INSTR_LD_I_FP || i == INSTR_LD_L_FP) {
      if (sz == 1)  { cg->code[cg->pc] = (char)INSTR_LD_B_FP;  cg->pc = cg->pc + 1; } else
      if (sz == 2)  { cg->code[cg->pc] = (char)INSTR_LD_S_FP;  cg->pc = cg->pc + 1; } else
      if (sz == 4)  { cg->code[cg->pc] = (char)INSTR_LD_I_FP;  cg->pc = cg->pc + 1; } else
      if (sz == 8)  { cg->code[cg->pc] = (char)INSTR_LD_L_FP;  cg->pc = cg->pc + 1; }
      CG_Param (cg, p, 2);
   } else

   if (i == INSTR_LD_B_SP || i == INSTR_LD_S_SP || i == INSTR_LD_I_SP || i == INSTR_LD_L_SP) {
      if (sz == 1)  { cg->code[cg->pc] = (char)INSTR_LD_B_SP;  cg->pc = cg->pc + 1; } else
      if (sz == 2)  { cg->code[cg->pc] = (char)INSTR_LD_S_SP;  cg->pc = cg->pc + 1; } else
      if (sz == 4)  { cg->code[cg->pc] = (char)INSTR_LD_I_SP;  cg->pc = cg->pc + 1; } else
      if (sz == 8)  { cg->code[cg->pc] = (char)INSTR_LD_L_SP;  cg->pc = cg->pc + 1; }
   } else

   if (i == INSTR_ST_B || i == INSTR_ST_S || i == INSTR_ST_I || i == INSTR_ST_L) {
      if (sz == 1)  { cg->code[cg->pc] = (char)INSTR_ST_B;  cg->pc = cg->pc + 1; }    else
      if (sz == 2)  { cg->code[cg->pc] = (char)INSTR_ST_S;  cg->pc = cg->pc + 1; }    else
      if (sz == 4)  { cg->code[cg->pc] = (char)INSTR_ST_I;  cg->pc = cg->pc + 1; }    else
      if (sz == 8)  { cg->code[cg->pc] = (char)INSTR_ST_L;  cg->pc = cg->pc + 1; }
      CG_Param (cg, p, 4);
   } else

   if (i == INSTR_ST_B_FP || i == INSTR_ST_S_FP || i == INSTR_ST_I_FP || i == INSTR_ST_L_FP) {
      if (sz == 1)  { cg->code[cg->pc] = (char)INSTR_ST_B_FP;  cg->pc = cg->pc + 1; } else
      if (sz == 2)  { cg->code[cg->pc] = (char)INSTR_ST_S_FP;  cg->pc = cg->pc + 1; } else
      if (sz == 4)  { cg->code[cg->pc] = (char)INSTR_ST_I_FP;  cg->pc = cg->pc + 1; } else
      if (sz == 8)  { cg->code[cg->pc] = (char)INSTR_ST_L_FP;  cg->pc = cg->pc + 1; }
      CG_Param (cg, p, 2);
   } else

   if (i == INSTR_ST_B_SP || i == INSTR_ST_S_SP || i == INSTR_ST_I_SP || i == INSTR_ST_L_SP) {
      if (sz == 1)  { cg->code[cg->pc] = (char)INSTR_ST_B_SP;  cg->pc = cg->pc + 1; } else
      if (sz == 2)  { cg->code[cg->pc] = (char)INSTR_ST_S_SP;  cg->pc = cg->pc + 1; } else
      if (sz == 4)  { cg->code[cg->pc] = (char)INSTR_ST_I_SP;  cg->pc = cg->pc + 1; } else
      if (sz == 8)  { cg->code[cg->pc] = (char)INSTR_ST_L_SP;  cg->pc = cg->pc + 1; }
   } else

#if 0
   if (i == INSTR_NEG_I || i == INSTR_NEG_L || i == INSTR_NEG_F || i == INSTR_NEG_D) {
      /* TODO: type check */
      cg->code[cg->pc] = (char)i;  cg->pc = cg->pc + 1;
   } else
#endif

   
   {
      cg->code[cg->pc] = (char)i;
      cg->pc = cg->pc + 1;
      CG_Param (cg, p, CG_Instr_Parms (i));
   }
}


/**
 * \brief emit an instruction for conditionals
 * \param cg a pointer to the code generator
 * \param i the instruction symbol from the scanner
 * \param p the parameter value
 * \param sz the size of the parameter value (optional)
 *****************************************************************************/

void
CG_Put_Cond_Operator (struct _codegen* cg, int i, int p, int sz) {
// i = CG_Negated_Operator (i);
   if (i == SYM_LEFT_ANGLE_BRACK)    CG_Put (cg, INSTR_BLT, p, sz);  else
   if (i == SYM_CMP_LE)              CG_Put (cg, INSTR_BLE, p, sz);  else
   if (i == SYM_CMP_EQ)              CG_Put (cg, INSTR_BEQ, p, sz);  else
   if (i == SYM_CMP_NEQ)             CG_Put (cg, INSTR_BNE, p, sz);  else
   if (i == SYM_CMP_GE)              CG_Put (cg, INSTR_BGE, p, sz);  else
   if (i == SYM_RIGHT_ANGLE_BRACK)   CG_Put (cg, INSTR_BGT, p, sz);
}


/**
 * \brief transfer data into the global data area
 * \param cg a pointer to the code generator
 * \param dat a pointer to the data to be transferred
 * \param len the length of the data
 * \param align is the alignment of the data in the global data area (1,2,4,8,...)
 *****************************************************************************/

int
CG_Put_Global_Data (struct _codegen* cg, char* dat, int len, int align) {
   int a;

   if (cg->didx % align)
      cg->didx = cg->didx + align - cg->didx % align;

   a = cg->didx;

   while (len) {
      len = len - 1;
      cg->gd[cg->didx] = *dat;
      cg->didx = cg->didx + 1;
      dat = dat + 1;
   }

   return a;
}


/**
 * \brief manage links to global data area
 * \param cg a pointer to the code generator
 * \param name the name of the symbol
 * \param l the link to be fixed in the code area
 *****************************************************************************/

void
CG_Link_Global_Data (struct _codegen* cg, char* name, int l) {
   struct _ld_sym* s;
   struct _ld_sym* o;
   s = cg->code_sym;

   while (s) {
     if (s->value == l && s->type == STT_OBJECT)  break;
     o = s;
     s = s->next;
   }

   if (!s) {
      cg->code_sym = LdSym_Create (name, l, cg->pc - 4, STT_OBJECT,
                                   STB_LOCAL, cg->code_sym);
   } else {
      CG_Fix_Long (cg, cg->pc - 4, s->size);
      s->size = cg->pc - 4;
   }
}


/**
 * \brief create or update an entry in the symbol list
 * \param cg a pointer to the code generator
 * \param name the name of the symbol
 * \param b the link binding information
 * \param t the link type information
 *****************************************************************************/

void
CG_New_ExpImp (struct _codegen* cg, char* name, st_bind_t b, st_type_t t) {
   struct _ld_sym* s;
   struct _ld_sym* o;
   s = cg->code_sym;

   while (s) {
     if ( !strcmp (s->name, name) && s->type != STT_OBJECT)  break;
     o = s;
     s = s->next;
   }

   if (!s) {
      cg->code_sym = LdSym_Create (name, cg->pc, 0, t, b, cg->code_sym);
   } else {
      s->value = cg->pc;
      s->type = t;
      s->bind = b;
   }
}

 
/**
 * \brief handle the export and import list for symbols
 * \param cg a pointer to the code generator
 * \param name the name of the symbol
 *****************************************************************************/

void
CG_Link_ExpImp (struct _codegen* cg, char* name) {
   struct _ld_sym* s;
   struct _ld_sym* o;
   s = cg->code_sym;

   while (s) {
     if ( !strcmp (s->name, name) )  break;
     o = s;
     s = s->next;
   }

   if (!s) {
      cg->code_sym = LdSym_Create (name, 0, cg->pc - 4, STT_NOTYPE,
                                   STB_GLOBAL, cg->code_sym);
   } else {
      CG_Fix_Long (cg, cg->pc - 4, s->size);
      s->size = cg->pc - 4;
#if 0
#ifdef DEBUG
      fprintf (stderr, "CG_Link_ExpImp(). (cg->pc - 4) = 0x%08X,  file=0x%08X\n", cg->pc - 4, CG_Read_Long (cg, cg->pc - 4));
#endif
#endif
   }
}


/**
 * \brief emit an branch instruction
 * \param cg a pointer to the code generator
 * \param i the instruction code
 * \param p the parameter value
 *****************************************************************************/

void
CG_Put_Branch (struct _codegen* cg, int i, int p) {
   cg->code[cg->pc] = (char)i;
   cg->pc = cg->pc + 1;
   if (i == INSTR_JMP || i == INSTR_JSR)
       CG_Param (cg, p, 4);
   else
       CG_Param (cg, p, 2);
}


/**
 * \brief load a variable onto the stack
 * \param cg a pointer to the code generator
 * \param x the item to be loaded
 *****************************************************************************/

void
CG_Load (struct _codegen* cg, struct _item* x) {
   if (x->mode == CLASS_VAR || x->mode == CLASS_PARAM) {
      if (x->type->form == FORM_ARRAY) {
         CG_Put (cg, INSTR_PUSH_I, x->a, 0);
      } else {
         if (!x->lev)  CG_Put (cg, INSTR_LD_I,    x->a, x->type->size);
         else          CG_Put (cg, INSTR_LD_I_FP, x->a, x->type->size);
      }
      x->a = 0;
   } else

   if (x->mode == CLASS_IND) {
//    if (!x->lev)  CG_Put (cg, INSTR_LD_I,    x->a, SIZE_OF_PTR);
//    else          CG_Put (cg, INSTR_LD_I_FP, x->a, SIZE_OF_PTR);
      CG_Put (cg, INSTR_LD_B_SP, 0, x->type->size);
   } else

   if (x->mode == CLASS_IND_DATA) {
      CG_Put (cg, INSTR_PUSH_I, 0, SIZE_OF_PTR);
      CG_Link_Global_Data (cg, "", x->a);
   } else

   if (x->mode == CLASS_CONST) {
      CG_Put (cg, INSTR_PUSH_I, x->a, 0);
   }

   x->mode = CLASS_STACK;
   x->r = STACK_NONE;
}


/**
 * \brief read two bytes from the code at a given address
 * \param cg a pointer to the code generator
 * \param at the address in the code
 * \return the two bytes as an integer value
 *****************************************************************************/

int
CG_Read_Short (struct _codegen* cg, int at) {
// return ((int)(cg->code [at]) << 8) | (int)(cg->code [at+1]);
   return (((int)(cg->code [at]) <<  8) & 0xFF00) |
          (((int)(cg->code [at+1])    ) & 0xFF);
}


/**
 * \brief read four bytes from the code at a given address
 * \param cg a pointer to the code generator
 * \param at the address in the code
 * \return the four bytes as an integer value
 *****************************************************************************/

int
CG_Read_Long (struct _codegen* cg, int at) {
// return ((int)(cg->code [at])   << 24) | ((int)(cg->code [at+1]) << 16) |
//        ((int)(cg->code [at+2]) << 8)  |  (int)(cg->code [at+3]);
   return (((int)(cg->code [at])   << 24) & 0xFF000000) |
          (((int)(cg->code [at+1]) << 16) & 0xFF0000) |
          (((int)(cg->code [at+2]) <<  8) & 0xFF00) |
          (((int)(cg->code [at+3])      ) & 0xFF);
}


/**
 * \brief do the branch destination fixup for relative addresses
 * \param cg a pointer to the code generator
 * \param at the address in the code of the parameter of a branch statement
 * \param with the new branch destination
 *****************************************************************************/

void
CG_Fix (struct _codegen* cg, int at, int with) {
   cg->code [at]   = (char)((with >> 8) & 0xFF);
   cg->code [at+1] = (char)( with       & 0xFF);
}


/**
 * \brief do the branch destination fixup for absolute addresses
 * \param cg a pointer to the code generator
 * \param at the address in the code of the parameter of a branch statement
 * \param with the new branch destination
 *****************************************************************************/

void
CG_Fix_Long (struct _codegen* cg, int at, int with) {
   cg->code [at]   = (char)((with >> 24) & 0xFF);
   cg->code [at+1] = (char)((with >> 16) & 0xFF);
   cg->code [at+2] = (char)((with >>  8) & 0xFF);
   cg->code [at+3] = (char)( with        & 0xFF);
}


/**
 * \brief merge two blocks
 * \param cg a pointer to the code generator
 * \param l0 the link 0
 * \param l1 the link 1
 * \return the new link
 *****************************************************************************/

int
CG_Merged (struct _codegen* cg, int l0, int l1) {
   int l2;
   int l3;

   if (!l0)  return l1;

   l2 = l0;
   while (1) {
      l3 = CG_Read_Short (cg, l2);
      if (!l3) break;
      l2 = l3;
   }

   CG_Fix (cg, l2, l1);
   return l0;
}


/**
 * \brief
 * \param cg a pointer to the code generator
 * \param l0 the link 0
 * \param l1 the link 1
 *****************************************************************************/

void
CG_Fix_With (struct _codegen* cg, int l0, int l1) {
   int l2;

   while (l0) {
      l2 = CG_Read_Short (cg, l0);
      CG_Fix (cg, l0, l1-l0);
      l0 = l2;
   }
}


/**
 * \brief do the branch destination fixup
 * \param cg a pointer to the code generator
 * \param l the address in the code of the parameter of a branch statement
 *****************************************************************************/

void
CG_Fix_Link (struct _codegen* cg, int l) {
   int l1;
   while (l) {
      l1 = CG_Read_Short (cg, l);
      CG_Fix (cg, l, cg->pc - l - 2);
      l = l1;
   }
}


/**
 * \brief do the branch destination fixup
 * \param cg a pointer to the code generator
 * \param l the address in the code of the parameter of a branch statement
 *****************************************************************************/

void
CG_Fix_Link_Long (struct _codegen* cg, int l) {
   int l1;
   while (l) {
      l1 = CG_Read_Long (cg, l);
      CG_Fix_Long (cg, l, cg->pc);
      l = l1;
   }
}


/**
 * \brief emit code for a logical operator
 * \param cg a pointer to the code generator
 * \param op the operator 
 * \param x the first item
 * \param y the second item
 *****************************************************************************/

void
CG_Put_Operator (struct _codegen* cg, int op, struct _item* x, struct _item* y) {
   if (x->mode != CLASS_STACK)  CG_Load (cg, x);

   if (y->mode == CLASS_CONST)  CG_Put  (cg, INSTR_PUSH_I, y->a, 0); else
   if (y->mode != CLASS_STACK)  CG_Load (cg, y);

   /* TODO: handle the real data types: float, long, double */
   if (op == SYM_PLUS)         CG_Put (cg, INSTR_ADD_I, 0, 0); else
   if (op == SYM_MINUS)        CG_Put (cg, INSTR_SUB_I, 0, 0); else
   if (op == SYM_ASTERISK)     CG_Put (cg, INSTR_MUL_I, 0, 0); else
   if (op == SYM_DIVIDE)       CG_Put (cg, INSTR_DIV_I, 0, 0); else
   if (op == SYM_REMINDER)     CG_Put (cg, INSTR_REM_I, 0, 0); else
   if (op == SYM_AMPERSAND)    CG_Put (cg, INSTR_AND_I, 0, 0); else
   if (op == SYM_BAR)          CG_Put (cg, INSTR_OR_I,  0, 0); else
   if (op == SYM_LEFT_SHIFT)   CG_Put (cg, INSTR_SHL_I, 0, 0); else
   if (op == SYM_RIGHT_SHIFT)  CG_Put (cg, INSTR_SHR_I, 0, 0); else
   if (op == SYM_LOGICAL_OR)   CG_Put (cg, INSTR_OR_I,  0, 0); else
   if (op == SYM_LOGICAL_AND)  CG_Put (cg, INSTR_AND_I, 0, 0); else
   CG_Put (cg, INSTR_CMP_I, y->a, 0);
}


/**
 * \brief determination of the negation of an operator
 * \param op the operator
 * \return the negated operator
 *****************************************************************************/

int
CG_Negated_Operator (int op) {
   if (op == SYM_LEFT_ANGLE_BRACK)   return SYM_CMP_GE;
   if (op == SYM_CMP_GE)             return SYM_LEFT_ANGLE_BRACK;
   if (op == SYM_RIGHT_ANGLE_BRACK)  return SYM_CMP_LE;
   if (op == SYM_CMP_LE)             return SYM_RIGHT_ANGLE_BRACK;
   if (op == SYM_CMP_EQ)             return SYM_CMP_NEQ;
   if (op == SYM_CMP_NEQ)            return SYM_CMP_EQ;
   return op;
}


/**
 * \brief emit the code for a function call
 * \param cg a pointer to the code generator
 * \param x the function item
 * \param name the name of the external symbol in the export table
 *****************************************************************************/

void
CG_Call (struct _codegen* cg, struct _item* x, char* name) {
   CG_Put_Branch  (cg, INSTR_JSR, x->a);
   CG_Link_ExpImp (cg, name);
}


/**
 * \brief emit the code for a call of an predefined (builtin) function
 * \param cg a pointer to the code generator
 * \param x the function item
 * \param name the name of the external symbol in the export table
 *****************************************************************************/

void
CG_Call_Predefined (struct _codegen* cg, struct _item* x, char* name) {
   if (!strcmp (name, "malloc"))  CG_Put (cg, INSTR_NEW,    0, 0); else
   if (!strcmp (name, "free"))    CG_Put (cg, INSTR_DEL,    0, 0); else
   if (!strcmp (name, "open"))    CG_Put (cg, INSTR_FOPEN,  0, 0); else
   if (!strcmp (name, "close"))   CG_Put (cg, INSTR_FCLOSE, 0, 0); else
   if (!strcmp (name, "vmgetc"))  CG_Put (cg, INSTR_GETC,   0, 0); else
   if (!strcmp (name, "vmputc"))  CG_Put (cg, INSTR_PUTC,   0, 0); else
   if (!strcmp (name, "write"))   CG_Put (cg, INSTR_WRITE,  0, 0); else
   if (!strcmp (name, "read"))    CG_Put (cg, INSTR_READ,   0, 0);
}


/**
 * \brief handle a forward jump to an (yet) unknown address
 * \param cg a pointer to the code generator
 * \param l the label to jump to
 *****************************************************************************/

int
CG_Forward_Jump (struct _codegen* cg, int l) {
   CG_Put (cg, INSTR_LDC_I_0, 0, 0);
   CG_Put_Branch (cg, INSTR_BEQ, l);
   return cg->pc - 2;
}


/**
 * \brief handle a backward jump to an already known address
 * \param cg a pointer to the code generator
 * \param l the label to jump to
 *****************************************************************************/

void
CG_Backward_Jump (struct _codegen* cg, int l) {
   CG_Put (cg, INSTR_LDC_I_0, 0, 0);
   CG_Put_Branch (cg, INSTR_BEQ, l - cg->pc - 3);
}


/**
 * \brief emit code for the function prolog
 * \param cg a pointer to the code generator
 * \param par the size of all parameters of the function
 * \return the address to fix the length of the local variables
 *****************************************************************************/

int
CG_Function_Prolog (struct _codegen* cg, int par) {
   CG_Put (cg, INSTR_DEC_FP, par, 0);
   CG_Put (cg, INSTR_INC_SP, 0, 0);
   return cg->pc - 2;
}


/**
 * \brief emit code for the function epilog
 * \param cg a pointer to the code generator
 * \param par the number of parameters of the function
 * \param loc the size of the local variables
 * \param f the form of the return value on the stack
 *****************************************************************************/

void
CG_Function_Epilog (struct _codegen* cg, int par, int loc, int f) {
   if (f == FORM_VOID) {
      CG_Put (cg, INSTR_DEC_SP, loc, 0);
      CG_Put (cg, INSTR_RET, 0, 0);
      return;
   }

   if (f == FORM_BOOLEAN || f == FORM_CHAR || f == FORM_INTEGER || f == FORM_POINTER) {
      CG_Put (cg, INSTR_PUSH_SP, 0, 0);
      CG_Put (cg, INSTR_PUSH_B, loc, 0);
      CG_Put (cg, INSTR_SUB_I, 0, 0);
      CG_Put (cg, INSTR_SWAP, 0, 0);
      CG_Put (cg, INSTR_ST_I_SP, 0, 4);
      CG_Put (cg, INSTR_DEC_SP, loc-4, 0);
      CG_Put (cg, INSTR_RET_I, 0, 0);
      return;
   }

   /* TODO: implement other data types */
   CG_Put (cg, INSTR_DEC_SP, loc-4, 0);
   CG_Put (cg, INSTR_RET, 0, 0);
}

