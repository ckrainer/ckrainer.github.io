/**
 * \file cc_scan.c
 * \brief CKPM C compiler scanner
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/


#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include "cpp_io.h"
#include "cpp_conv.h"
#include "cpp_token.h"
#include "cc_scan.h"

/**
 * \brief check if a given character is a digit
 * \param ch the character to be checked
 * \return !=0 if the character is a digit, otherwise 0
 *****************************************************************************/

int
isDigit (char ch) {
   if (ch >= '0' && ch <= '9')  return 1;
   return 0;
}


/**
 * \brief check if a given character is a octal digit
 * \param ch the character to be checked
 * \return !=0 if the character is a digit, otherwise 0
 *****************************************************************************/

int
isOctDigit (char ch) {
   if (ch >= '0' && ch <= '7')  return 1;
   return 0;
}


/**
 * \brief check if a given character is a hex digit
 * \param ch the character to be checked
 * \return !=0 if the character is a hex digit, otherwise 0
 *****************************************************************************/

int
isHexDigit (char ch) {
   if (ch >= '0' && ch <= '9')  return 1;
   if (ch >= 'A' && ch <= 'F')  return 1;
   if (ch >= 'a' && ch <= 'f')  return 1;
   return 0;
}


/**
 * \brief check if a given character is a letter
 * \param ch the character to be checked
 * \return !=0 if the character is a letter, otherwise 0
 *****************************************************************************/

int
isLetter (char ch) {
   if (ch >= 'A' && ch <= 'Z')  return 1;
   if (ch >= 'a' && ch <= 'z')  return 1;
   if (ch == '_') return 1;
   return 0;
}


/**
 * \brief check if a given character is a white space
 * \param ch the character to be checked
 * \return !=0 if the character is a white space, otherwise 0
 *****************************************************************************/

int
isSpace (char ch) {
   if (ch == ' ' || ch == '\t')  return 1;
   return 0;
}


/**
 * \brief append a character to a null terminated string
 * \param s the string
 * \param ch the character to be appended
 *****************************************************************************/

void
appendChar (char *s, char ch) {
   if (!s) return;
   while (*s) s = s + 1;
   *s = ch;
   s = s + 1;
   *s = '\0';
}


/**
 * \brief read one byte
 * \param fd file descriptor index of the input file
 * \param c the output variable containing the byte
 * \return status on from file read
 *****************************************************************************/
int
read_byte (int fd, char* c) {
   int rc;
   rc = read (fd, (void*)c, sizeof(char));
   return rc;
}


/**
 * \brief get next symbol (internal)
 * \param fd file descriptor index of the input file
 * \param t contains a complete token
 *****************************************************************************/

void
GetSymIntCC (int fd, struct _token* t) {
   int	i;
   int	e;
   int  hl;

#if 0
#ifdef DEBUG
   char buf[100];
   put_string (STDERR_FILENO, "### GetSymIntCC(): ");
   put_int    (STDERR_FILENO, t->ch);
   put_string (STDERR_FILENO, " '");
   if (t->ch > 31) put_char   (STDERR_FILENO, t->ch);
   put_string (STDERR_FILENO, "'\n");
#endif
#endif

   while (t->stat > 0 && t->ch <= ' ') {
      if ( t->ch == '\n' ) {
         t->line = t->line + 1;
         t->stat = read_byte (fd, &t->ch);
         if ( t->ch == '#' ) {
            t->stat = read_byte (fd, &t->ch);
            GetSymIntCC (fd, t);
            e = 0;
            if ( t->sym == SYM_NUMBER || t->sym == SYM_HEX_NUMBER ||
                 t->sym == SYM_OCT_NUMBER)
            {
               hl = dec_string_to_int (t->id);
               GetSymIntCC (fd, t);
               if ( t->sym == SYM_LITERAL ) {
                  t->line = hl+1;
                  free ((void*)t->file);
                  t->file = strdup (t->id);
#if 0
                  put_string        (STDERR_FILENO, "### PP line info: ");
                  put_string        (STDERR_FILENO, int_to_str (buf, 100, 10, hl) );
                  put_two_string_nl (STDERR_FILENO, " ", t->file);
#endif
               } else e = 1;
            } else e = 1;
            if (e) {
               put_string (STDERR_FILENO, "ERROR: in file '");
               put_string (STDERR_FILENO, t->file);
               put_string (STDERR_FILENO, "' in line ");
               put_int    (STDERR_FILENO, t->line);
               put_string (STDERR_FILENO, ": malformed pre-processor line information.\n");
#ifdef DEBUG
               put_string (STDERR_FILENO, "INFO: file '");
               put_string (STDERR_FILENO, t->file);
               put_string (STDERR_FILENO, "' in line ");
               put_int    (STDERR_FILENO, t->line);
               put_string (STDERR_FILENO, ", sym=");
               put_string (STDERR_FILENO, SymToStringCC (t->sym));
               put_string (STDERR_FILENO, ", id='");
               put_string (STDERR_FILENO, t->id);
               put_string (STDERR_FILENO, "'\n");
#endif
            }
//          t->stat = read_byte (fd, &t->ch);
         }
      } else
         t->stat = read_byte (fd, &t->ch);
   }

   if ( t->stat <= 0 ) {
      t->sym = SYM_END;
      t->id[0] = '\0';
      return;
   }

   t->sym = SYM_OTHER;
   t->id[0] = t->ch;
   t->id[1] = '\0';

   if ( t->ch == '(' ) {
      t->sym = SYM_LEFT_PAREN;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '[' ) {
      t->sym = SYM_LEFT_BRACK;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '{' ) {
      t->sym = SYM_LEFT_BRACE;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '<' ) {
      t->sym = SYM_LEFT_ANGLE_BRACK;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '<' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_LEFT_SHIFT;
         t->stat = read_byte (fd, &t->ch);
         if ( t->ch == '=' ) {
            appendChar (t->id, t->ch);
            t->sym = SYM_SHL_EQ;
            t->stat = read_byte (fd, &t->ch);
         }
         return;
      }
      if ( t->ch == '=' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_CMP_LE;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == '|' ) {
      t->sym = SYM_BAR;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '=' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_OR_EQ;
         t->stat = read_byte (fd, &t->ch);
         return;
      }
      if ( t->ch == '|' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_LOGICAL_OR;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == '&' ) {
      t->sym = SYM_AMPERSAND;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '=' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_AND_EQ;
         t->stat = read_byte (fd, &t->ch);
         return;
      }
      if ( t->ch == '&' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_LOGICAL_AND;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == '^' ) {
      t->sym = SYM_XOR;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '=' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_XOR_EQ;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == '~' ) {
      t->sym = SYM_TILDE;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '=' ) {
      t->sym = SYM_EQUAL;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '=' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_CMP_EQ;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == ')' ) {
      t->sym = SYM_RIGHT_PAREN;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == ']' ) {
      t->sym = SYM_RIGHT_BRACK;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '}' ) {
      t->sym = SYM_RIGHT_BRACE;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '>' ) {
      t->sym = SYM_RIGHT_ANGLE_BRACK;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '>' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_RIGHT_SHIFT;
         t->stat = read_byte (fd, &t->ch);
         if ( t->ch == '=' ) {
            appendChar (t->id, t->ch);
            t->sym = SYM_SHR_EQ;
            t->stat = read_byte (fd, &t->ch);
         }
         return;
      }
      if ( t->ch == '=' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_CMP_GE;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == '.' ) {
      t->sym = SYM_PERIOD;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == ':' ) {
      t->sym = SYM_COLON;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == ';' ) {
      t->sym = SYM_SEMICOLON;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == ',' ) {
      t->sym = SYM_COMMA;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   if ( t->ch == '+' ) {
      t->sym = SYM_PLUS;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '+' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_INCREMENT;
         t->stat = read_byte (fd, &t->ch);
         return;
      }
      if ( t->ch == '=' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_ADD_EQ;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == '-' ) {
      t->sym = SYM_MINUS;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '-' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_DECREMENT;
         t->stat = read_byte (fd, &t->ch);
         return;
      }
      if ( t->ch == '=' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_SUB_EQ;
         t->stat = read_byte (fd, &t->ch);
         return;
      }
      if ( t->ch == '>' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_ARROW;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == '*' ) {
      t->sym = SYM_ASTERISK;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '=' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_MULT_EQ;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == '%' ) {
      t->sym = SYM_REMINDER;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '=' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_REM_EQ;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   if ( t->ch == '!' ) {
      t->sym = SYM_EXCLAMATION_MARK;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '=' ) {
         appendChar (t->id, t->ch);
         t->sym = SYM_CMP_NEQ;
         t->stat = read_byte (fd, &t->ch);
      }
      return;
   }

   /* character literal */
   if ( t->ch == '\'' ) {
      i = 0;
      t->sym = SYM_CHARACTER;
//    t->id[i] = t->ch; i = i + 1;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '\\' ) {
         i=0;
         t->stat = read_byte (fd, &t->ch);
         if (t->ch == 'a')  { t->ch = '\a'; } else
         if (t->ch == 'f')  { t->ch = '\f'; } else
         if (t->ch == 'n')  { t->ch = '\n'; } else
         if (t->ch == 'r')  { t->ch = '\r'; } else
//       if (t->ch == '0')  { t->ch = '\0'; }
         if (isDigit (t->ch)) {
            t->num = (int)t->ch - 48;
            t->stat = read_byte (fd, &t->ch);
            if (isDigit (t->ch)) {
               t->num = (int)t->ch - 48 + 8*t->num;
               t->stat = read_byte (fd, &t->ch);
               if (isDigit (t->ch)) {
                  t->num = (int)t->ch - 48 + 8*t->num;
                  t->stat = read_byte (fd, &t->ch);
               }
            }
            t->id[0] = (char)t->num;
            t->id[1] = '\0';
            if ( t->ch == '\'' )
               t->stat = read_byte (fd, &t->ch);
            else
               t->sym = SYM_OTHER;
//          t->ch = t->id[0];
            return;
         }
      }
      t->id[i] = t->ch;  i = i + 1;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '\'' ) {
//       t->id[i] = t->ch;  i = i + 1;
         t->id[i] = '\0';
         t->stat = read_byte (fd, &t->ch);
         return;
      }
      t->sym = SYM_OTHER;
      t->id[i] = '\0';
      return;
   }

   /* pre-processor command */
   if ( t->ch == '#' ) {
      t->sym = SYM_NUMBER_SIGN;
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   /* comment */
   if ( t->ch == '/' ) {
      i = 0;
      t->id[i] = '/';  i = i + 1;
      t->stat = read_byte (fd, &t->ch);
      if ( t->ch == '/' ) {
         t->id[i] = t->ch;  i = i + 1;
         t->sym = SYM_COMMENT;
         while ( (t->stat = read_byte (fd, &t->ch)) > 0) {
//          if (t->ch == '\n') { t->line = t->line + 1; break; }
            if (t->ch == '\n') break;
            t->id[i] = t->ch;  i = i + 1;
         }
         t->id[i] = '\0';
         return;
      }
      if ( t->ch != '*' ) {
         t->sym = SYM_DIVIDE;
         t->id[i] = '\0';
         return;
      }
      if ( t->ch != '=' ) {
         t->sym = SYM_DIV_EQ;
         t->id[i] = '\0';
         return;
      }

      t->sym = SYM_COMMENT;
      while ( (t->stat = read_byte (fd, &t->ch)) > 0) {
         t->id[i] = t->ch;  i = i + 1;
         if (t->ch == '\n') t->line = t->line + 1;
         if ( i >= IDENT_MAX_LEN )
            break;
         if ( t->ch == '/' && t->id[i-2] == '*' )
            break;
      }
      t->id[i] = '\0';
      t->stat = read_byte (fd, &t->ch);
      return;
   }

   /* string literal */
   if ( t->ch == '"' ) {
      t->sym = SYM_LITERAL;
      i = 0;
      e = 0;
      hl = 0;
      while ( (t->stat = read_byte (fd, &t->ch)) > 0 ) {
         if ( hl ) {
            if (isDigit (t->ch) && hl < 3) {
               hl=hl+1;
               t->num = (int)t->ch - 48 + 8*t->num;
               t->id[i] = (char)t->num;
               continue;
            } else {
               hl=0;
               i = i + 1;
            }
         }
         if ( !e && t->ch == '"' )
            break;
         if (t->ch == '\n') t->line = t->line + 1;
         if (e) {
            if (t->ch == '\n') { e=0; continue; } else
            if (t->ch == 'a')  { t->ch = '\a';  } else
            if (t->ch == 'f')  { t->ch = '\f';  } else
            if (t->ch == 'n')  { t->ch = '\n';  } else
            if (t->ch == 'r')  { t->ch = '\r';  } else
//          if (t->ch == '0')  { t->ch = '\0'; hl=48; } else
            if (isDigit (t->ch)) {
               t->num = (int)t->ch - 48;
               t->id[i] = (char)t->num;
               hl = 1;
               continue;
            }
         }
         if (t->ch == '\\') e=1; else e=0;
         if (!e) { t->id[i] = t->ch;  i = i + 1; }
      }
      t->id[i] = '\0';
      t->stat = read_byte (fd, &t->ch);
      t->num = i+1;
      return;
   }

   /* idenifier */
   if ( isLetter (t->ch) ) {
      t->sym = SYM_IDENT;
      i = 0;
      while ( t->stat > 0 && (isLetter (t->ch) || isDigit (t->ch)) ) {
         t->id[i] = t->ch;  i = i + 1;
         if ( i >= IDENT_MAX_LEN )
            break;
         t->stat = read_byte (fd, &t->ch);
      }
      t->id[i] = '\0';

      if (!strcmp (t->id, "signed") )   t->sym = SYM_SIGNED;   else
      if (!strcmp (t->id, "unsigned") ) t->sym = SYM_UNSIGNED; else
      if (!strcmp (t->id, "auto") )     t->sym = SYM_AUTO;     else
      if (!strcmp (t->id, "register") ) t->sym = SYM_REGISTER; else
      if (!strcmp (t->id, "union") )    t->sym = SYM_UNION;    else
      if (!strcmp (t->id, "const") )    t->sym = SYM_CONST;    else
      if (!strcmp (t->id, "volatile") ) t->sym = SYM_VOLATILE; else
      if (!strcmp (t->id, "extern") )   t->sym = SYM_EXTERN;   else
      if (!strcmp (t->id, "static") )   t->sym = SYM_STATIC;   else
      if (!strcmp (t->id, "void") )     t->sym = SYM_VOID;     else
      if (!strcmp (t->id, "char") )     t->sym = SYM_CHAR;     else
      if (!strcmp (t->id, "int") )      t->sym = SYM_INT;      else
      if (!strcmp (t->id, "long") )     t->sym = SYM_LONG;     else
      if (!strcmp (t->id, "double") )   t->sym = SYM_DOUBLE;   else
      if (!strcmp (t->id, "float") )    t->sym = SYM_FLOAT;    else
      if (!strcmp (t->id, "enum") )     t->sym = SYM_ENUM;     else
      if (!strcmp (t->id, "short") )    t->sym = SYM_SHORT;    else
      if (!strcmp (t->id, "struct") )   t->sym = SYM_STRUCT;   else
      if (!strcmp (t->id, "typedef") )  t->sym = SYM_TYPEDEF;  else
      if (!strcmp (t->id, "if") )       t->sym = SYM_IF;       else
      if (!strcmp (t->id, "else") )     t->sym = SYM_ELSE;     else
      if (!strcmp (t->id, "while") )    t->sym = SYM_WHILE;    else
      if (!strcmp (t->id, "do") )       t->sym = SYM_DO;       else
      if (!strcmp (t->id, "for") )      t->sym = SYM_FOR;      else
      if (!strcmp (t->id, "break") )    t->sym = SYM_BREAK;    else
      if (!strcmp (t->id, "continue") ) t->sym = SYM_CONTINUE; else
      if (!strcmp (t->id, "return") )   t->sym = SYM_RETURN;   else
      if (!strcmp (t->id, "sizeof") )   t->sym = SYM_SIZEOF;   else
      if (!strcmp (t->id, "goto") )     t->sym = SYM_GOTO;     else
      if (!strcmp (t->id, "switch") )   t->sym = SYM_SWITCH;   else
      if (!strcmp (t->id, "case") )     t->sym = SYM_CASE;     else
      if (!strcmp (t->id, "default") )  t->sym = SYM_DEFAULT;

      return;
   }

   /* number */
   if ( isDigit (t->ch) ) {
      t->sym = SYM_NUMBER;
      if (t->ch == '0')  t->sym = SYM_OCT_NUMBER;
      i = 0;
      t->id[i] = t->ch;  i = i + 1;
      t->stat = read_byte (fd, &t->ch);

      if (t->ch == 'x' || t->ch == 'X') {
         t->sym = SYM_HEX_NUMBER;
         t->id[i] = t->ch;  i = i + 1;
         t->stat = read_byte (fd, &t->ch);
         if (!isHexDigit (t->ch)) {
            t->sym = SYM_OTHER;
            t->id[i] = '\0';
            t->stat = read_byte (fd, &t->ch);
            return;
         }
         while ( t->stat > 0 && isHexDigit (t->ch) ) {
            t->id[i] = t->ch;  i = i + 1;
            if ( i >= IDENT_MAX_LEN )
               break;
            t->stat = read_byte (fd, &t->ch);
         }
         t->id[i] = '\0';
         t->num = hex_string_to_int (t->id);
         return;
      }

      if (t->sym == SYM_OCT_NUMBER) {
         while ( t->stat > 0 && isOctDigit (t->ch) ) {
            t->id[i] = t->ch;  i = i + 1;
            if ( i >= IDENT_MAX_LEN )
               break;
            t->stat = read_byte (fd, &t->ch);
         }
         t->id[i] = '\0';
         t->num = oct_string_to_int (t->id);
         return;
      }

      while ( t->stat > 0 && isDigit (t->ch) ) {
         t->id[i] = t->ch;  i = i + 1;
         if ( i >= IDENT_MAX_LEN )
            break;
         t->stat = read_byte (fd, &t->ch);
      }
      t->id[i] = '\0';
      t->num = dec_string_to_int (t->id);
      return;
   }

   t->stat = read_byte (fd, &t->ch);
   return;
}


/**
 * \brief convert symbols to the corresponding text
 * \param sym the symbol
 * \return the symbol as a string
 *****************************************************************************/

char*
SymToStringCC (int sym) {
   if (sym == SYM_LEFT_PAREN)         return "left parenthesis symbol";
   if (sym == SYM_LEFT_BRACK)         return "left bracket symbol";
   if (sym == SYM_LEFT_BRACE)         return "left brace symbol";
   if (sym == SYM_LEFT_ANGLE_BRACK)   return "left angle bracket";
   if (sym == SYM_LEFT_SHIFT)         return "left shift symbol";
   if (sym == SYM_BAR)                return "bar symbol";
   if (sym == SYM_EQUAL)              return "equal symbol";
   if (sym == SYM_RIGHT_PAREN)        return "right parenthesis symbol";
   if (sym == SYM_RIGHT_BRACK)        return "right bracket symbol";
   if (sym == SYM_RIGHT_BRACE)        return "right brace symbol";
   if (sym == SYM_RIGHT_ANGLE_BRACK)  return "right angle bracket";
   if (sym == SYM_RIGHT_SHIFT)        return "right shift symbol";
   if (sym == SYM_PERIOD)             return "period symbol";
   if (sym == SYM_NUMBER_SIGN)        return "number sign";
   if (sym == SYM_DIVIDE)             return "arithmetic division";
   if (sym == SYM_REMINDER)           return "reminder of an integer division";
   if (sym == SYM_PLUS)               return "positive sign / addition";
   if (sym == SYM_MINUS)              return "negative sign / subtraction";
   if (sym == SYM_ASTERISK)           return "multiplication";
   if (sym == SYM_EXCLAMATION_MARK)   return "exclamation mark";
   if (sym == SYM_LOGICAL_OR)         return "logical or operator";
   if (sym == SYM_LOGICAL_AND)        return "logical and operator";
   if (sym == SYM_AMPERSAND)          return "ampersand symbol";
   if (sym == SYM_CMP_EQ)             return "comparison equal symbol";
   if (sym == SYM_CMP_NEQ)            return "comparison not equal symbol";
   if (sym == SYM_CMP_GE)             return "comparison greater or equal";
   if (sym == SYM_CMP_LE)             return "comparison lower or equal";
   if (sym == SYM_COLON)              return "colon";
   if (sym == SYM_SEMICOLON)          return "semi colon";
   if (sym == SYM_COMMA)              return "comma";
   if (sym == SYM_ARROW)              return "dereference operator";
   if (sym == SYM_MULT_EQ)            return "multiply in place";
   if (sym == SYM_DIV_EQ)             return "divide in place";
   if (sym == SYM_REM_EQ)             return "reminder in place";
   if (sym == SYM_ADD_EQ)             return "add in place";
   if (sym == SYM_SUB_EQ)             return "subtract in place";
   if (sym == SYM_SHL_EQ)             return "shift left in place";
   if (sym == SYM_SHR_EQ)             return "shift rigth in place";
   if (sym == SYM_AND_EQ)             return "bitwise and in place";
   if (sym == SYM_XOR_EQ)             return "bitwise xor in place";
   if (sym == SYM_OR_EQ)              return "bitwise or in place";
   if (sym == SYM_TILDE)              return "bitwise ones complement";
   if (sym == SYM_XOR)                return "bitwise xor";
   if (sym == SYM_INCREMENT)          return "increment operator";
   if (sym == SYM_DECREMENT)          return "decrement operator";

   if (sym == SYM_COMMENT)            return "comment symbol";
   if (sym == SYM_NUMBER)             return "number";
   if (sym == SYM_OCT_NUMBER)         return "octal number";
   if (sym == SYM_HEX_NUMBER)         return "hexa decimal number";
   if (sym == SYM_IDENT)              return "identifier symbol";
   if (sym == SYM_LITERAL)            return "string literal symbol";
   if (sym == SYM_CHARACTER)          return "a single character";

   if (sym == SYM_SIGNED)             return "signed";
   if (sym == SYM_UNSIGNED)           return "unsigned";
   if (sym == SYM_AUTO)               return "auto";
   if (sym == SYM_REGISTER)           return "register";
   if (sym == SYM_UNION)              return "union";
   if (sym == SYM_CONST)              return "const";
   if (sym == SYM_VOLATILE)           return "volatile";
   if (sym == SYM_EXTERN)             return "extern";
   if (sym == SYM_STATIC)             return "static";
   if (sym == SYM_VOID)               return "void";
   if (sym == SYM_CHAR)               return "char";
   if (sym == SYM_INT)                return "int";
   if (sym == SYM_LONG)               return "long";
   if (sym == SYM_DOUBLE)             return "double";
   if (sym == SYM_FLOAT)              return "float";
   if (sym == SYM_ENUM)               return "enum";
   if (sym == SYM_SHORT)              return "short";
   if (sym == SYM_STRUCT)             return "struct";
   if (sym == SYM_TYPEDEF)            return "typedef";

   if (sym == SYM_IF)                 return "if";
   if (sym == SYM_ELSE)               return "else";
   if (sym == SYM_WHILE)              return "while";
   if (sym == SYM_DO)                 return "do";
   if (sym == SYM_FOR)                return "for";
   if (sym == SYM_BREAK)              return "break";
   if (sym == SYM_CONTINUE)           return "continue";
   if (sym == SYM_RETURN)             return "return";
   if (sym == SYM_SIZEOF)             return "sizeof";
   if (sym == SYM_GOTO)               return "goto";
   if (sym == SYM_SWITCH)             return "switch";
   if (sym == SYM_CASE)               return "case";
   if (sym == SYM_DEFAULT)            return "default";


   if (sym == SYM_OTHER)              return "other symbol";
   if (sym == SYM_END)                return "end of input file";
   return "unknown symbol";
}
