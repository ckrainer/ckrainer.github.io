/**
 * \file cc_token_list.c
 * \brief CKPM C parser token list handling
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <stdlib.h>
#include <string.h>

//include "cpp_scan.h"
#include "cpp_token.h"
#include "cc_token_list.h"


/**
 * \brief append one token to the token list
 * \param tl the token list
 * \param t the token to be appended at the list
 * \return the pointer to the new list
 *****************************************************************************/

struct _token_list*
Token_List_Append (struct _token_list* tl, struct _token* t) {
   struct _token_list* l;
   struct _token_list* s;

   l = (struct _token_list*) malloc (sizeof(struct _token_list));
   s = tl;

   l->t = Token_Clone (t);
   l->next = (struct _token_list*)0;

   if (!tl) return l;

   while ( s->next ) s = s->next;
   s->next = l;
   return tl;
}


/**
 * \brief take the first token from a token list
 * \param tl the token list
 * \param t a pointer to a struct _token to write the shifted token data 
 * \return the pointer 
 *****************************************************************************/

struct _token_list*
Token_List_Shift  (struct _token_list* tl, struct _token* t) {
   struct _token_list* nl;
   nl = tl->next;

   if (t->file)  free ((void*)t->file);

   t->stat = tl->t->stat;
   t->sym  = tl->t->sym;
   t->line = tl->t->line;
   t->num  = tl->t->num;
   t->file = strdup (tl->t->file);
   t->ch   = tl->t->ch;
   strcpy (t->id, tl->t->id);

   Token_Destroy (tl->t);
   free ((void*)tl);
   return nl;
}


/**
 * \brief destroy a complete token list
 * \param tl the token list
 * \return the pointer
 *****************************************************************************/

void
Token_List_Destroy  (struct _token_list* tl) {
   struct _token_list* o;

   while (tl) {
      Token_Destroy (tl->t);
      o = tl;
      tl = o->next;
      free ((void*)o);
   }
}

