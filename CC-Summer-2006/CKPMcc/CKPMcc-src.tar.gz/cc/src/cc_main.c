/**
 * \file cc_main.c
 * \brief CKPM C compiler main program
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/


#include <unistd.h>
#include <string.h>

#include "cpp_io.h"
#include "cc_run.h"
#include "cc_scan.h"

#define CC_VERSION	0x00000001


/**
 * \brief print the usage message
 * \param exit_code variable containing the required return value
 * \return value from parameter exit_code
 *****************************************************************************/

int
print_usage (int exit_code) {
   put_string (STDERR_FILENO,
"Usage: CKPMcc [-hvV] -o out-file -i in-file -e err-file\n\n\
-h, --help          show this usage message.\n\
-i, --in            specifies the input file name (in-file).\n\
-o, --out           specifies the output file name (out-file).\n\
-e, --err           specifies the error file name (err-file).\n\
-v, --verbose       verbose mode, additional '-v' increase verbosity.\n\
-V, --version       show version\n"
   );
   return exit_code;
}


/**
 * \brief C compiler main program
 * \param argc argument counter, contains the number of entries in argv
 * \param argv argument vector
 * \return exit code, 0 on success, otherwise 1
 *****************************************************************************/

int
main (int argc, char** argv) {
   char* in_file_name;
   char* out_file_name;
   char* err_file_name;
   int verbose;
   int i;
   int rc;

   in_file_name = (char*)0;
   out_file_name = (char*)0;
   err_file_name = "-";
   verbose = 0;

   i=0;
   while (1) {
      i = i + 1;
      if (i >= argc)  break;

      if (!strcmp (argv[i], "--help") || !strcmp (argv[i], "-h") || !strcmp (argv[i], "-?")) {
         return print_usage (0);
      }

      if (!strcmp (argv[i], "--in") || !strcmp (argv[i], "-i") ) {
         i = i + 1;
         if (i < argc)
            in_file_name = argv[i];
         continue;
      }

      if (!strcmp (argv[i], "--out") || !strcmp (argv[i], "-o") ) {
         i = i + 1;
         if (i < argc)
            out_file_name = argv[i];
         continue;
      }

      if (!strcmp (argv[i], "--err") || !strcmp (argv[i], "-e") ) {
         i = i + 1;
         if (i < argc)
            err_file_name = argv[i];
         continue;
      }

      if (!strcmp (argv[i], "--version") || !strcmp (argv[i], "-V") ) {
         put_int (STDOUT_FILENO, CC_VERSION);
         return 0;
      }

      if (!strcmp (argv[i], "--verbose") || !strcmp (argv[i], "-v") ) {
         verbose = verbose + 1;
         continue;
      }

      if (i != argc)
         return print_usage (1);
   }

   if (!in_file_name || *in_file_name == 0 || !out_file_name || *out_file_name == 0)
         return print_usage (1);

   if (verbose) {
      put_string (STDOUT_FILENO, "Verbose mode, level is ");
      put_int    (STDOUT_FILENO, verbose);
      put_string (STDOUT_FILENO, ". CC version is ");
      put_int    (STDOUT_FILENO, CC_VERSION);
      put_string (STDOUT_FILENO, "\nInput file name is '");
      put_string (STDOUT_FILENO, in_file_name);
      put_string (STDOUT_FILENO, "'\nOutput file name is '");
      put_string (STDOUT_FILENO, out_file_name);
      put_string (STDOUT_FILENO, "'\n");
   }

   rc = cc_run (verbose, in_file_name, out_file_name, err_file_name);

   if (rc) return 0;
   return 1;
}
