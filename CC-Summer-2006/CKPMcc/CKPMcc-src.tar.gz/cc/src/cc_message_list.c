/**
 * \file cc_message_list.c
 * \brief CKPM C parser message list definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <stdlib.h>
#include <string.h>

#include "cpp_io.h"
#include "cc_message_list.h"


/**
 * \brief append one message to the message list
 * \param ml the message list
 * \param m the message to be appended at the list
 * \param t a pointer to an array for incrementing the number of the according message type
 * \return the pointer to the new list
 *****************************************************************************/

struct _message_list*
Message_List_Append (struct _message_list* ml, char * m, msgtype_t t) {
   struct _message_list* l;
   struct _message_list* s;

   l = (struct _message_list*) malloc (sizeof(struct _message_list));
   s = ml;

   l->msg = strdup (m);
   l->type = t;
   l->next = (struct _message_list*)0;

   if (!ml) return l;

   while ( s->next ) s = s->next;
   s->next = l;
   return ml;
}


/**
 * \brief take the first message from a message list
 * \param ml the message list
 * \param m a pointer to a char pointer to hand over the shifted message data 
 * \param t a pointer to an array for incrementing the number of the according message type
 * \return the pointer 
 *****************************************************************************/

struct _message_list*
Message_List_Shift  (struct _message_list* ml, char ** m, msgtype_t* t) {
   struct _message_list* nl;
   nl = ml->next;
   *m = ml->msg;
   if (t)  t[ml->type] = t[ml->type] + 1;
   free ((void*)ml);
   return nl;
}


/**
 * \brief destroy a complete message list
 * \param ml the message list
 *****************************************************************************/

void
Message_Destroy  (struct _message_list* ml) {
   struct _message_list* nl;

   while (ml) {
      nl = ml;
      ml = ml->next;
      free ((void*)nl->msg);
      free ((void*)nl);
   }
}


/**
 * \brief destroy a complete message list
 * \param fd file descriptor index for writing the messages
 * \param ml the message list
 * \param m a pointer to a message prefix
 * \param t a pointer to an array for incrementing the number of the according message type
 *****************************************************************************/

void
Message_List_Print  (struct _message_list* ml, int fd, char* m, msgtype_t* t) {
   while (ml) {
      put_string (fd, m);
      put_string (fd, ml->msg);
      if (t) t[ml->type] = t[ml->type] + 1;
      ml = ml->next;
   }
}

