/**
 * \file cc_parse_test.c
 * \brief CKPM C parser tester
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cc_test.h"
#include "cc_scan.h"
#include "cc_parse.h"

#define	MAX_LINES 6

static char* b[MAX_LINES] = {
   "char *strcpy(char *dest, const char *src);\n",
   "char *strncpy(char *dest, const char *src, int n);\n",
   "char *strcat(char *dest, const char *src);\n",
   "char *strncat(char *dest, const char *src, int n);\n",
   "int strcmp(const char *s1, const char *s2);\n",
   "int strncmp(const char *s1, const char *s2, int n);\n"
};


static int pr_error (char *s, int rc) { perror (s); return rc; }


/**
 * \brief read a symbol and print it
 * \param v != 0 if verbose output should be written
 * \param p pointer to the parser structure.
 *****************************************************************************/

static void
ReadSym (struct _parser* p, int v) {
   GetSymCC (p);
   if (v) printf ("read: sym=%-25s, id='%s'\n", SymToStringCC (p->t->sym), p->t->id);
}



/**
 * \brief test the stack based calculator
 * \param v != 0 if verbose output should be written
 * \return 0 if successful, 1 otherwise
 *****************************************************************************/

int
cc_parse_test (int v) {
   int ok = 0;
   int fail = 0;
   int rc;
   int k;
   int fd_in, fd_err;
   int fd_out = open ("nix.i", O_WRONLY | O_CREAT | O_TRUNC, 0644);
   struct _parser* p;
   struct _token* fst_1[20];
   struct _token* snd_1[20];
   struct _token* fst_2[20];
   struct _token* snd_2[20];
   int sp1;
   int sp2;

   for (k=0; k < MAX_LINES; k++) {
      write (fd_out, b[k], strlen (b[k]));
   }
   close (fd_out);

   fd_in  = open ("nix.i", O_RDONLY, 0);
   if (fd_in  < 0)  return pr_error ("nix.i",0);

   fd_out = open ("nix.o", O_WRONLY | O_CREAT | O_TRUNC, 0644);
   if (fd_out < 0)  return pr_error ("nix.o",0);

   fd_err = open ("nix.e", O_WRONLY | O_CREAT | O_TRUNC, 0644);
   if (fd_err < 0)  return pr_error ("nix.e",0);

   rc = 1;

   p = Parser_Create (fd_in, fd_out, fd_err);


   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_CHAR);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_ASTERISK);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_IDENT);
                   CHK_RESULT_STR ("Token Read", p->t->id, "strcpy");
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_LEFT_PAREN);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_CHAR);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_ASTERISK);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_IDENT);
                   CHK_RESULT_STR ("Token Read", p->t->id, "dest");
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_COMMA);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_CONST);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_CHAR);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_ASTERISK);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_IDENT);
                   CHK_RESULT_STR ("Token Read", p->t->id, "src");
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_RIGHT_PAREN);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_SEMICOLON);

   printf ("\nset save point 1.\n");
   sp1 = SetSavePoint (p);

   for (k=0; k < 17; k++) {
      ReadSym (p,v);
      fst_1[k] = Token_Clone (p->t);
   }

   printf ("\nrewind to save point.\n");
   Rewind (p, sp1);

   for (k=0; k < 17; k++) {
      ReadSym (p,v);
      snd_1[k] = Token_Clone (p->t);
   }

   for (k=0; k < 17; k++) {
      CHK_RESULT ("Token Reread", Token_Equals (fst_1[k], snd_1[k]), 1);
   }

   printf ("\ncontinue reading 1.\n");
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_CHAR);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_ASTERISK);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_IDENT);
                   CHK_RESULT_STR ("Token Read", p->t->id, "strcat");
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_LEFT_PAREN);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_CHAR);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_ASTERISK);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_IDENT);
                   CHK_RESULT_STR ("Token Read", p->t->id, "dest");
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_COMMA);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_CONST);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_CHAR);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_ASTERISK);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_IDENT);
                   CHK_RESULT_STR ("Token Read", p->t->id, "src");
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_RIGHT_PAREN);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_SEMICOLON);


   printf ("\nset save point 1 (again).\n");
   sp1 = SetSavePoint (p);

   for (k=0; k < 14; k++) {
      ReadSym (p,v);
      fst_1[k] = Token_Clone (p->t);
   }

   printf ("\nset save point 2.\n");
   sp2 = SetSavePoint (p);

   for (k=0; k < 17; k++) {
      ReadSym (p,v);
      fst_2[k] = Token_Clone (p->t);
   }

   printf ("\nrewind to save point 2.\n");
   Rewind (p, sp2);

   for (k=0; k < 17; k++) {
      ReadSym (p,v);
      snd_2[k] = Token_Clone (p->t);
   }

   for (k=0; k < 17; k++) {
      CHK_RESULT ("Token Reread sp2", Token_Equals (fst_2[k], snd_2[k]), 1);
   }

   printf ("\nrewind to save point 1.\n");
   Rewind (p, sp1);

   for (k=0; k < 14; k++) {
      ReadSym (p,v);
      snd_1[k] = Token_Clone (p->t);
   }

   for (k=0; k < 14; k++) {
      CHK_RESULT ("Token Reread sp1", Token_Equals (fst_1[k], snd_1[k]), 1);
   }


   for (k=0; k < 17; k++) {
      ReadSym (p,v);
      snd_2[k] = Token_Clone (p->t);
   }

   for (k=0; k < 17; k++) {
      CHK_RESULT ("Token Reread sp2 (again)", Token_Equals (fst_2[k], snd_2[k]), 1);
   }


   printf ("\nChecking Tokens from save point 1 to save point 2.\n");

   CHK_RESULT     ("Token Read", fst_1[ 0]->sym, SYM_CHAR);
   CHK_RESULT     ("Token Read", fst_1[ 1]->sym, SYM_ASTERISK);
   CHK_RESULT     ("Token Read", fst_1[ 2]->sym, SYM_IDENT);
   CHK_RESULT_STR ("Token Read", fst_1[ 2]->id, "strncat");
   CHK_RESULT     ("Token Read", fst_1[ 3]->sym, SYM_LEFT_PAREN);
   CHK_RESULT     ("Token Read", fst_1[ 4]->sym, SYM_CHAR);
   CHK_RESULT     ("Token Read", fst_1[ 5]->sym, SYM_ASTERISK);
   CHK_RESULT     ("Token Read", fst_1[ 6]->sym, SYM_IDENT);
   CHK_RESULT_STR ("Token Read", fst_1[ 6]->id, "dest");
   CHK_RESULT     ("Token Read", fst_1[ 7]->sym, SYM_COMMA);
   CHK_RESULT     ("Token Read", fst_1[ 8]->sym, SYM_CONST);
   CHK_RESULT     ("Token Read", fst_1[ 9]->sym, SYM_CHAR);
   CHK_RESULT     ("Token Read", fst_1[10]->sym, SYM_ASTERISK);
   CHK_RESULT     ("Token Read", fst_1[11]->sym, SYM_IDENT);
   CHK_RESULT_STR ("Token Read", fst_1[11]->id, "src");
   CHK_RESULT     ("Token Read", fst_1[12]->sym, SYM_COMMA);
   CHK_RESULT     ("Token Read", fst_1[13]->sym, SYM_INT);


   printf ("\nChecking Tokens from save point 2 to rewind point.\n");
   CHK_RESULT     ("Token Read", fst_2[ 0]->sym, SYM_IDENT);
   CHK_RESULT_STR ("Token Read", fst_2[ 0]->id, "n");
   CHK_RESULT     ("Token Read", fst_2[ 1]->sym, SYM_RIGHT_PAREN);
   CHK_RESULT     ("Token Read", fst_2[ 2]->sym, SYM_SEMICOLON);
   CHK_RESULT     ("Token Read", fst_2[ 3]->sym, SYM_INT);
   CHK_RESULT     ("Token Read", fst_2[ 4]->sym, SYM_IDENT);
   CHK_RESULT_STR ("Token Read", fst_2[ 4]->id, "strcmp");
   CHK_RESULT     ("Token Read", fst_2[ 5]->sym, SYM_LEFT_PAREN);
   CHK_RESULT     ("Token Read", fst_2[ 6]->sym, SYM_CONST);
   CHK_RESULT     ("Token Read", fst_2[ 7]->sym, SYM_CHAR);
   CHK_RESULT     ("Token Read", fst_2[ 8]->sym, SYM_ASTERISK);
   CHK_RESULT     ("Token Read", fst_2[ 9]->sym, SYM_IDENT);
   CHK_RESULT_STR ("Token Read", fst_2[ 9]->id, "s1");
   CHK_RESULT     ("Token Read", fst_2[10]->sym, SYM_COMMA);
   CHK_RESULT     ("Token Read", fst_2[11]->sym, SYM_CONST);
   CHK_RESULT     ("Token Read", fst_2[12]->sym, SYM_CHAR);
   CHK_RESULT     ("Token Read", fst_2[13]->sym, SYM_ASTERISK);
   CHK_RESULT     ("Token Read", fst_2[14]->sym, SYM_IDENT);
   CHK_RESULT_STR ("Token Read", fst_2[14]->id, "s2");
   CHK_RESULT     ("Token Read", fst_2[15]->sym, SYM_RIGHT_PAREN);
   CHK_RESULT     ("Token Read", fst_2[16]->sym, SYM_SEMICOLON);


   printf ("\ncontinue reading 2.\n");
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_INT);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_IDENT);
                   CHK_RESULT_STR ("Token Read", p->t->id, "strncmp");
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_LEFT_PAREN);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_CONST);
/*
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_CHAR);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_ASTERISK);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_IDENT);
                   CHK_RESULT_STR ("Token Read", p->t->id, "s1");
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_COMMA);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_CONST);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_CHAR);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_ASTERISK);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_IDENT);
                   CHK_RESULT_STR ("Token Read", p->t->id, "s2");
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_COMMA);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_INT);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_IDENT);
                   CHK_RESULT_STR ("Token Read", p->t->id, "n");
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_RIGHT_PAREN);
   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_SEMICOLON);

   ReadSym (p,v);  CHK_RESULT     ("Token Read", p->t->sym, SYM_END);
*/

   sp1 = SetSavePoint (p);
   printf ("\nset save point 1 (once more) (%d).\n",sp1);

   ReadSym (p,v);  CHK_RESULT     ("Token Once More", p->t->sym, SYM_CHAR);
   ReadSym (p,v);  CHK_RESULT     ("Token Once More", p->t->sym, SYM_ASTERISK);
   ReadSym (p,v);  CHK_RESULT     ("Token Once More", p->t->sym, SYM_IDENT);
                   CHK_RESULT_STR ("Token Once More", p->t->id, "s1");
   printf ("\nrewind to save point 1. (%d)\n",sp1);
   Rewind (p,sp1);
   ReadSym (p,v);  CHK_RESULT     ("Token Once More", p->t->sym, SYM_CHAR);

   sp2 = SetSavePoint (p);
   printf ("\nset save point 2 (once more). (%d)\n",sp2);

   ReadSym (p,v);  CHK_RESULT     ("Token Once More", p->t->sym, SYM_ASTERISK);
   ReadSym (p,v);  CHK_RESULT     ("Token Once More", p->t->sym, SYM_IDENT);
                   CHK_RESULT_STR ("Token Once More", p->t->id, "s1");
   ReadSym (p,v);  CHK_RESULT     ("Token Once More", p->t->sym, SYM_COMMA);
   ReadSym (p,v);  CHK_RESULT     ("Token Once More", p->t->sym, SYM_CONST);
   ReadSym (p,v);  CHK_RESULT     ("Token Once More", p->t->sym, SYM_CHAR);
   ReadSym (p,v);  CHK_RESULT     ("Token Once More", p->t->sym, SYM_ASTERISK);
   ReadSym (p,v);  CHK_RESULT     ("Token Once More", p->t->sym, SYM_IDENT);


   Parser_Destroy (p);

   close (fd_in);
   close (fd_out);
   close (fd_err);

   printf ("%d subtests total, %d ok, %d failed\n", ok+fail, ok, fail);

   return fail;
}
