#!/bin/sh
#
# @(#) cc_test.sh - run the parser test scripts.
#

CC=${CKPMCC-../CKPMcc}
CC_TEST=${CC_TEST-./cc_test}
TMP=/tmp/cc_test.$$;

#trap "rm -f $TMP nix.i nix.o nix.e;" 0 1 2 15
trap "rm -f $TMP ;" 0 1 2 15

die () { echo "$*"; exit 1; }

[ ! -x "$CC" ] && die "Can not find pre-processor executable. Aborting.";

[ "$*" = "" ] && die "Usage: $(basename $0) test1 [test2] [test3] ...";

rc=0;
{
$CC_TEST

for f in $*; do
   ok=0;
   echo
   echo "Running tests $f";
   rm -f nix.i nix.o nix.e
   ../../../pp/src/CKPMpp -I ../../../libc/include -I ../../../libc -i $f -o nix.i;
   if $CC --in nix.i --out nix.o -e nix.e # > /dev/null 2>&1
   then
      echo "Parser succeeded.";
      ok=1;
   else
      echo "Parser failed.";
      rc=1;
   fi

   loc=$(grep '[;{]' nix.i | grep -v -e '^0x' | wc -l)
   err=$(grep '^ERROR:' nix.e | wc -l)
   eo=${f/.src}.err;
   obj=${f/.src}.obj;
   if [ -f "$eo" ]
   then
      echo -n "Checking error output against $eo ... ";
      grep '^ERROR:' nix.e > nix.eo;
      if diff nix.eo $eo
      then echo "ok"; err=0; ok=1;
      else echo "error"; err=1; ok=0; fi
   fi

   if [ -f "$obj" ]
   then
      echo -n "Checking compiler output against $obj ... ";
      if cmp nix.o $obj
      then echo "ok"; ok=1;
      else echo "error"; ok=0; err=$(expr $err + 1); fi
   fi

   [ "$ok" -eq 1 ] && ok=$loc;

   printf "%d subtests total, %d ok, %d errors\n" $loc $ok $err;
   [ $err -ne 0 ] && rc=1;  
done
} | awk '
      {print;}
      /subtests total/ { t=t+$1; o=o+$4; e=e+$6; }
      END {
            printf("\nSummary:  %d tests total, %d ok, %d errors\n",t,o,e);
            exit (e?1:0);
      }' || rc=1;


[ "$rc" -eq 0 ] \
   && echo "All tests succeeded." \
   || echo "Tests failed, see above for details.";

exit $rc;
