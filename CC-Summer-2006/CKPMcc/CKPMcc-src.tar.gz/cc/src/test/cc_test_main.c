/**
 * \file cc_test_main.c
 * \brief CKPM C parser test driver
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cc_test.h"

/**
 * \brief print the usage message
 * \param exit_code variable containing the required return value
 * \return value from parameter exit_code
 *****************************************************************************/

int
print_usage (int exit_code) {
   printf (
         "Usage: cc_test [-hvV] -o out-file -i in-file -e err-file\n\n"
         "-v, --verbose       verbose mode, additional '-v' increase verbosity.\n"
   );
   return exit_code;
}


/**
 * \brief pre-processor test driver
 * \param argc argument counter
 * \param argv argument values
 * \return 0 on success, otherwise 1
 *****************************************************************************/

int
main (int argc, char** argv) {
   int rc = 0;
   int rcl;
   int verbose = 0;
   int i;

   for (i = 1; i < argc; i++) {
       if (!strcmp (argv[i], "--verbose") || !strcmp (argv[i], "-v") ) {
         verbose++;
         continue;
      }

      if (i+1 != argc)
         return print_usage (1);
   }


   printf ("\ncc_parse_test:\n");  rcl = cc_parse_test (verbose);   rc |= rcl;


   printf ("result ... %s\n", rc ? "failed":"ok");

   return rc?1:0;
}
