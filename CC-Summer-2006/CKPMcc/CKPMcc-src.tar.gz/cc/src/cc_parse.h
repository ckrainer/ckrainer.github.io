/**
 * \file cc_parse.h
 * \brief CKPM C compiler parser definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef	_CKPM_CC_PARSE_H_
#define	_CKPM_CC_PARSE_H_

#include "cpp_token.h"
#include "cc_token_list.h"
#include "cc_symtab.h"
#include "cc_code_gen.h"


#define	MIN_ERROR_DIST	3		/*<! minimal distance to last error */

/**
 * \struct _parser
 * \brief parser administrative variables
 *****************************************************************************/

struct _parser {
   int fd_in;				/*!< input file descriptor index */
   int fd_out;				/*!< input file descriptor index */
   int fd_err;				/*!< input file descriptor index */
   int rec;				/*!< != 0 if token save point is set */
   int len;				/*!< current length of the saved token list */
   int rew;				/*!< allow rewinding */
   int errDist;				/*!< distance to the last error message */
   int infos;				/*!< the number of info messages */
   int warnings;			/*!< the number of warning messages */
   int errors;				/*!< the number of error messages */
   int oldpc;				/*!< cg->pc at last top level save point */
   int olddidx;				/*!< cg->didx at last top level save point */
   struct _token* t;			/*!< actual token */
   struct _token_list *rd;		/*!< read pointer in the saved token list */
   struct _token_list *sp;		/*!< list of saved tokens */
   struct _message_list *ml;		/*!< postponed error messages */
   struct _symtab* st;			/*!< symbol table */
   struct _codegen* cg;			/*!< code generator */
};


/*
 * forward declarations
 */
struct _parser* Parser_Create (int fd_in, int fd_out, int fd_err);
void Parser_Destroy (struct _parser* p);

void GetSymCC (struct _parser *p);
void SkipToSymCC (struct _parser *p, int sym);
int SetSavePoint (struct _parser* p);
void Rewind (struct _parser* p, int sp);
void Release (struct _parser* p, int sp);

int cc_parse (struct _parser* p);

struct _object* NewObj (struct _parser* p, class_t cls, char* ident);
void DelObj (struct _parser* p, struct _object* o);
struct _object* Find (struct _parser* p, char* ident, int err);
struct _object* FindField (struct _parser* p, struct _object* list);
int Is_Parameter (struct _object* par);

int Compare_Field_Types (struct _parser* p, struct _object* f1, struct _object* f2);
void Destroy_Fields (struct _parser* p, struct _object* f1);


void Make_Item (struct _parser* p, struct _item* x, struct _object* obj);
void Make_Const_Item (struct _parser* p, struct _item* x, struct _type* typ, int val);
void Make_Link_Item (struct _parser* p, struct _item* x, struct _type* typ, int st, int end, int ret, int wl);
void Make_Void_Item (struct _parser* p, struct _item* x);
void Make_Boolean_Item (struct _parser* p, struct _item* x);
void Make_Temp_Item (struct _parser* p, struct _item* x, class_t md, struct _type* ty);
void Index (struct _parser* p, struct _item* x, struct _item* y);
void Field (struct _parser* p, struct _item* x, struct _object* y);
void PointerField (struct _parser* p, struct _item* x, struct _object* y);
void Load_Boolean (struct _parser* p, struct _item* x);
void Store (struct _parser* p, struct _item* x, struct _item* y);
void Relation (struct _parser* p, int op, struct _item* x, struct _item* y);
int Get_Unary_Operator (struct _parser* p);
void Unary_Operator (struct _parser* p, int op, struct _item* x);
void Dual_Operator (struct _parser* p, int op, struct _item* x, struct _item* y);
// void Parameter (struct _parser* p, struct _item* x, struct _type* ftyp, class_t cls);
void Conditional_Jump (struct _parser* p, struct _item* x);


void Pre_Increment (struct _parser* p, struct _item* x);
void Pre_Decrement (struct _parser* p, struct _item* x);
void Post_Increment (struct _parser* p, struct _item* x);
void Post_Decrement (struct _parser* p, struct _item* x);


#endif /* _CKPM_CC_PARSE_H_ */

