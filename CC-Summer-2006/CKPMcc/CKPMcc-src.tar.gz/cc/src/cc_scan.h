/**
 * \file cc_scan.h
 * \brief CKPM C compiler scanner definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef	_CKPM_CC_SCAN_H_
#define	_CKPM_CC_SCAN_H_

#include "cpp_token.h"


#define	SYM_LEFT_PAREN  	3	/*!< '('   left parenthesis symbol */
#define	SYM_LEFT_BRACK  	4	/*!< '['   left bracket symbol */
#define	SYM_LEFT_BRACE  	5	/*!< '{'   left brace symbol */
#define	SYM_LEFT_ANGLE_BRACK	6	/*!< '<'   left angle bracket */
#define	SYM_LEFT_SHIFT		7	/*!< '<<'  left shift symbol */
#define	SYM_BAR         	8	/*!< '|'   bar symbol */
#define	SYM_EQUAL       	9	/*!< '='   equal symbol */
#define	SYM_RIGHT_PAREN 	10	/*!< ')'   right parenthesis symbol */
#define	SYM_RIGHT_BRACK 	11	/*!< ']'   right bracket symbol */
#define	SYM_RIGHT_BRACE 	12	/*!< '}'   right brace symbol */
#define	SYM_RIGHT_ANGLE_BRACK	13	/*!< '>'   right angle bracket */
#define	SYM_RIGHT_SHIFT		14	/*!< '>>'  right shift symbol */
#define	SYM_PERIOD      	15	/*!< '.'   period symbol */
#define	SYM_NUMBER_SIGN		18	/*!< '#'   number sign */
#define	SYM_DIVIDE		24	/*!< '/'   arithmetic division */
#define	SYM_REMINDER		25	/*!< '\%'  reminder of an integer division */
#define	SYM_PLUS		27	/*!< '+'   positive sign / addition */
#define	SYM_MINUS		28	/*!< '-'   negative sign / subtraction */
#define	SYM_ASTERISK		29	/*!< '*'   multiplication */
#define	SYM_EXCLAMATION_MARK	30	/*!< '!'   exclamation mark */
#define	SYM_LOGICAL_OR		31	/*!< '||'  logical or operator */
#define	SYM_LOGICAL_AND		32	/*!< '&&'  logical and operator */
#define	SYM_AMPERSAND		33	/*!< '&'   ampersand symbol */
#define	SYM_CMP_EQ		34	/*!< '=='  comparison equal symbol */
#define	SYM_CMP_NEQ		35	/*!< '!='  comparison not equal symbol */
#define	SYM_CMP_GE		36	/*!< '>='  comparison greater or equal */
#define	SYM_CMP_LE		37	/*!< '<='  comparison lower or equal */
#define	SYM_COLON		38	/*!< ':'   colon */
#define	SYM_SEMICOLON		39	/*!< ';'   semi colon */
#define	SYM_COMMA		40	/*!< ','   comma */
#define	SYM_ARROW		41	/*!< '->'  dereference operator */
#define	SYM_MULT_EQ		42	/*!< '*='  multiply in place */
#define	SYM_DIV_EQ		43	/*!< '/='  divide in place */
#define	SYM_REM_EQ		44	/*!< '%='  reminder in place */
#define	SYM_ADD_EQ		45	/*!< '+='  add in place */
#define	SYM_SUB_EQ		46	/*!< '-='  subtract in place */
#define	SYM_SHL_EQ		47	/*!< '<<=' shift left in place */
#define	SYM_SHR_EQ		48	/*!< '>>=' shift rigth in place */
#define	SYM_AND_EQ		49	/*!< '&='  bitwise and in place */
#define	SYM_XOR_EQ		50	/*!< '^='  bitwise xor in place */
#define	SYM_OR_EQ		51	/*!< '|='  bitwise or in place */
#define	SYM_TILDE		52	/*!< '~'   bitwise ones complement */
#define	SYM_XOR			53	/*!< '^'   bitwise xor */
#define	SYM_INCREMENT		54	/*!< '++'  increment operator */
#define	SYM_DECREMENT		55	/*!< '--'  decrement operator */


#define	SYM_COMMENT     	100	/*!< comment symbol */
#define	SYM_NUMBER		102	/*!< decimal number */
#define	SYM_OCT_NUMBER		103	/*!< octal number */
#define	SYM_HEX_NUMBER		104	/*!< hexa decimal number */
#define	SYM_IDENT       	105	/*!< identifier symbol */
#define	SYM_LITERAL     	106	/*!< string literal symbol */
#define	SYM_CHARACTER		107	/*!< a single character */

#define	SYM_SIGNED		201	/*!< signed */
#define	SYM_UNSIGNED		202	/*!< unsigned */
#define	SYM_AUTO		203	/*!< auto */
#define	SYM_REGISTER		204	/*!< register */
#define	SYM_UNION		205	/*!< union */
#define	SYM_CONST		206	/*!< const */
#define	SYM_VOLATILE		207	/*!< volatile */
#define	SYM_EXTERN		208	/*!< extern */
#define	SYM_STATIC		209	/*!< static */
#define	SYM_VOID		210	/*!< type void */
#define	SYM_CHAR		211	/*!< type char */
#define	SYM_INT			212	/*!< type int */
#define	SYM_LONG		213	/*!< type long */
#define	SYM_DOUBLE		214	/*!< type double */
#define	SYM_FLOAT		215	/*!< type float */
#define	SYM_ENUM		216	/*!< enum */
#define	SYM_SHORT		217	/*!< type short */
#define	SYM_STRUCT		218	/*!< struct */
#define	SYM_TYPEDEF		219	/*!< typedef */

#define	SYM_IF			220	/*!< if */
#define	SYM_ELSE		221	/*!< else */
#define	SYM_WHILE		222	/*!< while */
#define	SYM_DO			223	/*!< do */
#define	SYM_FOR			224	/*!< for */
#define	SYM_BREAK		225	/*!< break */
#define	SYM_CONTINUE		226	/*!< continue */
#define	SYM_RETURN		227	/*!< return */
#define	SYM_SIZEOF		228	/*!< sizeof */
#define	SYM_GOTO		229	/*!< goto */
#define	SYM_SWITCH		230	/*!< switch */
#define	SYM_CASE		231	/*!< case */
#define	SYM_DEFAULT		232	/*!< default */

#define	SYM_OTHER       	1000	/*!< other symbol */
#define	SYM_END		       	2000	/*!< no more symbols to read */

/*
 * forward declarations
 */

void GetSymIntCC (int fd, struct _token* t);
char* SymToStringCC (int sym);

#endif /* _CKPM_CC_SCAN_H_ */

