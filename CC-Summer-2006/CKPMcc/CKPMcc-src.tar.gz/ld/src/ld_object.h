/**
 * \file ld_object.h
 * \brief CKPM linker object manipulation definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef _CKPM_LD_OBJECT_H_
#define _CKPM_LD_OBJECT_H_

#include "cklf.h"

/**
 * \struct _ld_sym
 * \brief a liked list of linker symbols
 *
 * Imported symbols:
 *
 * Imported symbols have allways set value=0, size=0, type=LD_TYPE_NOTYPE and
 * bind=LD_BIND_GLOBAL
 *
 * Exported symbols:
 *
 * Exported symbols have set size!=0 and a type LD_TYPE_FUNC for code or
 * LD_TYPE_OBJECT for data. Additionally bind is set to LD_BIND_GLOBAL.
 *
 * Local symbols:
 *
 * With bind equals LD_BIND_LOCAL the according entry is a local symbol.
 *
 *****************************************************************************/

struct _ld_sym {
  char*			name;		/*!< symbol name */
  int			value;		/*!< symbol value */
  int			size;		/*!< symbol size */
  st_type_t		type;		/*!< symbol type */
  st_bind_t		bind;		/*!< symbol binding */
  struct _ld_sym*	next;		/*!< next entry or 0 */
};


/**
 * \struct _ld_rel_text
 * \brief a linked list of relocation entries
 *****************************************************************************/

struct _ld_rel_text {
   int			offs;		/*!< address */
   st_type_t		type;		/*!< relocation type */
   int			sym;		/*!< relocation symbol index */
   struct _ld_rel_text*	next;		/*!< next entry or 0 */
};



/**
 * \struct _ld_link_obj
 * \brief a linked list of cklf object file information for linke editing
 *****************************************************************************/

struct _ld_link_obj {
   int			data_len;	/*!< lenght of data segment */
   int			data_offs;	/*!< data segment offset after loading */
   int			code_len;	/*!< length of code segment */
   int			code_offs;	/*!< code segment offset after loading */
   int			sym_len;	/*!< length of the symbol table */
   struct _cklf_symtab*	sym_tab;	/*!< symbol table after loading */
   int			str_len;	/*!< length of the string table */
   char*		str_tab;	/*!< string table after loading */
   char*		fname;		/*!< name of the object file */
   struct _ld_link_obj* next;		/*!< next entry or 0 */
};


/**
 * \struct _ld_link_mgmt
 * \brief contains link management information
 *****************************************************************************/

struct _ld_link_mgmt {
   int			ds_len;		/*!< length of the data segment */
   int			cs_len;		/*!< length of the code segment */
   char*                ds;		/*!< data segment */
   char*                cs;		/*!< code segment */
   struct _ld_link_obj*	obj;		/*!< file information linked list */
   struct _ld_sym*	lds;		/*!< the symbol table as a linked list */
};



struct _ld_sym* LdSym_Create (char* name, int val, int size, int typ, int bnd, struct _ld_sym* nxt);
void LdSym_Destroy (struct _ld_sym* lds);
void LdSym_Dump (struct _ld_sym* lds, int fd);

struct _ld_sym* LdSym_Find (struct _ld_sym* lds, char* n);
int CKLF_Store (int fd_err, char* fname, char* data, int datsz, char* code, int codsz, struct _ld_sym* lds);
int CKLF_Load (int fd_err, char* fname, char* mem, int memsz, int* start);
int CKLF_Link (int fd_err, int verbose, char* ofile, int nr, char** ifiles);

#endif
