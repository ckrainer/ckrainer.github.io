/**
 * \file ld_object.c
 * \brief CKPM linker object manipulation
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Authors: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/


#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include "cpp_io.h"
#include "cpp_conv.h"
#include "ld_object.h"
#include "cklf.h"

#ifdef DEBUG
#include "vm_disasm.h"
#endif

/**
 * \brief create a linker symbol list entry
 * \param name the symbol name
 * \param val the symbol value
 * \param size the symbol size
 * \param typ the symbol type
 * \param bnd the symbol binding information
 * \param nxt a pointer to the next node
 * \return a pointer to the newly created symbol list entry
 *****************************************************************************/

struct _ld_sym*
LdSym_Create (char* name, int val, int size, int typ, int bnd, struct _ld_sym* nxt) {
   struct _ld_sym* lds;
   lds = (struct _ld_sym*) malloc (sizeof (struct _ld_sym));
   lds->name = (char*)0;
   if (name)  lds->name = strdup (name);
   lds->value = val;
   lds->size = size;
   lds->type = typ;
   lds->bind = bnd;
   lds->next = nxt;
   return lds;
}


/**
 * \brief destroy a linker symbol list entry
 * \param lds a pointer to the linker symbol table
 *****************************************************************************/

void
LdSym_Destroy (struct _ld_sym* lds) {
   if (lds->name)  free ((void*)lds->name);
   free ((void*)lds);
}


/**
 * \brief dump the entire linker symbol list
 * \param lds a pointer to the linker symbol table
 * \param fd a filedescriptor index of an open file
 *****************************************************************************/

void
LdSym_Dump (struct _ld_sym* lds, int fd) {
   char buf[30];
   put_string (fd, "\nLinker Symbol Table:\n");
   while (lds) {
      put_string (fd, "name='");
      put_string (fd, lds->name);
      put_string (fd, "', addr=0x");
      put_string (fd, int_to_str (buf, 30, 16, lds->value) );
      put_string (fd, ", offs=0x");
      put_string (fd, int_to_str (buf, 30, 16, lds->size) );
      put_string (fd, ", type=");
      put_string (fd, CKLF_ST_TypeToStr (lds->type) );
      put_string (fd, ", binding=");
      put_string (fd, CKLF_ST_BindToStr (lds->bind) );
      put_string (fd, "\n");
      lds = lds->next;
   }
}


/**
 * \brief find a linker symbol in the list
 * \param lds the linker symbol list
 * \param n the symbol name
 * \return a pointer to the entry or 0 if none was found
 *****************************************************************************/

struct _ld_sym*
LdSym_Find (struct _ld_sym* lds, char* n) {
   if (!lds || !n)
      return (struct _ld_sym*)0;

   while ( lds ) {
      if (!strcmp (lds->name, n))
         return lds;
      lds = lds->next;
   }

   return (struct _ld_sym*)0;
}


/**
 * \brief determine the length of the symbol list
 * \param lds the linker symbol list
 * \return the length of this list
 *****************************************************************************/

int
LdSym_Length (struct _ld_sym* lds) {
   int n; n = 0;
   while (lds) {
      lds = lds->next;
      n = n + 1;
   }
   return n;
}


/**
 * \brief determine the length of the symbol list strings
 * \param lds the linker symbol list
 * \return the length of this list
 *****************************************************************************/

int
LdSym_StrLength (struct _ld_sym* lds) {
   int n; n = 0;
   while (lds) {
      n = n + strlen (lds->name) + 1;
      lds = lds->next;
   }
   return n;
}


/**
 * \brief create a struct _ld_link_mgmt on the heap
 * \return a pointer to the created structure
 *****************************************************************************/

struct _ld_link_mgmt*
LdMgmt_Create () {
   struct _ld_link_mgmt* m;
   m = (struct _ld_link_mgmt*) malloc (sizeof (struct _ld_link_mgmt));
   m->ds = (char*)0;
   m->cs = (char*)0;
   m->obj = (struct _ld_link_obj*)0;
   m->lds = (struct _ld_sym*)0;
   return m;
}


/**
 * \brief destroy a struct _ld_link_mgmt on the heap
 * \param m a pointer to the _ld_link_mgmt structure
 *****************************************************************************/

void
LdMgmt_Destroy (struct _ld_link_mgmt* m) {
   struct _ld_link_obj* n;
   struct _ld_link_obj* o;

   if (!m)  return;

   o = m->obj;
   while (o) {
      if (o->sym_tab)  free ((void*)o->sym_tab);
      if (o->str_tab)  free ((void*)o->str_tab);
      n = o->next; free ((void*)o); o = n;
   }

   LdSym_Destroy (m->lds);
  
   if (m->ds)  free ((void*)m->ds);
   if (m->cs)  free ((void*)m->cs);
   free ((void*)m);
}


/**
 * \brief alignment calculation
 * \param a the address
 * \param b the alignment size
 *****************************************************************************/

int
Ld_Align (int a, int b) {
   if (a % b)  a = a + b - a % b;
   return a;
}


/**
 * \brief read four bytes from the code at a given address
 * \param c a pointer to the code
 * \param at the address in the code
 * \return the four bytes as an integer value
 *****************************************************************************/

int
Ld_Read_Long (char* c, int at) {
// return ((int)(c[at])  << 24) | ((int)(c[at+1]) << 16) |
//        ((int)(c[at+2]) << 8) |  (int)(c[at+3]);
   return (((int)(c[at])   << 24) & 0xFF000000) |
          (((int)(c[at+1]) << 16) & 0xFF0000) |
          (((int)(c[at+2]) <<  8) & 0xFF00) |
          (((int)(c[at+3])      ) & 0xFF);
}


/**
 * \brief write four bytes to the code
 * \param c a pointer to the code
 * \param at the address in the code
 * \param with the new value
 *****************************************************************************/

void
Ld_Write_Long (char* c, int at, int with) {
   c[at]   = (char)((with >> 24) & 0xFF);
   c[at+1] = (char)((with >> 16) & 0xFF);
   c[at+2] = (char)((with >>  8) & 0xFF);
   c[at+3] = (char)( with        & 0xFF);
}


/**
 * \brief do the branch destination fixup
 * \param c a pointer to the code
 * \param dst the new destination
 * \param l the address in the code of the parameter of a branch statement
 * \param o offset in the code
 *****************************************************************************/

void
Ld_Fix_Link_Long (char* c, int dst, int l, int o) {
   int l1;
   while (l) {
      l1 = Ld_Read_Long (c, l+o);
      Ld_Write_Long (c, l+o, dst);
      l = l1;
   }
}


/**
 * \brief create a CKLF file from compiled code, data and symbol table
 * \param fd_err a file discriptor index to an open file for error output
 * \param fname the name of the file for saving
 * \param data the area of initialised data
 * \param datsz the size of this data area
 * \param code the compiled code
 * \param codsz the size of this code area
 * \param lds a pointer to the linker symbol table
 * \return <0 on failure during I/O, otherwise all ran ok.
 *****************************************************************************/

int
CKLF_Store (int fd_err, char* fname, char* data, int datsz, char* code,
            int codsz, struct _ld_sym* lds)
{
   int lds_len;
   int strtab_len;
   int k;
   int i;
   struct _cklf_hdr hdr;
   struct _cklf_symtab sym;
   int rc;
   int fd;
   char *str;

   fd = open (fname, O_WRONLY|O_CREAT|O_TRUNC, 0644);
   if (fd < 0)  return fd;

   lds_len = LdSym_Length (lds);
   strtab_len = LdSym_StrLength (lds);

   /* write the file header*/
   hdr.ident[7] = '\0';
   strcpy (hdr.ident, CKLF_MAG);
   hdr.version = CKLF_VERSION;
   hdr.prog = sizeof (struct _cklf_hdr);
   hdr.data = hdr.prog + codsz;
   hdr.symtab = hdr.data + datsz;
   hdr.strtab = hdr.symtab + lds_len * sizeof (struct _cklf_symtab);
   hdr.total_sz = hdr.strtab + strtab_len;
   rc = write (fd, (void*)&hdr, sizeof (struct _cklf_hdr));
   if (rc < 0)  return rc;

   /* write the program segment */
   rc = write (fd, (void*)code, codsz);
   if (rc < 0)  return rc;

   /* write the data segment */
   rc = write (fd, (void*)data, datsz);
   if (rc < 0)  return rc;

   /* write the symbol table */
   str = (char*) malloc (strtab_len);
   k = 0;
   while (lds) {
      sym.name = k;
      sym.addr = lds->value;
      sym.offs = lds->size;
      sym.type = lds->type;
      sym.bind = lds->bind;
      i=0;
      while ( (str[k] = lds->name[i]) ) { k = k + 1; i = i + 1; }
      k = k + 1;
      rc = write (fd, (void*)&sym, sizeof (struct _cklf_symtab));
      if (rc < 0)  return rc;
      lds = lds->next;
   }

   /* write the string tables */
   rc = write (fd, (void*)str, strtab_len);
   if (rc < 0)  return rc;
   
   rc = close (fd);
   return rc;
}


/**
 * \brief load a CKLF file
 * \param fd_err a file discriptor index to an open file for error output
 * \param fname the file to be loaded
 * \param mem the memory of the virtual machine
 * \param memsz the size of the virtual machine memory
 * \param start the start of the program, i.e. function main() (output)
 * \return allocated memory on success, otherwise 0
 *****************************************************************************/

int
CKLF_Load (int fd_err, char* fname, char* mem, int memsz, int* start) {
   int lds_len;
// int strtab_len;
   int k;
   struct _cklf_hdr hdr;
   struct _cklf_symtab* sym;
   int rc;
   int fd;
   int data;
   int code;
   int loaded;
   int prog;
   char *str;
   char *h;

   fd = open (fname, O_RDONLY, 0);
   if (fd < 0) {
      put_two_string_nl (fd_err, "Can not open file: ", fname);
      return 0;
   }

   rc = read (fd, (void*)&hdr, sizeof (struct _cklf_hdr));
   if (fd < 0) {
      put_two_string_nl (fd_err, "Can not read from file: ", fname);
      return 0;
   }

   if (strcmp (hdr.ident, CKLF_MAG) != 0) {
      put_two_string_nl (fd_err, "File is no VM executable: ", fname);
      return 0;
   }

   code = 0;
   data = code + hdr.data - hdr.prog;
   data = data + 256 - data % 256;
   loaded = data + hdr.symtab - hdr.data;
   loaded = loaded + 256 - loaded % 256;

   if (memsz < loaded) {
      put_string (fd_err, "Virtual Machine memory is too small to load program from file.\n");
      return 0;
   }

   /* load code segment from file */
   rc = read (fd, (void*)&mem[code], hdr.data - hdr.prog);
   if (rc != hdr.data - hdr.prog) {
      put_string (fd_err, "Can not read code, because file is too small.\n");
      return 0;
   }
   
   /* load data segment from file */
   rc = read (fd, (void*)&mem[data], hdr.symtab - hdr.data);
   if (rc != hdr.symtab - hdr.data) {
      put_string (fd_err, "Can not read data, because file is too small.\n");
      return 0;
   }

   /* load the symbol table from file */
   sym = (struct _cklf_symtab*) malloc (hdr.strtab - hdr.symtab);
   rc = read (fd, (void*)sym, hdr.strtab - hdr.symtab);
   if (rc != hdr.strtab - hdr.symtab) {
      put_string (fd_err, "Can not read symbol table, because file is too small.\n");
      return 0;
   }

   /* load the string table from file */
   str = (char*) malloc (hdr.total_sz - hdr.strtab);
   rc = read (fd, (void*)str, hdr.total_sz - hdr.strtab);
   if (rc != hdr.total_sz - hdr.strtab) {
      put_string (fd_err, "Can not read string table, because file is too small.\n");
      return 0;
   }

   lds_len = (hdr.strtab - hdr.symtab) / sizeof (struct _cklf_symtab);

   /* do the fixup of the local symbols */
   k = 0;
   prog = 0;
   while (k < lds_len) {
      if (sym[k].type == STT_OBJECT)
         Ld_Fix_Link_Long (mem, sym[k].addr + data, sym[k].offs, code);
      else
      if (sym[k].type == STT_FUNC) {
         Ld_Fix_Link_Long (mem, sym[k].addr + code, sym[k].offs, code);
         h = &str[sym[k].name];
         if (!strcmp (&str[sym[k].name], "main")) {
            *start = sym[k].addr + code;
            prog = 1;
         }
      } else
      if (sym[k].type == STT_NOTYPE) {
         put_two_string_nl (fd_err, "Can not (yet) solve links to external symbols for: ",
                            &str[sym[k].name]);
      }
      k = k + 1;
   }

   if (!prog) {
      put_string (fd_err, "No function 'main' found, aborting.\n");
      return 0;
   }

   /* TODO: link with other modules */

   return loaded;
}


/**
 * \brief load the headers from cklf files and create a struct _ld_link_obj list
 * \param fd_err a file discriptor index to an open file for error output
 * \param nr the number of files to be linked
 * \param ifiles the names of the files to be linked
 * \returns the linked list on success, otherwise 0
 *****************************************************************************/

struct _ld_link_obj*
CKLF_Load_File_Info (int fd_err, int nr, char** ifiles) {
   int rc;
   int k;
   int fd;
   struct _cklf_hdr  hdr;
   struct _ld_link_obj* obj;
   struct _ld_link_obj* o;

   obj = (struct _ld_link_obj*)0;

   k = 0;
   while (k < nr) {
      fd = open (ifiles[k], O_RDONLY, 0);
      k = k + 1;

      if (fd <= 0) {
         put_two_string_nl (fd_err, "Can not open file: ", ifiles[k-1]);
         continue;
      }

      rc = read (fd, (void*)&hdr, sizeof (struct _cklf_hdr));
      close (fd);

      if (rc < 0) {
         put_two_string_nl (fd_err, "Can not read from file: ", ifiles[k-1]);
         continue;
      }

      if (rc != sizeof (struct _cklf_hdr) ) {
         put_two_string_nl (fd_err, "Can not read header, because file is too small: ", ifiles[k-1]);
         continue;
      }

      if (strcmp (hdr.ident, CKLF_MAG) != 0) {
         put_two_string_nl (fd_err, "File is no cklf object file: ", ifiles[k-1]);
         continue;
      }

      o = (struct _ld_link_obj*) malloc (sizeof (struct _ld_link_obj));
      o->next = obj;
      obj = o;
      o->data_len = hdr.symtab - hdr.data;
      o->data_offs = -1;
      o->code_len = hdr.data - hdr.prog;
      o->code_offs = -1;
      o->sym_len = (hdr.strtab - hdr.symtab) / sizeof (struct _cklf_symtab);
      o->str_len = hdr.total_sz - hdr.strtab;
      o->fname = ifiles[k-1];
   }

   return obj;
}


/**
 * \brief load code and data segments for linking
 * \param fd_err a file discriptor index to an open file for error output
 * \param m a pointer to the linking management sytucture
 * \returns != 0 on success, otherwise 0
 *****************************************************************************/

int
CKLF_Load_Files (int fd_err, struct _ld_link_mgmt* m) {
   int rc;
   int fd;
   int cs_offs;
   int ds_offs;
   char *h;
   struct _ld_link_obj* o;
   struct _cklf_hdr hdr;

   m->ds_len = 0;
   m->cs_len = 0;
   o = m->obj;
   while (o) {
      m->ds_len = m->ds_len + o->data_len;
      m->cs_len = m->cs_len + o->code_len;
      o = o->next;
   }
   m->ds = (char*) malloc (m->ds_len);
   m->cs = (char*) malloc (m->cs_len);

   rc = 1;
   o = m->obj;
   cs_offs = 0;
   ds_offs = 0;
   while (rc && o) {
      fd = open (o->fname, O_RDONLY, 0);
      rc = read (fd, (void*)&hdr, sizeof (struct _cklf_hdr));     

      /* load code segment from file */
      h = m->cs + cs_offs;
      rc = read (fd, (void*)h, o->code_len);
      if (rc != o->code_len) {
         put_two_string_nl (fd_err, "Can not read code, because file is too small: ", o->fname);
         rc = 0;
      }

      /* load data segment from file */
      h = m->ds + ds_offs;
      rc = read (fd, (void*)h, o->data_len);
      if (rc != o->data_len) {
         put_two_string_nl (fd_err, "Can not read data, because file is too small: ", o->fname);
         rc = 0;
      }

      /* load the symbol table from file */
      h = (char*) malloc (hdr.strtab - hdr.symtab);
      o->sym_tab = (struct _cklf_symtab*)h;
      rc = read (fd, (void*)h, hdr.strtab - hdr.symtab);
      if (rc != hdr.strtab - hdr.symtab) {
         put_two_string_nl (fd_err, "Can not read symbol table, because file is too small: ",
                            o->fname);
         rc = 0;
      }

      /* load the string table from file */
      h = (char*) malloc (o->str_len);
      o->str_tab = h;
      rc = read (fd, (void*)h, o->str_len);
      if (rc != o->str_len) {
         put_two_string_nl (fd_err, "Can not read string table, because file is too small: ",
                            o->fname);
         rc = 0;
      }

      o->code_offs = cs_offs;
      o->data_offs = ds_offs;
      cs_offs = cs_offs + o->code_len;
      ds_offs = ds_offs + o->data_len;

      close (fd);
      o = o->next;
   }

   return rc;
}


/**
 * \brief join a link chain with an existing link chain and correct the offsets
 * \param s the start address of the segment
 * \param old_chain the address of the old chain (points to already fixed links)
 * \param new_chain the address of the new chain (not corrected)
 * \param offs the offset of the corresponding new segment
 * \return corrected new chain address
 *****************************************************************************/

int
CKLF_Merge_Chains (char* s, int old_chain, int new_chain, int offs) {
   int l1;
   int l;

   if (!new_chain)  return old_chain;

   l = new_chain;
   while (l) {
      l1 = Ld_Read_Long (s, l+offs);
      if (l1)  Ld_Write_Long (s, l+offs, l1+offs);
      else     Ld_Write_Long (s, l+offs, old_chain);
      l = l1;
   }

   if (new_chain)  return new_chain + offs;
   return 0;
}


/**
 * \brief join the symbol tables of all loaded files
 * \param fd_err a file discriptor index to an open file for error output
 * \param m a pointer to the linking management sytucture
 * \returns the list of symbols on success, otherwise 0
 *****************************************************************************/

void
CKLF_Create_SymTab (int fd_err, struct _ld_link_mgmt* m) {
   struct _ld_link_obj* o;
   struct _ld_sym* sym;
   char* s;
   int k;
   int a;

   o = m->obj;
   while (o) {

      k = 0;
      while (k < o->sym_len) {
         s = &o->str_tab[o->sym_tab[k].name];
         if (!strcmp (s, ""))  sym = (struct _ld_sym*)0;
         else  sym = LdSym_Find (m->lds, s);
         if (!sym) {
            /* TODO: fixup chain */
            a = o->sym_tab[k].offs;
            if (a)  a = a + o->code_offs;

            if (o->sym_tab[k].type == STT_OBJECT)
               m->lds = LdSym_Create (s, o->sym_tab[k].addr + o->data_offs, a,
                                      o->sym_tab[k].type, o->sym_tab[k].bind, m->lds);
            else
               m->lds = LdSym_Create (s, o->sym_tab[k].addr + o->code_offs, a,
                                      o->sym_tab[k].type, o->sym_tab[k].bind, m->lds);

            m->lds->size = CKLF_Merge_Chains (m->cs, 0, o->sym_tab[k].offs,
                                                        o->code_offs);
         } else {
            /* TODO: Fixup & Merge new Chain.
                     have existing symbol -> Fixup & Merge new Chain, check duplicates
                     have external reference -> got symbol: replace in symtab
                     have external reference -> got external reference: nothing */
            if (sym->type != STT_NOTYPE && o->sym_tab[k].type != STT_NOTYPE) {
               put_string (fd_err, "Duplicate symbol '");
               put_string (fd_err, s);
               put_string (fd_err, "' found in file ");
               put_string (fd_err, o->fname);
               put_string (fd_err, " (ignored).\n");
            }

            if (sym->type == STT_NOTYPE && o->sym_tab[k].type != STT_NOTYPE) {
               sym->value = o->sym_tab[k].addr + o->code_offs;
               sym->type = o->sym_tab[k].type;
               sym->bind = o->sym_tab[k].bind;
            }
            sym->size = CKLF_Merge_Chains (m->cs, sym->size,
                                           o->sym_tab[k].offs, o->code_offs);
         }
         k = k + 1;
      }
      o = o->next;
   }
}


/**
 * \brief link a set of CKLF files
 * \param fd_err a file discriptor index to an open file for error output
 * \param verbose if != 0 this function will provide verbose output
 * \param ofile the file name of the linked file
 * \param nr the number of files to be linked
 * \param ifiles the names of the files to be linked
 * \returns != 0 on success, otherwise 0
 *****************************************************************************/

int
CKLF_Link (int fd_err, int verbose, char* ofile, int nr, char** ifiles) {
   struct _ld_link_mgmt* m;

   m = LdMgmt_Create();

   m->obj = CKLF_Load_File_Info (fd_err, nr, ifiles);
   if (!m->obj) {
      put_string (fd_err, "No files loaded.\n");
      LdMgmt_Destroy (m);
      return 0;
   }

   if ( !CKLF_Load_Files (fd_err, m) ) {
      LdMgmt_Destroy (m);
      return 0;
   }

   CKLF_Create_SymTab (fd_err, m);

#ifdef DEBUG
   if (verbose) {
      put_string (fd_err, "\nCKLF_Link(): Dump of code segment:\n");
      vm_dump_data (fd_err, m->cs, m->cs_len);
      put_string (fd_err, "\n");
      put_string (fd_err, "\nCKLF_Link(): Disassembly of code segment:\n");
      vm_disasm (fd_err, 2, m->cs, 0, m->cs_len);
      put_string (fd_err, "\nCKLF_Link(): Dump of data segment:\n");
      vm_dump_data (fd_err, m->ds, m->ds_len);
      put_string (fd_err, "\n");
      LdSym_Dump (m->lds, fd_err);
   }
#endif

   CKLF_Store (fd_err, ofile, m->ds, m->ds_len, m->cs, m->cs_len, m->lds);

   LdMgmt_Destroy (m);
   return 1;
}

