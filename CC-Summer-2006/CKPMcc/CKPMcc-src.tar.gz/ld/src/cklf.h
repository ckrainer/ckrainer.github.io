/**
 * \file cklf.h
 * \brief CKPM ck linking format definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef _CKPM_CKLF_H_
#define _CKPM_CKLF_H_

#define	CKLF_MAG	"\177CKLF  "
#define	CKLF_VERSION	1

#define	LD_MAX_IDENT	8		/*!< length of the magic number field */

/**
 * \struct _cklf_hdr
 * \brief the file header
 *****************************************************************************/

struct _cklf_hdr {
   char	ident[LD_MAX_IDENT];		/*!< magic number */
   int	version;			/*!< object file version */
   int  prog;				/*!< index to the program code section */
   int  data;				/*!< index to the data section */
   int  symtab;				/*!< index to the symbol table */
   int  strtab;				/*!< index to the string table */
   int	total_sz;			/*!< total size of the file */
};


#if 0
/* Values for section header types */
#define	sh_type_t	int
#define	SHT_UNUSED	0		/*!< section header table entry unused */
#define SHT_PROG	1		/*!< program code */
#define	SHT_DATA	2		/*!< initialized program data */
#define SHT_SYMTAB	3		/*!< symbol table */
#define SHT_STRTAB	4		/*!< string table */

/* Values for section header flags */
#define	sh_flags_t	int
#define	SHF_WRITE	1		/*!< writeable */
#define	SHF_EXEC	2		/*!< executable */
#define	SHF_STRINGS	4		/*!< contains null terminated strings */

/**
 * \struct _cklf_shdr
 * \brief a section header
 *****************************************************************************/

struct _cklf_shdr {
   int		name;			/*!< section name (string table index) */
   sh_type_t	type;			/*!< section type */
   sh_flags_t	flags;			/*!< section flags */
   int  	size;			/*!< section size in bytes */
   int 		link;			/*!< link to the next section */
};
#endif


#define st_type_t       int
#define STT_NOTYPE	0               /*!< symbol type is unspecified */
#define STT_OBJECT	1               /*!< symbol is a data object */
#define STT_FUNC	2               /*!< symbol is a code object */

#define st_bind_t       int             /*!< symbol binding */
#define STB_LOCAL	0               /*!< local symbol */
#define STB_GLOBAL	1               /*!< global symbol */

/**
 * \struct _cklf_symtab
 * \brief a symbol table entry
 *****************************************************************************/

struct _cklf_symtab {
   int		name;			/*! symbol name (string table index) */
   int		addr;			/*!< symbol address (offset) */
   int		offs;			/*!< symbol offset for link fixup */
   st_type_t	type;			/*!< symbol type */
   st_bind_t	bind;			/*!< symbol binding */
};


// char* CKLF_SH_TypeToStr (sh_type_t t);
// char* CKLF_SH_FlagsToStr (sh_flags_t f);
char* CKLF_ST_TypeToStr (st_type_t t);
char* CKLF_ST_BindToStr (st_bind_t b);

#endif
