/**
 * \file cklf.c
 * \brief CKPM ck linking format
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/


#include <stdlib.h>
#include <string.h>

#include "cpp_io.h"
#include "cpp_conv.h"
#include "cklf.h"


#if 0
/**
 * \brief convert a sh_type_t number to a string
 * \param t the sh_type_t number
 * \return the corresponding string
 *****************************************************************************/

char*
CKLF_SH_TypeToStr (sh_type_t t) {
   if (t == SHT_UNUSED)  return "unused";
   if (t == SHT_PROG)    return "program";
   if (t == SHT_DATA)    return "data";
   if (t == SHT_SYMTAB)  return "symbol table";
   if (t == SHT_STRTAB)  return "string table";
   return "unknown";
}


/**
 * \brief convert a ld_type_t number to a string
 * \param t the ld_type_t number
 * \return the corresponding string
 *****************************************************************************/
char*
CKLF_SH_FlagsToStr (sh_flags_t f) {
   if (f == SHF_WRITE)    return "write";
   if (f == SHF_EXEC)     return "exec";
   if (f == SHF_STRINGS)  return "strings";
   return "unknown";
}
#endif


/**
 * \brief convert a st_type_t number to a string
 * \param t the st_type_t number
 * \return the corresponding string
 *****************************************************************************/

char*
CKLF_ST_TypeToStr (st_type_t t) {
   if (t ==  STT_NOTYPE)  return "no type (0)";
   if (t ==  STT_OBJECT)  return "object";
   if (t ==  STT_FUNC)    return "function";
   return "unknown";
}


/**
 * \brief convert a st_bind_t number to a string
 * \param b the st_bind_t number
 * \return the corresponding string
 *****************************************************************************/

char*
CKLF_ST_BindToStr (st_bind_t b) {
   if (b == STB_LOCAL)  return "local";
   if (b == STB_GLOBAL) return "global";
   return "unknown";
}
