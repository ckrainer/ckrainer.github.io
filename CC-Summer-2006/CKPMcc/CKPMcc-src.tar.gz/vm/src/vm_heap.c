/**
 * \file vm_heap.c
 * \brief CKPM virtual machine heap implementation
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "vm_heap.h"


/**
 * \brief initialise the virtual machine heap management
 * \param m the virtual machine memory
 * \return a pointer to the heap management structure within the virtual machine memory
 *****************************************************************************/

void
Heap_Init (vm_mem_t* m) {
   m->heap = m->mem_max - sizeof(vm_heap_t);

   vm_heap_t* h = (vm_heap_t*) &(m->mem[m->heap]);
   h->free_list = m->heap - sizeof(vm_heap_entry_t);
   h->used_list = 0;
   h->n_free = 1;
   h->n_used = 0;

   vm_heap_entry_t* e = (vm_heap_entry_t*) &(m->mem[h->free_list]);
   e->next = 0;
   e->size = h->free_list - m->sp + VM_MIN_HEAP_STACK_DIST;
}


/**
 * \brief allocate memory on the heap with first fit algorithm
 * \param m the virtual machine memory
 * \param sz the size of bytes to be allocated 
 * \return a pointer to the newly allocated memory if successful, otherwise 0
 *****************************************************************************/

vm_addr_t
Heap_Allocate (vm_mem_t* m, vm_size_t sz) {
   vm_addr_t fl;
   vm_addr_t o;
   vm_heap_entry_t* f;
   vm_heap_entry_t* e;
   vm_heap_t* h = (vm_heap_t*) &(m->mem[m->heap]);
   if (sz % 4)  sz = sz + 4 - sz % 4;

   vm_addr_t a = h->free_list;
   o = a;
   while (a) {
      e = (vm_heap_entry_t*) &(m->mem[a]);
      if (e->size >= sz) {
         if (e->size >= sz + sizeof (vm_heap_entry_t) + 1) {
            fl = a - sizeof (vm_heap_entry_t) - sz;
            f = (vm_heap_entry_t*) &(m->mem[fl]);
            f->size = e->size - sz - sizeof (vm_heap_entry_t);
            f->next = e->next;
            h->free_list = fl;
            e->size = sz;
         } else {
            h->n_free = h->n_free - 1;
            if (o == a) {
               h->free_list = e->next;
            } else {
               f = (vm_heap_entry_t*) &(m->mem[o]);
               f->next = e->next;
            }
         }
         e->next = h->used_list;
         h->used_list = a;
         h->n_used = h->n_used + 1;
         return a - sz;
      }
      o = a;
      a = e->next;
   }

   return 0;
}


/**
 * \brief deallocate memory on the heap
 * \param m the virtual machine memory
 * \param a the address of the allocated memory as returned from Heap_Allocate().
 *****************************************************************************/

void
Heap_Deallocate (vm_mem_t* m, vm_addr_t a) {
   vm_addr_t ul;
   vm_addr_t oul;
   vm_heap_entry_t* u;
   vm_heap_entry_t* ou;
   vm_heap_t* h = (vm_heap_t*) &(m->mem[m->heap]);

   ul = h->used_list;
   oul = ul;
   while (ul) {
      u = (vm_heap_entry_t*) &(m->mem[ul]);

      if (ul - u->size == a) {
         if (oul == ul) {
            h->used_list = u->next;
         } else {
            ou = (vm_heap_entry_t*) &(m->mem[oul]);
            ou->next = u->next;
         }
         u->next = h->free_list;
         h->free_list = ul;
         h->n_free = h->n_free + 1;
         h->n_used = h->n_used - 1;
         break;
      }

      oul = ul;
      ul = u->next;
   }
}


/**
 * \brief cleanup the heap and merge free list entries
 * \param m the virtual machine memory
 *****************************************************************************/

void
Heap_Cleanup (vm_mem_t* m) {
#ifdef DEBUG
   fprintf (stderr, "Heap_Cleanup() not implemented.");
#endif
}


/**
 * \brief dump data to stderr
 * \param s the memory chunk to be dumped
 * \param ofs the offset in the memory chunk where to start with the dump
 * \param len the length of the chunk to be dumped
 *****************************************************************************/

void
Heap_Dump_Data (unsigned char* s, int ofs, int len) {
   int k, x;
   unsigned char buf[2];

   k = 0;
   while (k < len) {
      fprintf (stderr, "     %-9s 0x%08X:   ", k?"":"Memory:", k+ofs);
      x = 0;
      while (x < 16) {
         if (k+x < len) {
            fprintf (stderr, "%02X ", s[k+ofs+x]);
         } else
            fprintf (stderr, "   ");
         x = x + 1;
         if (x == 8)  fprintf (stderr, "  ");
      }
      fprintf (stderr, "  ");
      x = 0;
      while (x < 16) {
         buf[0] = ' '; buf[1] = '\0';
         if (k+x < len) { if (s[k+ofs+x] < 32)  buf[0] = '.';  else  buf[0] = s[k+ofs+x]; }
         fprintf (stderr, "%s", buf);
         x = x + 1;
         if (x == 8)  fprintf (stderr, " ");
      }
      k = k + 16;
      fprintf (stderr, "\n");
   }
}


/**
 * \brief dump the heap management structure to a file
 * \param m the virtual machine memory
 * \param verbose if != 0 this function will provide verbose output, i.e. dumps the heap memory
 *****************************************************************************/

void
Heap_Dump (vm_mem_t* m, int verbose) {
   vm_addr_t el;
   vm_heap_entry_t* e;
   vm_heap_t* h = (vm_heap_t*) &(m->mem[m->heap]);

   fprintf (stderr, "\nHeap_Dump(): free_list=0x%08X n_free=%d, used_list=0x%08X n_used=%d\n",
            h->free_list, h->n_free, h->used_list, h->n_used);

   el = h->used_list;
   while (el) {
      e = (vm_heap_entry_t*) &(m->mem[el]);
      fprintf (stderr, "Used:   header=0x%08X, next=0x%08X, address=0x%08X, size=%d\n",
               el, e->next, el - e->size, e->size);

      if (verbose > 4) {
/*
         for (a=0; a < e->size; a+=4) {
            if (!(a%32)) fprintf (stderr, "     %-9s 0x%08X   ", a?"":"Memory:", a + el - e->size);
            fprintf (stderr, " 0x%08X", *(int*)&m->mem[a + el - e->size]);
            if ((a%32) == 28) fprintf(stderr, "\n");
         }
         if (a && (a%32) ) fprintf(stderr, "\n");
*/
         Heap_Dump_Data (m->mem, el - e->size, e->size);
      }

      el = e->next;
   }

   el = h->free_list;
   while (el) {
      e = (vm_heap_entry_t*) &(m->mem[el]);
      fprintf (stderr, "Free:   header=0x%08X, next=0x%08X, address=0x%08X, size=%d\n",
               el, e->next, el - e->size, e->size);
      el = e->next;
   }
}

