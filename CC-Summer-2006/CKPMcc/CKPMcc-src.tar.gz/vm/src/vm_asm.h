/**
 * \file vm_asm.h
 * \brief CKPM virtual machine assembly / disassembly definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef _VM_ASM_H_
#define _VM_ASM_H_

#include "vm_instr.h"

/**
 * \brief instruction set entry
 * This structure forms one entry in the instruction set table \b instruction_set
 */
struct instr_set_entry {
   short	instruction;	/* instruction code */
   short	params;		/* number of immediate parameter bytes */
   char*	asm_code;	/* assembler code with format for printf */
   char*	comment;	/* commentars to the instruction */
};


/**
 * \brief virtual machine instruction set table
 * This variable contains the whole instruction set of the CKPMvm
 * virtual machine as a table of \ref instr_set_entry entries.
 */
static struct instr_set_entry instruction_set [256] = {
/* 0x00 */   {INSTR_PUSH_B,       1,   "push_b\t#0x%02x",   "push byte"},
/* 0x01 */   {INSTR_PUSH_S,       2,   "push_s\t#0x%04x",   "push short"},
/* 0x02 */   {INSTR_PUSH_I,       4,   "push_i\t#0x%08x",   "push integer"},
/* 0x03 */   {INSTR_PUSH_SP,      0,   "push_sp",           "push stack pointer"},
/* 0x04 */   {INSTR_PUSH_FP,      0,   "push_fp",           "push frame pointer"},
/* 0x05 */   {INSTR_INVLD,        0,   "invld_05",          "invalid opcode 0x05"},
/* 0x06 */   {INSTR_INVLD,        0,   "invld_06",          "invalid opcode 0x06"},
/* 0x07 */   {INSTR_INVLD,        0,   "invld_07",          "invalid opcode 0x07"},
/* 0x08 */   {INSTR_LD_B,         4,   "ld_b\t#0x%08x",     "load byte value"},
/* 0x09 */   {INSTR_LD_S,         4,   "ld_s\t#0x%08x",     "load short value"},
/* 0x0A */   {INSTR_LD_I,         4,   "ld_i\t#0x%08x",     "load integer value"},
/* 0x0B */   {INSTR_LD_L,         4,   "ld_l\t#0x%08x",     "load long value"},
/* 0x0C */   {INSTR_INVLD,        0,   "invld_0c",          "invalid opcode 0x0C"},
/* 0x0D */   {INSTR_LD_F,         4,   "ld_f\t#0x%08x",     "load float value"},
/* 0x0E */   {INSTR_LD_D,         4,   "ld_d\t#0x%08x",     "load double value"},
/* 0x0F */   {INSTR_INVLD,        0,   "invld_0f",          "invalid opcode 0x0F"},

/* 0x10 */   {INSTR_LD_B_FP,      2,   "ld_b\t#0x%04x,fp",  "load byte value indexed by FP"},
/* 0x11 */   {INSTR_LD_S_FP,      2,   "ld_s\t#0x%04x,fp",  "load short value indexed by FP"},
/* 0x12 */   {INSTR_LD_I_FP,      2,   "ld_i\t#0x%04x,fp",  "load integer value indexed by FP"},
/* 0x13 */   {INSTR_LD_L_FP,      2,   "ld_l\t#0x%04x,fp",  "load long value indexed by FP"},
/* 0x14 */   {INSTR_INVLD,        0,   "invld_14",          "invalid opcode 0x14"},
/* 0x15 */   {INSTR_LD_F_FP,      2,   "ld_f\t#0x%04x,fp",  "load float value indexed by FP"},
/* 0x16 */   {INSTR_LD_D_FP,      2,   "ld_d\t#0x%04x,fp",  "load double value indexed by FP"},
/* 0x17 */   {INSTR_INVLD,        0,   "invld_17",          "invalid opcode 0x17"},
/* 0x18 */   {INSTR_LD_B_IND,     4,   "ld_b\t(#0x%08x)",   "load byte indirect"},
/* 0x19 */   {INSTR_LD_S_IND,     4,   "ld_s\t(#0x%08x)",   "load short indirect"},
/* 0x1A */   {INSTR_LD_I_IND,     4,   "ld_i\t(#0x%08x)",   "load integer indirect"},
/* 0x1B */   {INSTR_LD_L_IND,     4,   "ld_l\t(#0x%08x)",   "load long indirect"},
/* 0x1C */   {INSTR_INVLD,        0,   "invld_1c",          "invalid opcode 0x1C"},
/* 0x1D */   {INSTR_LD_F_IND,     4,   "ld_f\t(#0x%08x)",   "load float indirect"},
/* 0x1E */   {INSTR_LD_D_IND,     4,   "ld_d\t(#0x%08x)",   "load double indirect"},
/* 0x1F */   {INSTR_INVLD,        0,   "invld_1f",          "invalid opcode 0x1F"},

/* 0x20 */   {INSTR_LD_B_SP,      0,   "ld_b_sp",           "load byte with address from stack"},
/* 0x21 */   {INSTR_LD_S_SP,      0,   "ld_s_sp",           "load short with address from stack"},
/* 0x22 */   {INSTR_LD_I_SP,      0,   "ld_i_sp",           "load integer with address from stack"},
/* 0x23 */   {INSTR_LD_L_SP,      0,   "ld_l_sp",           "load long with address from stack"},
/* 0x24 */   {INSTR_INVLD,        0,   "invld_24",          "invalid opcode 0x24"},
/* 0x25 */   {INSTR_LD_F_SP,      0,   "ld_f_sp",           "load float with address from stack"},
/* 0x26 */   {INSTR_LD_D_SP,      0,   "ld_d_sp",           "load double with address from stack"},
/* 0x27 */   {INSTR_INVLD,        0,   "invld_27",          "invalid opcode 0x27"},
/* 0x28 */   {INSTR_ST_B,         4,   "st_b\t#0x%08x",     "store byte value"},
/* 0x29 */   {INSTR_ST_S,         4,   "st_s\t#0x%08x",     "store short value"},
/* 0x2A */   {INSTR_ST_I,         4,   "st_i\t#0x%08x",     "store integer value"},
/* 0x2B */   {INSTR_ST_L,         4,   "st_l\t#0x%08x",     "store long value"},
/* 0x2C */   {INSTR_INVLD,        0,   "invld_2c",          "invalid opcode 0x2C"},
/* 0x2D */   {INSTR_ST_F,         4,   "st_f\t#0x%08x",     "store float value"},
/* 0x2E */   {INSTR_ST_D,         4,   "st_d\t#0x%08x",     "store double value"},
/* 0x2F */   {INSTR_INVLD,        0,   "invld_2f",          "invalid opcode 0x2F"},

/* 0x30 */   {INSTR_ST_B_FP,      2,   "st_b\t#0x%04x,fp",  "store byte value indexed by FP"},
/* 0x31 */   {INSTR_ST_S_FP,      2,   "st_s\t#0x%04x,fp",  "store short value indexed by FP"},
/* 0x32 */   {INSTR_ST_I_FP,      2,   "st_i\t#0x%04x,fp",  "store integer value indexed by FP"},
/* 0x33 */   {INSTR_ST_L_FP,      2,   "st_l\t#0x%04x,fp",  "store long value indexed by FP"},
/* 0x34 */   {INSTR_INVLD,        0,   "invld_34",          "invalid opcode 0x34"},
/* 0x35 */   {INSTR_ST_F_FP,      2,   "st_f\t#0x%04x,fp",  "store float value indexed by FP"},
/* 0x36 */   {INSTR_ST_D_FP,      2,   "st_d\t#0x%04x,fp",  "store double value indexed by FP"},
/* 0x37 */   {INSTR_INVLD,        0,   "invld_37",          "invalid opcode 0x37"},
/* 0x38 */   {INSTR_ST_B_IND,     4,   "st_b\t(#0x%08x)",   "store byte indirect"},
/* 0x39 */   {INSTR_ST_S_IND,     4,   "st_s\t(#0x%08x)",   "store short indirect"},
/* 0x3A */   {INSTR_ST_I_IND,     4,   "st_i\t(#0x%08x)",   "store integer indirect"},
/* 0x3B */   {INSTR_ST_L_IND,     4,   "st_l\t(#0x%08x)",   "store long indirect"},
/* 0x3C */   {INSTR_INVLD,        0,   "invld_3c",          "invalid opcode 0x3C"},
/* 0x3D */   {INSTR_ST_F_IND,     4,   "st_f\t(#0x%08x)",   "store float indirect"},
/* 0x3E */   {INSTR_ST_D_IND,     4,   "st_d\t(#0x%08x)",   "store double indirect"},
/* 0x3F */   {INSTR_INVLD,        0,   "invld_3f",          "invalid opcode 0x3F"},

/* 0x40 */   {INSTR_ST_B_SP,      0,   "st_b_sp",           "store byte with address from stack"},
/* 0x41 */   {INSTR_ST_S_SP,      0,   "st_s_sp",           "store short with address from stack"},
/* 0x42 */   {INSTR_ST_I_SP,      0,   "st_i_sp",           "store integer with address from stack"},
/* 0x43 */   {INSTR_ST_L_SP,      0,   "st_l_sp",           "store long with address from stack"},
/* 0x44 */   {INSTR_INVLD,        0,   "invld_44",          "invalid opcode 0x44"},
/* 0x45 */   {INSTR_ST_F_SP,      0,   "st_f_sp",           "store float with address from stack"},
/* 0x46 */   {INSTR_ST_D_SP,      0,   "st_d_sp",           "store double with address from stack"},
/* 0x47 */   {INSTR_INVLD,        0,   "invld_47",          "invalid opcode 0x47"},
/* 0x48 */   {INSTR_LDC_I_0,      0,   "ldc_i_0",           "load integer constant 0"},
/* 0x49 */   {INSTR_INVLD,        0,   "invld_49",          "invalid opcode 0x49"},
/* 0x4A */   {INSTR_ADD_I,        0,   "add_i",             "add integer"},
/* 0x4B */   {INSTR_ADD_L,        0,   "add_l",             "add long"},
/* 0x4C */   {INSTR_INVLD,        0,   "invld_4c",          "invalid opcode 0x4C"},
/* 0x4D */   {INSTR_ADD_F,        0,   "add_f",             "add float"},
/* 0x4E */   {INSTR_ADD_D,        0,   "add_d",             "add double"},
/* 0x4F */   {INSTR_INVLD,        0,   "invld_4f",          "invalid opcode 0x4F"},

/* 0x50 */   {INSTR_LDC_I_1,      0,   "ldc_i_1",           "load integer constant 1"},
/* 0x51 */   {INSTR_INVLD,        0,   "invld_51",          "invalid opcode 0x51"},
/* 0x52 */   {INSTR_SUB_I,        0,   "sub_i",             "subtract integer"},
/* 0x53 */   {INSTR_SUB_L,        0,   "sub_l",             "subtract long"},
/* 0x54 */   {INSTR_INVLD,        0,   "invld_54",          "invalid opcode 0x54"},
/* 0x55 */   {INSTR_SUB_F,        0,   "sub_f",             "subtract float"},
/* 0x56 */   {INSTR_SUB_D,        0,   "sub_d",             "subtract double"},
/* 0x57 */   {INSTR_INVLD,        0,   "invld_57",          "invalid opcode 0x57"},
/* 0x58 */   {INSTR_LDC_I_M1,     0,   "ldc_i_m1",          "load integer constant -1"},
/* 0x59 */   {INSTR_INVLD,        0,   "invld_59",          "invalid opcode 0x59"},
/* 0x5A */   {INSTR_MUL_I,        0,   "mul_i",             "multiply integer"},
/* 0x5B */   {INSTR_MUL_L,        0,   "mul_l",             "multiply long"},
/* 0x5C */   {INSTR_INVLD,        0,   "invld_5c",          "invalid opcode 0x5C"},
/* 0x5D */   {INSTR_MUL_F,        0,   "mul_f",             "multiply float"},
/* 0x5E */   {INSTR_MUL_D,        0,   "mul_d",             "multiply double"},
/* 0x5F */   {INSTR_INVLD,        0,   "invld_5f",          "invalid opcode 0x5F"},

/* 0x60 */   {INSTR_LDC_L_0,      0,   "ldc_l_0",           "load long constant 0"},
/* 0x61 */   {INSTR_INVLD,        0,   "invld_61",          "invalid opcode 0x61"},
/* 0x62 */   {INSTR_DIV_I,        0,   "div_i",             "divide integer"},
/* 0x63 */   {INSTR_DIV_L,        0,   "div_l",             "divide long"},
/* 0x64 */   {INSTR_INVLD,        0,   "invld_64",          "invalid opcode 0x64"},
/* 0x65 */   {INSTR_DIV_F,        0,   "div_f",             "divide float"},
/* 0x66 */   {INSTR_DIV_D,        0,   "div_d",             "divide double"},
/* 0x67 */   {INSTR_INVLD,        0,   "invld_67",          "invalid opcode 0x67"},
/* 0x68 */   {INSTR_LDC_L_1,      0,   "ldc_l_1",           "load long constant 1"},
/* 0x69 */   {INSTR_INVLD,        0,   "invld_69",          "invalid opcode 0x69"},
/* 0x6A */   {INSTR_REM_I,        0,   "rem_i",             "remainder of integer division"},
/* 0x6B */   {INSTR_REM_L,        0,   "rem_l",             "remainder of long division"},
/* 0x6C */   {INSTR_INVLD,        0,   "invld_6c",          "invalid opcode 0x6C"},
/* 0x6D */   {INSTR_REM_F,        0,   "rem_f",             "remainder of float division"},
/* 0x6E */   {INSTR_REM_D,        0,   "rem_d",             "remainder of double division"},
/* 0x6F */   {INSTR_INVLD,        0,   "invld_6f",          "invalid opcode 0x6F"},

/* 0x70 */   {INSTR_LDC_L_M1,     0,   "ldc_l_m1",          "load long constant -1"},
/* 0x71 */   {INSTR_INVLD,        0,   "invld_71",          "invalid opcode 0x71"},
/* 0x72 */   {INSTR_NEG_I,        0,   "neg_i",             "negate integer"},
/* 0x73 */   {INSTR_NEG_L,        0,   "neg_l",             "negate long"},
/* 0x74 */   {INSTR_INVLD,        0,   "invld_74",          "invalid opcode 0x74"},
/* 0x75 */   {INSTR_NEG_F,        0,   "neg_f",             "negate float"},
/* 0x76 */   {INSTR_NEG_D,        0,   "neg_d",             "negate double"},
/* 0x77 */   {INSTR_INVLD,        0,   "invld_77",          "invalid opcode 0x77"},
/* 0x78 */   {INSTR_LDC_F_0,      0,   "ldc_f_0",           "load float constant 0"},
/* 0x79 */   {INSTR_INVLD,        0,   "invld_79",          "invalid opcode 0x79"},
/* 0x7A */   {INSTR_SHL_I,        0,   "shl_i",             "integer shift left"},
/* 0x7B */   {INSTR_SHL_L,        0,   "shl_l",             "long shift left"},
/* 0x7C */   {INSTR_INVLD,        0,   "invld_7c",          "invalid opcode 0x7C"},
/* 0x7D */   {INSTR_INVLD,        0,   "invld_7d",          "invalid opcode 0x7D"},
/* 0x7E */   {INSTR_INVLD,        0,   "invld_7e",          "invalid opcode 0x7E"},
/* 0x7F */   {INSTR_INVLD,        0,   "invld_7f",          "invalid opcode 0x7F"},

/* 0x80 */   {INSTR_LDC_F_1,      0,   "ldc_f_1",           "load float constant 1"},
/* 0x81 */   {INSTR_INVLD,        0,   "invld_81",          "invalid opcode 0x81"},
/* 0x82 */   {INSTR_SHR_I,        0,   "shr_i",             "integer shift right"},
/* 0x83 */   {INSTR_SHR_L,        0,   "shr_l",             "long shift right"},
/* 0x84 */   {INSTR_INVLD,        0,   "invld_84",          "invalid opcode 0x84"},
/* 0x85 */   {INSTR_INVLD,        0,   "invld_85",          "invalid opcode 0x85"},
/* 0x86 */   {INSTR_INVLD,        0,   "invld_86",          "invalid opcode 0x86"},
/* 0x87 */   {INSTR_INVLD,        0,   "invld_87",          "invalid opcode 0x87"},
/* 0x88 */   {INSTR_LDC_F_M1,     0,   "ldc_f_m1",          "load float constant -1"},
/* 0x89 */   {INSTR_INVLD,        0,   "invld_89",          "invalid opcode 0x89"},
/* 0x8A */   {INSTR_AND_I,        0,   "and_i",             "integer bitwise and"},
/* 0x8B */   {INSTR_AND_L,        0,   "and_l",             "long bitwise and"},
/* 0x8C */   {INSTR_INVLD,        0,   "invld_8c",          "invalid opcode 0x8C"},
/* 0x8D */   {INSTR_INVLD,        0,   "invld_8d",          "invalid opcode 0x8D"},
/* 0x8E */   {INSTR_INVLD,        0,   "invld_8e",          "invalid opcode 0x8E"},
/* 0x8F */   {INSTR_INVLD,        0,   "invld_8f",          "invalid opcode 0x8F"},

/* 0x90 */   {INSTR_LDC_D_0,      0,   "ldc_d_0",           "load double constant 0"},
/* 0x91 */   {INSTR_INVLD,        0,   "invld_91",          "invalid opcode 0x91"},
/* 0x92 */   {INSTR_OR_I,         0,   "or_i",              "integer bitwise or"},
/* 0x93 */   {INSTR_OR_L,         0,   "or_l",              "long bitwise or"},
/* 0x94 */   {INSTR_INVLD,        0,   "invld_94",          "invalid opcode 0x94"},
/* 0x95 */   {INSTR_INVLD,        0,   "invld_95",          "invalid opcode 0x95"},
/* 0x96 */   {INSTR_INVLD,        0,   "invld_96",          "invalid opcode 0x96"},
/* 0x97 */   {INSTR_INVLD,        0,   "invld_97",          "invalid opcode 0x97"},
/* 0x98 */   {INSTR_LDC_D_1,      0,   "ldc_d_1",           "load double constant 1"},
/* 0x99 */   {INSTR_INVLD,        0,   "invld_99",          "invalid opcode 0x99"},
/* 0x9A */   {INSTR_XOR_I,        0,   "xor_i",             "integer bitwise xor"},
/* 0x9B */   {INSTR_XOR_L,        0,   "xor_l",             "long bitwise xor"},
/* 0x9C */   {INSTR_INVLD,        0,   "invld_9c",          "invalid opcode 0x9C"},
/* 0x9D */   {INSTR_INVLD,        0,   "invld_9d",          "invalid opcode 0x9D"},
/* 0x9E */   {INSTR_INVLD,        0,   "invld_9e",          "invalid opcode 0x9E"},
/* 0x9F */   {INSTR_INVLD,        0,   "invld_9f",          "invalid opcode 0x9F"},

/* 0xA0 */   {INSTR_LDC_D_M1,     0,   "ldc_d_m1",          "load double constant -1"},
/* 0xA1 */   {INSTR_INVLD,        0,   "invld_a1",          "invalid opcode 0xA1"},
/* 0xA2 */   {INSTR_CMP_I,        0,   "cmp_i",             "integer comparison"},
/* 0xA3 */   {INSTR_CMP_L,        0,   "cmp_l",             "long comparison"},
/* 0xA4 */   {INSTR_INVLD,        0,   "invld_a4",          "invalid opcode 0xA4"},
/* 0xA5 */   {INSTR_CMP_F,        0,   "cmp_f",             "float comparison"},
/* 0xA6 */   {INSTR_CMP_D,        0,   "cmp_d",             "double comparison"},
/* 0xA7 */   {INSTR_INVLD,        0,   "invld_a7",          "invalid opcode 0xA7"},
/* 0xA8 */   {INSTR_I2B,          0,   "i2b",               "integer to byte conversion"},
/* 0xA9 */   {INSTR_I2S,          0,   "i2s",               "integer to short conversion"},
/* 0xAA */   {INSTR_INVLD,        0,   "invld_aa",          "invalid opcode 0xAA"},
/* 0xAB */   {INSTR_I2L,          0,   "i2l",               "integer to long conversion"},
/* 0xAC */   {INSTR_I2F,          0,   "i2f",               "integer to float conversion"},
/* 0xAD */   {INSTR_I2D,          0,   "i2d",               "integer to double conversion"},
/* 0xAE */   {INSTR_INVLD,        0,   "invld_ae",          "invalid opcode 0xAE"},
/* 0xAF */   {INSTR_INVLD,        0,   "invld_af",          "invalid opcode 0xAF"},

/* 0xB0 */   {INSTR_INVLD,        0,   "invld_b0",          "invalid opcode 0xB0"},
/* 0xB1 */   {INSTR_INVLD,        0,   "invld_b1",          "invalid opcode 0xB1"},
/* 0xB2 */   {INSTR_L2I,          0,   "l2i",               "long to integer conversion"},
/* 0xB3 */   {INSTR_INVLD,        0,   "invld_b3",          "invalid opcode 0xB3"},
/* 0xB4 */   {INSTR_INVLD,        0,   "invld_b4",          "invalid opcode 0xB4"},
/* 0xB5 */   {INSTR_L2F,          0,   "l2f",               "long to float conversion"},
/* 0xB6 */   {INSTR_L2D,          0,   "l2d",               "long to double conversion"},
/* 0xB7 */   {INSTR_INVLD,        0,   "invld_b7",          "invalid opcode 0xB7"},
/* 0xB8 */   {INSTR_INVLD,        0,   "invld_b8",          "invalid opcode 0xB8"},
/* 0xB9 */   {INSTR_INVLD,        0,   "invld_b9",          "invalid opcode 0xB9"},
/* 0xBA */   {INSTR_F2I,          0,   "f2i",               "float to integer conversion"},
/* 0xBB */   {INSTR_F2L,          0,   "f2l",               "float to long conversion"},
/* 0xBC */   {INSTR_INVLD,        0,   "invld_bc",          "invalid opcode 0xBC"},
/* 0xBD */   {INSTR_INVLD,        0,   "invld_bd",          "invalid opcode 0xBD"},
/* 0xBE */   {INSTR_F2D,          0,   "f2d",               "float to double conversion"},
/* 0xBF */   {INSTR_INVLD,        0,   "invld_bf",          "invalid opcode 0xBF"},

/* 0xC0 */   {INSTR_INVLD,        0,   "invld_c0",          "invalid opcode 0xC0"},
/* 0xC1 */   {INSTR_INVLD,        0,   "invld_c1",          "invalid opcode 0xC1"},
/* 0xC2 */   {INSTR_D2I,          0,   "d2i",               "double to integer conversion"},
/* 0xC3 */   {INSTR_D2L,          0,   "d2l",               "double to long conversion"},
/* 0xC4 */   {INSTR_INVLD,        0,   "invld_c4",          "invalid opcode 0xC4"},
/* 0xC5 */   {INSTR_D2F,          0,   "d2f",               "double to float conversion"},
/* 0xC6 */   {INSTR_INVLD,        0,   "invld_c6",          "invalid opcode 0xC6"},
/* 0xC7 */   {INSTR_INVLD,        0,   "invld_c7",          "invalid opcode 0xC7"},
/* 0xC8 */   {INSTR_INVLD,        0,   "invld_c8",          "invalid opcode 0xC8"},
/* 0xC9 */   {INSTR_INVLD,        0,   "invld_c9",          "invalid opcode 0xC9"},
/* 0xCA */   {INSTR_RET_I,        0,   "ret_i",             "return integer"},
/* 0xCB */   {INSTR_RET_L,        0,   "ret_l",             "return long"},
/* 0xCC */   {INSTR_INVLD,        0,   "invld_cc",          "invalid opcode 0xCC"},
/* 0xCD */   {INSTR_RET_F,        0,   "ret_f",             "return float"},
/* 0xCE */   {INSTR_RET_D,        0,   "ret_d",             "return double"},
/* 0xCF */   {INSTR_INVLD,        0,   "invld_cf",          "invalid opcode 0xCF"},

/* 0xD0 */   {INSTR_POP,          0,   "pop",               "pop word"},
/* 0xD1 */   {INSTR_POP2,         0,   "pop2",              "pop double word"},
/* 0xD2 */   {INSTR_DUP,          0,   "dup",               "duplicate word"},
/* 0xD3 */   {INSTR_DUP2,         0,   "dup2",              "duplicate double word"},
/* 0xD4 */   {INSTR_INVLD,        0,   "invld_d4",          "invalid opcode 0xD4"},
/* 0xD5 */   {INSTR_INVLD,        0,   "invld_d5",          "invalid opcode 0xD5"},
/* 0xD6 */   {INSTR_INVLD,        0,   "invld_d6",          "invalid opcode 0xD6"},
/* 0xD7 */   {INSTR_INVLD,        0,   "invld_d7",          "invalid opcode 0xD7"},
/* 0xD8 */   {INSTR_INVLD,        0,   "invld_d8",          "invalid opcode 0xD8"},
/* 0xD9 */   {INSTR_INVLD,        0,   "invld_d9",          "invalid opcode 0xD9"},
/* 0xDA */   {INSTR_SWAP,         0,   "swap",              "swap words"},
/* 0xDB */   {INSTR_SWAP2,        0,   "swap2",             "swap double words"},
/* 0xDC */   {INSTR_INVLD,        0,   "invld_dc",          "invalid opcode 0xDC"},
/* 0xDD */   {INSTR_INVLD,        0,   "invld_dd",          "invalid opcode 0xDD"},
/* 0xDE */   {INSTR_INVLD,        0,   "invld_de",          "invalid opcode 0xDE"},
/* 0xDF */   {INSTR_INVLD,        0,   "invld_df",          "invalid opcode 0xDF"},

/* 0xE0 */   {INSTR_INVLD,        0,   "invld_e0",          "invalid opcode 0xE0"},
/* 0xE1 */   {INSTR_DEC_FP,       2,   "dec_fp\t#0x%04x",   "decrement frame pointer"},
/* 0xE2 */   {INSTR_INC_SP,       2,   "inc_sp\t#0x%04x",   "increment stack pointer"},
/* 0xE3 */   {INSTR_DEC_SP,       2,   "dec_sp\t#0x%04x",   "decrement stack pointer"},
/* 0xE4 */   {INSTR_INVLD,        0,   "invld_e4",          "invalid opcode 0xE4"},
/* 0xE5 */   {INSTR_READ,         0,   "read",              "read"},
/* 0xE6 */   {INSTR_WRITE,        0,   "write",             "write"},
/* 0xE7 */   {INSTR_INVLD,        0,   "invld_e7",          "invalid opcode 0xE7"},
/* 0xE8 */   {INSTR_INVLD,        0,   "invld_e8",          "invalid opcode 0xE8"},
/* 0xE9 */   {INSTR_INVLD,        0,   "invld_e9",          "invalid opcode 0xE9"},
/* 0xEA */   {INSTR_INC_I,        4,   "inc_i\t#0x%08x",    "increment integer"},
/* 0xEB */   {INSTR_INC_L,        4,   "inc_l\t#0x%08x",    "increment long"},
/* 0xEC */   {INSTR_INVLD,        0,   "invld_ec",          "invalid opcode 0xEC"},
/* 0xED */   {INSTR_INVLD,        0,   "invld_ed",          "invalid opcode 0xED"},
/* 0xEE */   {INSTR_INVLD,        0,   "invld_ee",          "invalid opcode 0xEE"},
/* 0xEF */   {INSTR_INVLD,        0,   "invld_ef",          "invalid opcode 0xEF"},

/* 0xF0 */   {INSTR_RET,          0,   "ret",               "return from subroutine"},
/* 0xF1 */   {INSTR_JMP,          4,   "jmp\t#0x%08x",      "unconditional jump"},
/* 0xF2 */   {INSTR_JSR,          4,   "jsr\t#0x%08x",      "jump to subroutine"},
/* 0xF3 */   {INSTR_FOPEN,        0,   "fopen",             "file open"},
/* 0xF4 */   {INSTR_FCLOSE,       0,   "fclose",            "file close"},
/* 0xF5 */   {INSTR_GETC,         0,   "getc",              "get one character"},
/* 0xF6 */   {INSTR_PUTC,         0,   "putc",              "put one character"},
/* 0xF7 */   {INSTR_HALT,         0,   "halt",              "halt the virtual machine"},
/* 0xF8 */   {INSTR_BEQ,          2,   "beq\t#0x%04x",      "branch on equal"},
/* 0xF9 */   {INSTR_BNE,          2,   "bne\t#0x%04x",      "branch on not equal"},
/* 0xFA */   {INSTR_BGE,          2,   "bge\t#0x%04x",      "branch on greater or equal"},
/* 0xFB */   {INSTR_BGT,          2,   "bgt\t#0x%04x",      "branch on greater than"},
/* 0xFC */   {INSTR_BLE,          2,   "ble\t#0x%04x",      "branch on less or equal"},
/* 0xFD */   {INSTR_BLT,          2,   "blt\t#0x%04x",      "branch on less than"},
/* 0xFE */   {INSTR_NEW,          0,   "new",               "allocate memory"},
/* 0xFF */   {INSTR_DEL,          0,   "del",               "free memory"}
};





#endif /* _VM_ASM_H_ */

