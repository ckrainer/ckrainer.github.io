/**
 * \file demo_2.h
 * \brief CKPM virtual machine demonstration program
 *
 * This demonstration program calculates the factorial of 5.
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef _DEMO_2_VM_H_
#define _DEMO_2_VM_H_

#include <fcntl.h>

#include "vm_instr.h"

/**
 * \brief virtual machine factorial demonstration program 
 *
 * This demonstration program calculates the factorial of 5.
 */

/**
 * \brief Assembly code of the factorial demonstration program
 *
 * <pre>
 *		start:
 * 0x00000000		push_b	#0x05		; parameter for fact(n): n=5
 * 0x00000002		jsr	fact		; call subroutine fact(n)
 * 0x00000007		halt			; stop processing
 *		fact:
 * 0x00000008		dec_fp	#0x0004		; we got one parameter, adjust fp
 * 0x0000000B		ld_i	#0x0000,fp	; load first parameter
 * 0x0000000E		ldc_i_1			; load constant 1 ontop or the stack
 * 0x0000000F		cmp_i			; compare integer: n == 1
 * 0x00000010		bne	fact_rec	; branch if n != 1
 * 0x00000013		ld_i	#0x0000,fp	; load first parameter
 * 0x00000016		ret_i			; return calculated integer value
 *		fact_rec:
 * 0x00000017		ld_i	#0x0000,fp	; load first parameter
 * 0x0000001A		ldc_i_1			; load constant 1 ontop or the stack
 * 0x0000001B		sub_i			; substract integer: n-1
 * 0x0000001C		jsr	fact		; call subroutine fact(n-1)
 * 0x00000021		ld_i	#0x0000,fp	; load first parameter
 * 0x00000024		mul_i			; multiply result with first parameter
 * 0x00000025		ret_i			; return calculated integer value
 *
 * </pre>
 */

#define VM_DEMO_2_TEXT_ADDR	0x00000000	/*!< load address for the instruction codes */

static unsigned char vm_demo_2_text [] = {	/*!< variable containing the demo program instructions area */
   INSTR_PUSH_B,  0x05,				/*   parameter for fact(n): n=5 */
   INSTR_JSR,     0x00, 0x00, 0x00, 0x08,	/*   call subroutine fact(n) */
   INSTR_HALT,					/*   stop processing */
						/*fact: */
   INSTR_DEC_FP,  0x00, 0x04,			/*   we got one parameter, adjust fp */
   INSTR_LD_I_FP, 0x00, 0x00,			/*   load first parameter */
   INSTR_LDC_I_1,				/*   load constant 1 ontop or the stack */
   INSTR_CMP_I,					/*   compare integer: n == 1 */
   INSTR_BNE,     0x00, 0x04,            	/*   branch if n != 1 */
   INSTR_LD_I_FP, 0x00, 0x00,			/*   load first parameter */
   INSTR_RET_I,					/*   return calculated integer value */
						/*fact_rec: */
   INSTR_LD_I_FP, 0x00, 0x00,			/*   load first parameter */
   INSTR_LDC_I_1,				/*   load constant 1 ontop or the stack */
   INSTR_SUB_I,					/*   substract integer: n-1 */
   INSTR_JSR,     0x00, 0x00, 0x00, 0x08,	/*   call subroutine fact(n-1) */
   INSTR_LD_I_FP, 0x00, 0x00,			/*   load first parameter */
   INSTR_MUL_I,					/* multiply result with first parameter */
   INSTR_RET_I,					/*   return calculated integer value */
};


/**
 * \brief data area of the demonstration program
 *
 */
#define VM_DEMO_2_DATA_ADDR	0x00001000	/*!< load address for the data area */

static unsigned char vm_demo_2_data [] = {	/*!< variable containing the demo program data area */
   '\0',
};


#define	VM_DEMO_2_STACK_ADDR	0x00001100	/*!< start of the stack area */

#endif /* _DEMO_2_VM_H_ */

