/**
 * \file vm_load.c
 * \brief CKPM virtual machine executable loader
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include "vm.h"
#include "vm_disasm.h"
#include "ld_object.h"

#ifdef VM_DEMO_PROGRAMS
#include "demo_1.h"
#include "demo_2.h"
#endif

#define	VM_START_ADDR	1			/* edit start address here */
#define	VM_START_LENGTH	6			/* length of starter code */

static unsigned char vm_call [] = {
   INSTR_JSR, 0x00, 0x00, 0x00, 0x00,		/* call main() */
   INSTR_HALT
};

#ifdef VM_DEMO_PROGRAMS
/**
 * \brief load the "Hello World." demo program to the virtual machine
 * \parm m he pointer to the VM memory
 * \param argc argument counter, contains the number of entries in argv
 * \param argv argument vector
 * \return the pointer to the VM memory on success, NULL otherwise
 *
 * This function loads the "Hello World." demo program to the virtual machine.
 * The aim of this demo is to test the basic functionality of the virtual machine.
 */

vm_mem_t*
load_demo_1 (vm_mem_t* m, int argc, char** argv) {
   vm_addr_t a;

   m->pc = 0;
   m->fp = 0;
   m->sp = 0;
   m->mem_max = 0;

   for (a=0; a < sizeof(vm_demo_1_text); a++) {
      m->mem[a+VM_DEMO_1_TEXT_ADDR] = vm_demo_1_text[a];
   }

   for (a=0; a < sizeof(vm_demo_1_data); a++) {
      m->mem[a+VM_DEMO_1_DATA_ADDR] = vm_demo_1_data[a];
   }
   m->pc = VM_DEMO_1_TEXT_ADDR;
   m->fp = VM_DEMO_1_STACK_ADDR;
   *(int*)&m->mem[m->fp] = argc;
   *(int*)&m->mem[m->fp+4] = (int)argv;
   m->sp = m->fp+4;

   return m;
}


/**
 * \brief load the factorial demo program to the virtual machine
 * \parm m he pointer to the VM memory
 * \param argc argument counter, contains the number of entries in argv
 * \param argv argument vector
 * \return the pointer to the VM memory on success, NULL otherwise
 *
 * This function loads the factoriy demo program to the virtual machine.
 * This demo aims at the recursive call of functions.
 */

vm_mem_t*
load_demo_2 (vm_mem_t* m, int argc, char** argv) {
   vm_addr_t a;

   m->pc = 0;
   m->fp = 0;
   m->sp = 0;
   m->mem_max = 0;

   for (a=0; a < sizeof(vm_demo_2_text); a++) {
      m->mem[a+VM_DEMO_2_TEXT_ADDR] = vm_demo_2_text[a];
   }

   for (a=0; a < sizeof(vm_demo_2_data); a++) {
      m->mem[a+VM_DEMO_2_DATA_ADDR] = vm_demo_2_data[a];
   }
   m->pc = VM_DEMO_2_TEXT_ADDR;
   m->fp = VM_DEMO_2_STACK_ADDR;
   *(int*)&m->mem[m->fp] = argc;
   *(int*)&m->mem[m->fp+4] = (int)argv;
   m->sp = m->fp+4;

   return m;
}
#endif


/**
 * \brief load a virtual machine executable
 * \param verbose if != 0 this function will provide verbose output
 * \param argc argument counter, contains the number of entries in argv
 * \param argv argument vector
 * \param file_name the file name of the VM executable to be loaded
 * \param mem_size the requested size in MB of the VM memory 
 * \return the pointer to the VM memory on success, NULL otherwise
 *
 * This function allocates the requested size of memory for the virtual
 * machine and loads a virtual machine executable into this memory.
 * Additionally, it initialises the virtual machine registers.
 *****************************************************************************/

vm_mem_t*
load_file (int verbose, int argc, char** argv, char* file_name, vm_size_t mem_size) {
   vm_mem_t* m = NULL;
   vm_size_t sz;
   int stack;
   int start;
   
   if (mem_size < VM_MEM_DEFAULT)  mem_size = VM_MEM_DEFAULT;
   if (mem_size > VM_MEM_MAX)      mem_size = VM_MEM_MAX;

   if (verbose)
      fprintf (stderr, "Try to allocate %d MB virtual machine memory.\n", mem_size);

   sz = mem_size * 1048576 + VM_MEM_T_SIZE;
   m = (vm_mem_t*) malloc (sz);
   m->mem_max = mem_size * 1048576;

   if (!m) {
      fprintf (stderr, "Can not allocate %d MB virtual machine memory.\n", mem_size);
      return NULL;
   }

   if (verbose > 1) {
      int k;
      for (k=0; k < argc; k++)
         fprintf (stderr, "argv[%d]='%s'\n", k, argv[k]);
   }

#ifdef VM_DEMO_PROGRAMS
   if (!strcmp (file_name, "demo1"))
      return load_demo_1 (m, argc, argv);

   if (!strcmp (file_name, "demo2"))
      return load_demo_2 (m, argc, argv);
#endif

   if (verbose)
      fprintf (stderr, "Loading file '%s'\n", file_name);

   stack = (vm_addr_t) CKLF_Load (STDERR_FILENO, file_name, (char*)(m->mem), sz, &start); 

   if (stack) {
      vm_addr_t vm_argv;
      int k = 0;
      int a,b,c,d;

      if (verbose > 1)
         fprintf (stderr, "Disassembly of loaded program:\n");

      vm_disasm (STDERR_FILENO, verbose, (char*)m->mem, 0, stack-256);

      /* copy argv into virtual machine memory */
      if (stack % 4)  stack += 4 - stack % 4;
      b = stack + 4*argc;
      for (a=0; a < argc; a++) {
         char *x = argv[a];
         *(int*)&m->mem[stack+4*a] = b;
         while ( (m->mem[b++] = *x++) ) continue;
      }
      vm_argv = (vm_addr_t) stack;
      stack = b;
      if (stack % 4)  stack += 4 - stack % 4;


      /* copy runtime environment and fill in the start addres of main() */
      while (k < VM_START_LENGTH) { m->mem[k+stack] = vm_call[k]; k++; }
      a = (start >> 24) & 0xFF;  m->mem[stack+VM_START_ADDR]   = (unsigned char)a;
      b = (start >> 16) & 0xFF;  m->mem[stack+VM_START_ADDR+1] = (unsigned char)b;
      c = (start >>  8) & 0xFF;  m->mem[stack+VM_START_ADDR+2] = (unsigned char)c;
      d = (start      ) & 0xFF;  m->mem[stack+VM_START_ADDR+3] = (unsigned char)d;
//    *(int*)&m->mem[stack+VM_START_ADDR] = start;
      m->pc = (vm_addr_t) stack;
      m->fp = (vm_addr_t) stack+VM_START_LENGTH;
      *(int*)&m->mem[m->fp] = argc;
      *(int*)&m->mem[m->fp+4] = vm_argv;
      m->sp = m->fp+4;

      if (verbose)
         fprintf (stderr, "stack=0x%08x start=0x%08x pc=0x%08x fp=0x%08x sp=0x%08x\n",
                  stack, start, m->pc, m->fp, m->sp);

      return m;
   }

   free (m);
   return NULL;
}

