/**
 * \file vm_heap.h
 * \brief CKPM virtual machine heap definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef _CKPM_VM_HEAP_H_
#define _CKPM_VM_HEAP_H_

#include "vm.h"

#define	VM_MIN_HEAP_STACK_DIST	256	/*!< minimal distance between heap and stack in bytes */


/**
 * \typedef vm_heap_entry_t
 * \brief head of an allocated / free memory chunk
 *****************************************************************************/

typedef struct _vm_heap_entry {
   vm_addr_t	next;			/*!< next entry in the list */
   vm_size_t	size;			/*!< size of the entry */
} vm_heap_entry_t;


/**
 * \typedef vm_heap_t
 * \brief the heap management information
 *****************************************************************************/

typedef struct _vm_heap {
   vm_addr_t free_list;			/*!< a pointer to the first free list entry */
   vm_addr_t used_list;			/*!< a pointer to the first used list entry */
   int n_free;				/*!< number of entries in the freelist */
   int n_used;				/*!< number of entries in the used list */
} vm_heap_t;


/*
 * forward declarations
 */

void Heap_Init (vm_mem_t* m);
vm_addr_t Heap_Allocate (vm_mem_t* m, vm_size_t sz);
void Heap_Deallocate (vm_mem_t* m, vm_addr_t a);
void Heap_Cleanup (vm_mem_t* m);
void Heap_Dump (vm_mem_t* m, int verbose);

#endif /* _CKPM_VM_HEAP_H_ */

