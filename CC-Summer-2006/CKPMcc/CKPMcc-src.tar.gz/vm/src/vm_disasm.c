/**
 * \file vm_disasm.c
 * \brief CKPM virtual machine disassembler
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include "vm.h"
#include "vm_asm.h"


/**
 * \brief this subroutine writes a disassembled instruction to stderr
 * \param fd a file descriptor index to an open file
 * \param e the pointer to the current instruction description
 * \param arg the argument value of the instruction
 * \param pc the actual program counter
 *****************************************************************************/

void
vm_dump_instruction (int fd, struct instr_set_entry* e, int arg, int pc)
{
   char buf[50];
   snprintf (buf, 50, "0x%08X:   ", pc);   write (fd, buf, strlen (buf));
   snprintf (buf, 50, e->asm_code, arg);   write (fd, buf, strlen (buf));
   snprintf (buf, 50, "\n");               write (fd, buf, strlen (buf));
}


/**
 * \brief load a virtual machine executable
 * \param fd a file descriptor index to an open file
 * \param verbose if != 0 this function will provide verbose output
 * \param m a pointer to the virtual machine memory
 * \param start the start address for disassembling
 * \param len the length of bytes to be disassembled
 *****************************************************************************/

void
vm_disasm (int fd, int verbose, unsigned char* m, int start, int len) {
   signed int arg_i;
   unsigned int instr;
   struct instr_set_entry* e;
   int save_pc, pc;
   unsigned char a,b,c,d;
   unsigned char* mem = (unsigned char*)m;

   if (verbose < 2)  return;

   pc = start;
   while (pc < start+len) {
      save_pc = pc;
      instr = mem[pc] & 0xFF;  pc = pc + 1;
      e = &(instruction_set[instr]);
      switch (e->params) {
         case 1:
            arg_i = mem[pc] & 0xFF;  pc = pc + 1;
            vm_dump_instruction (fd, e, arg_i, save_pc);
            break;
         case 2:
            a = mem[pc];  pc = pc + 1;
            b = mem[pc];  pc = pc + 1;
            arg_i = (((int)a << 8) & 0xFF00) | ((int)b & 0xFF);
            vm_dump_instruction (fd, e, arg_i & 0xFFFF, save_pc);
            break;
         case 4:
            a = mem[pc];  pc = pc + 1;
            b = mem[pc];  pc = pc + 1;
            c = mem[pc];  pc = pc + 1;
            d = mem[pc];  pc = pc + 1;
            arg_i = (((int)a << 24) & 0xFF000000) |
                    (((int)b << 16) & 0xFF0000) |
                    (((int)c <<  8) & 0xFF00) |
                    ( (int)d  & 0xFF);
            vm_dump_instruction (fd, e, arg_i, save_pc);
            break;
         default:
            vm_dump_instruction (fd, e, 0, save_pc);
            break;
      }
   }

}


/**
 * \brief hexdump of data
 * \param fd a file descriptor index to an open file
 * \param s the pointer to the data area
 * \param len the length in bytes to be dumped
 *****************************************************************************/

void
vm_dump_data (int fd, char* s, int len) {
   int k, x;
   char buf[50];

   k = 0;
   while (k < len) {
      snprintf (buf, 50, "0x%08x:   ", k);  write (fd, buf, strlen(buf));
      x = 0;
      while (x < 16) {
         if (k+x < len) {
            snprintf (buf, 50, "%02x ", s[k+x] & 0xFF);
            write (fd, buf, strlen(buf));
         } else
            write (fd, "   ", 3);
         x = x + 1;
         if (x == 8)  write (fd, "  ", 2);
      }
      write (fd, "  ", 2);
      x = 0;
      while (x < 16) {
         buf[0] = ' '; buf[1] = '\0';
         if (k+x < len) { if (s[k+x] < 32)  buf[0] = '.';  else  buf[0] = s[k+x]; }
         write (fd, buf, strlen(buf));
         x = x + 1;
         if (x == 8)  write (fd, " ", 1);
      }
      k = k + 16;
      write (fd, "\n", 1);
   }
}

