/**
 * \file demo_1.h
 * \brief CKPM virtual machine demonstration program
 *
 * This demonstration program opens a file named "demo.out" and writes the
 * character string "Hello World.\n" into this file. Subsequently it closes
 * the file and stops the virtual machine.
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef _DEMO_1_VM_H_
#define _DEMO_1_VM_H_

#include <fcntl.h>

#include "vm_instr.h"

/**
 * \brief virtual machine demonstration program
 * This program opens a file named \b "demo.out" and writes the character
 * string "Hello World.\n" into this file.
 */

/**
 * \brief Assembly code of the demonstration program
 *
 * <pre>
 *		start:
 * 0x00000000		push_i	#0x00001000	; address of file name "demo.out"
 * 0x00000005		push_s	#0x0242		; O_CREAT | O_RDWR | O_TRUNC
 * 0x00000008		push_s	#0x01A4		; S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH
 * 0x0000000B		fopen			; open the file
 * 0x0000000C		st_i	#0x00002000	; store file descriptor
 * 0x00000011		push_i	#0x00001009	; address of string "Hello World"
 * 0x00000016		st_i	#0x00002004	; save address
 *		loop:
 * 0x0000001B		ld_b	(#0x00002004)	; read byte from string
 * 0x00000020		dup			; duplicate top stack word
 * 0x00000021		beq	end		; == 0 ? then jump to end of program
 * 0x00000024		ld_i	#0x00002000	; load file descriptor
 * 0x00000029		swap			; reorder first two words on stack
 * 0x0000002A		putc			; write character to file
 * 0x0000002B		pop			; ignore result
 * 0x0000002C		inc_i	#0x00002004	; increment pointer by 1
 * 0x00000031		jmp	loop		; jump back and write next character
 *		end:
 * 0x00000036		ld_i	#0x00002000	; load file descriptor
 * 0x0000003B           push_i  #0x00001009     ; address of string "Hello World"
 * 0x00000041           push_b  #0x0C           ; the lenght of the string "Hello World"
 * 0x00000043           write                   ; write it to the file
 * 0x00000044		ld_i	#0x00002000	; load file descriptor
 * 0x00000049		fclose			; close file
 * 0x00000050		ldc_i	#0		; set the return value of the virtual machine
 * 0x00000051		halt			; stop processing
 *
 * </pre>
 */

#define VM_DEMO_1_TEXT_ADDR	0x00000000	/*!< load address for the instruction codes */

static unsigned char vm_demo_1_text [] = {	/*!< variable containing the demo program instructions area */
						/*start: */
 INSTR_PUSH_I,    0x00, 0x00, 0x10, 0x00,	/*   address of file name "demo.out" */
 INSTR_PUSH_S,    0x02, 0x42,			/*   O_CREAT | O_RDWR | O_TRUNC */
 INSTR_PUSH_S,    0x01, 0xA4,			/*   S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH */
 INSTR_FOPEN,					/*   open the file */
 INSTR_ST_I,      0x00, 0x00, 0x20, 0x00,	/*   store file descriptor */
 INSTR_PUSH_I,    0x00, 0x00, 0x10, 0x09,	/*   address of string "Hello World" */
 INSTR_ST_I,      0x00, 0x00, 0x20, 0x04,	/*   save address */
						/*loop: */
 INSTR_LD_B_IND,  0x00, 0x00, 0x20, 0x04,	/*   read byte from string */
 INSTR_DUP,					/*   duplicate top stack word */
 INSTR_BEQ,       0x00, 0x12,			/*   == '\0' ? then jump to end of program */
 INSTR_LD_I,      0x00, 0x00, 0x20, 0x00,	/*   load file descriptor */
 INSTR_SWAP,					/*   reorder first two words on stack */
 INSTR_PUTC,					/*   write character to file */
 INSTR_POP,					/*   ignore result */
 INSTR_INC_I,     0x00, 0x00, 0x20, 0x04,	/*   increment pointer by 1 */
 INSTR_JMP,       0x00, 0x00, 0x00, 0x1B,	/*   jump back and write next character */
						/*end: */
 INSTR_LD_I,      0x00, 0x00, 0x20, 0x00,	/*   load file descriptor */
 INSTR_PUSH_I,    0x00, 0x00, 0x10, 0x09,	/*   address of string "Hello World" */
 INSTR_PUSH_B,    0x0E,                  	/*   the lenght of this string */
 INSTR_WRITE,                                   /*   write it to the file */
 INSTR_LD_I,      0x00, 0x00, 0x20, 0x00,	/*   load file descriptor */
 INSTR_FCLOSE,					/*   close file */
 INSTR_LDC_I_0,					/*   set the return value of the virtual machine */
 INSTR_HALT					/*   stop processing */
 
};


/**
 * \brief data area of the demonstration program
 *
 */
#define VM_DEMO_1_DATA_ADDR	0x00001000	/*!< load address for the data area */

static unsigned char vm_demo_1_data [] = {	/*!< variable containing the demo program data area */
   'd',  'e',  'm',  'o',  '.',  'o',  'u',  't',
   '\0', 'H',  'e',  'l',  'l',  'o',  ' ',  'W',
   'o',  'r',  'l',  'd',  '.',  '\n', '\0'
};


#define	VM_DEMO_1_STACK_ADDR	0x00001100	/*!< start of the stack area */

#endif /* _DEMO_1_VM_H_ */

