/**
 * \file vm_instr.h
 * \brief CKPM virtual machine instruction set
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef _VM_INSTR_H_
#define _VM_INSTR_H_

#define	INSTR_INVLD	-1	/* invalid instruction */

#define	INSTR_PUSH_B	0x00	/* push byte */
#define INSTR_PUSH_S	0x01	/* push short */
#define INSTR_PUSH_I	0x02	/* push integer */
#define	INSTR_PUSH_SP	0x03	/* push stack pointer */
#define	INSTR_PUSH_FP	0x04	/* push frame pointer */

#define INSTR_LD_B	0x08	/* load byte value */
#define INSTR_LD_S	0x09	/* load short value */
#define INSTR_LD_I	0x0A	/* load integer value */
#define INSTR_LD_L	0x0B	/* load long value */
#define INSTR_LD_F	0x0D	/* load float value */
#define INSTR_LD_D	0x0E	/* load double value */

#define INSTR_LD_B_FP	0x10	/* load byte value indexed by FP */
#define INSTR_LD_S_FP	0x11	/* load short value indexed by FP */
#define INSTR_LD_I_FP	0x12	/* load integer value indexed by FP */
#define INSTR_LD_L_FP	0x13	/* load long value indexed by FP */
#define INSTR_LD_F_FP	0x15	/* load float value indexed by FP */
#define INSTR_LD_D_FP	0x16	/* load double value indexed by FP */

#define	INSTR_LD_B_IND	0x18	/* load byte indirect */
#define	INSTR_LD_S_IND	0x19	/* load short indirect */
#define	INSTR_LD_I_IND	0x1A	/* load integer indirect */
#define	INSTR_LD_L_IND	0x1B	/* load long indirect */
#define	INSTR_LD_F_IND	0x1D	/* load float indirect */
#define	INSTR_LD_D_IND	0x1E	/* load double indirect */

#define	INSTR_LD_B_SP	0x20	/* load byte with address from stack */
#define	INSTR_LD_S_SP	0x21	/* load short with address from stack */
#define	INSTR_LD_I_SP	0x22	/* load integer with address from stack */
#define	INSTR_LD_L_SP	0x23	/* load long with address from stack */
#define	INSTR_LD_F_SP	0x25	/* load float with address from stack */
#define	INSTR_LD_D_SP	0x26	/* load double with address from stack */

#define INSTR_ST_B	0x28	/* store byte value */
#define INSTR_ST_S	0x29	/* store short value */
#define INSTR_ST_I	0x2A	/* store integer value */
#define INSTR_ST_L	0x2B	/* store long value */
#define INSTR_ST_F	0x2D	/* store float value */
#define INSTR_ST_D	0x2E	/* store double value */

#define INSTR_ST_B_FP	0x30	/* store byte value indexed by FP */
#define INSTR_ST_S_FP	0x31	/* store short value indexed by FP */
#define INSTR_ST_I_FP	0x32	/* store integer value indexed by FP */
#define INSTR_ST_L_FP	0x33	/* store long value indexed by FP */
#define INSTR_ST_F_FP	0x35	/* store float value indexed by FP */
#define INSTR_ST_D_FP	0x36	/* store double value indexed by FP */

#define	INSTR_ST_B_IND	0x38	/* store byte indirect */
#define	INSTR_ST_S_IND	0x39	/* store short indirect */
#define	INSTR_ST_I_IND	0x3A	/* store integer indirect */
#define	INSTR_ST_L_IND	0x3B	/* store long indirect */
#define	INSTR_ST_F_IND	0x3D	/* store float indirect */
#define	INSTR_ST_D_IND	0x3E	/* store double indirect */

#define	INSTR_ST_B_SP	0x40	/* store byte with address from stack */
#define	INSTR_ST_S_SP	0x41	/* store short with address from stack */
#define	INSTR_ST_I_SP	0x42	/* store integer with address from stack */
#define	INSTR_ST_L_SP	0x43	/* store long with address from stack */
#define	INSTR_ST_F_SP	0x45	/* store float with address from stack */
#define	INSTR_ST_D_SP	0x46	/* store double with address from stack */

#define INSTR_LDC_I_0	0x48	/* load integer constant 0 */
#define INSTR_LDC_I_1	0x50	/* load integer constant 1 */
#define INSTR_LDC_I_M1	0x58	/* load integer constant -1 */

#define INSTR_LDC_L_0	0x60	/* load long constant 0 */
#define INSTR_LDC_L_1	0x68	/* load long constant 1 */
#define INSTR_LDC_L_M1	0x70	/* load long constant -1 */

#define INSTR_LDC_F_0	0x78	/* load float constant 0 */
#define INSTR_LDC_F_1	0x80	/* load float constant 1 */
#define INSTR_LDC_F_M1	0x88	/* load float constant -1 */

#define INSTR_LDC_D_0	0x90	/* load double constant 0 */
#define INSTR_LDC_D_1	0x98	/* load double constant 1 */
#define INSTR_LDC_D_M1	0xa0	/* load double constant -1 */

#define INSTR_ADD_I	0x4a	/* add integer */
#define INSTR_ADD_L	0x4b	/* add long */
#define INSTR_ADD_F	0x4d	/* add float */
#define INSTR_ADD_D	0x4e	/* add double */

#define INSTR_SUB_I	0x52	/* subtract integer */
#define INSTR_SUB_L	0x53	/* subtract long */
#define INSTR_SUB_F	0x55	/* subtract float */
#define INSTR_SUB_D	0x56	/* subtract double */

#define INSTR_MUL_I	0x5a	/* multiply integer */
#define INSTR_MUL_L	0x5b	/* multiply long */
#define INSTR_MUL_F	0x5d	/* multiply float */
#define INSTR_MUL_D	0x5e	/* multiply double */

#define INSTR_DIV_I	0x62	/* divide integer */
#define INSTR_DIV_L	0x63	/* divide long */
#define INSTR_DIV_F	0x65	/* divide float */
#define INSTR_DIV_D	0x66	/* divide double */

#define INSTR_REM_I	0x6a	/* remainder of integer division */
#define INSTR_REM_L	0x6b	/* remainder of long division */
#define INSTR_REM_F	0x6d	/* remainder of float division */
#define INSTR_REM_D	0x6e	/* remainder of double division */

#define INSTR_NEG_I	0x72	/* negate integer */
#define INSTR_NEG_L	0x73	/* negate long */
#define INSTR_NEG_F	0x75	/* negate float */
#define INSTR_NEG_D	0x76	/* negate double */

#define INSTR_SHL_I	0x7a	/* integer shift left */
#define INSTR_SHL_L	0x7b	/* long shift left */

#define INSTR_SHR_I	0x82	/* integer shift right */
#define INSTR_SHR_L	0x83	/* long shift right */

#define INSTR_AND_I	0x8a	/* integer bitwise and */
#define INSTR_AND_L	0x8b	/* long bitwise and */

#define INSTR_OR_I	0x92	/* integer bitwise or */
#define INSTR_OR_L	0x93	/* long bitwise or */

#define INSTR_XOR_I	0x9a	/* integer bitwise xor */
#define INSTR_XOR_L	0x9b	/* long bitwise xor */

#define INSTR_CMP_I	0xa2	/* integer comparison */
#define INSTR_CMP_L	0xa3	/* long comparison */
#define INSTR_CMP_F	0xa5	/* float comparison */
#define INSTR_CMP_D	0xa6	/* double comparison */

#define INSTR_I2B	0xa8	/* integer to byte conversion */
#define INSTR_I2S	0xa9	/* integer to short conversion */
#define INSTR_I2L	0xab	/* integer to long conversion */
#define INSTR_I2F	0xac	/* integer to float conversion */
#define INSTR_I2D	0xad	/* integer to double conversion */

#define INSTR_L2I	0xb2	/* long to integer conversion */
#define INSTR_L2F	0xb5	/* long to float conversion */
#define INSTR_L2D	0xb6	/* long to double conversion */

#define INSTR_F2I	0xba	/* float to integer conversion */
#define INSTR_F2L	0xbb	/* float to long conversion */
#define INSTR_F2D	0xbe	/* float to double conversion */

#define INSTR_D2I	0xc2	/* double to integer conversion */
#define INSTR_D2L	0xc3	/* double to long conversion */
#define INSTR_D2F	0xc5	/* double to float conversion */

#define INSTR_RET_I	0xca	/* return integer */
#define INSTR_RET_L	0xcb	/* return long */
#define INSTR_RET_F	0xcd	/* return float */
#define INSTR_RET_D	0xce	/* return double */

#define INSTR_POP	0xd0	/* pop word */
#define INSTR_POP2	0xd1	/* pop double word */
#define INSTR_DUP	0xd2	/* duplicate word */
#define INSTR_DUP2	0xd3	/* duplicate double word */
#define INSTR_SWAP	0xda	/* swap words */
#define INSTR_SWAP2	0xdb	/* swap double words */

#define	INSTR_DEC_FP	0xe1	/* decrement frame pointer */
#define	INSTR_INC_SP	0xe2	/* increment stack pointer */
#define	INSTR_DEC_SP	0xe3	/* decrement stack pointer */
#define	INSTR_READ      0xe5    /* read from file */
#define	INSTR_WRITE     0xe6    /* write from file */
#define	INSTR_INC_I	0xea	/* increment integer */
#define	INSTR_INC_L	0xeb	/* increment long */

#define INSTR_RET	0xf0	/* return from subroutine */
#define INSTR_JMP	0xf1	/* unconditional jump */
#define INSTR_JSR	0xf2	/* jump to subroutine */
#define INSTR_FOPEN	0xf3	/* file open */
#define INSTR_FCLOSE	0xf4	/* file close */
#define INSTR_GETC	0xf5	/* get one character */
#define INSTR_PUTC	0xf6	/* put one character */
#define	INSTR_HALT	0xf7	/* halt the virtual machine */

#define INSTR_BEQ	0xf8	/* branch on equal */
#define INSTR_BNE	0xf9	/* branch on not equal */
#define INSTR_BGE	0xfa	/* branch on greater or equal */
#define INSTR_BGT	0xfb	/* branch on greater than */
#define INSTR_BLE	0xfc	/* branch on less or equal */
#define INSTR_BLT	0xfd	/* branch on less than */
#define INSTR_NEW	0xfe	/* allocate memory */
#define INSTR_DEL	0xff	/* free memory */


#endif /* _VM_INSTR_H_ */
