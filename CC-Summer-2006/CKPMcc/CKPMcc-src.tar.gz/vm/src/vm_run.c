/**
 * \file vm_run.c
 * \brief CKPM virtual machine execution unit
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>

#include "vm_instr.h"
#include "vm.h"
#include "vm_asm.h"
#include "vm_heap.h"


/**
 * \brief this subroutine writes an error message for not implemented instructions.
 * \param e the pointer to the current instruction description.
 *
 */
inline void
not_implemented (struct instr_set_entry* e) {
   fprintf (stderr, "            not implemented: %s\n", e->comment);
}


/**
 * \brief this subroutine dumps the current machine stack to stderr
 * \param verbose if > 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
dump_stack (int verbose, vm_mem_t* vm)
{
   vm_addr_t a;

   if (verbose < 4)  return;

   for (a=0; a <= vm->sp - vm->fp; a+=4) {
      if (!(a%32)) fprintf (stderr, "%-14s 0x%08X   ", a?"":"Stack Frame:", a+vm->fp);
      fprintf (stderr, " 0x%08X", *(int*)&vm->mem[a+vm->fp]);
      if ((a%32) == 28) fprintf(stderr, "\n");
   }
   if (a && (a%32) ) fprintf(stderr, "\n");
}


/**
 * \brief this subroutine dumps the current machine status to stderr
 * \param verbose if > 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
dump_status (int verbose, vm_mem_t* vm)
{
   if (verbose < 3)  return;

   fprintf (stderr, "            pc=0x%08X   fp=0x%08X   sp=0x%08X   (sp)=0x%08X\n",
      vm->pc, vm->fp, vm->sp, *(int*)&(vm->mem[vm->sp]) );

   dump_stack  (verbose, vm);
}


/**
 * \brief this subroutine writes a disassembled instruction to stderr
 * \param verbose if > 0 this function will provide verbose output
 * \param e the pointer to the current instruction description
 * \param arg the argument value of the instruction
 * \param pc the actual program counter
 *
 */
inline void
dump_instruction (int verbose, struct instr_set_entry* e, int arg, int pc)
{
   if (verbose < 2)  return;

   fprintf (stderr, "0x%08X:   ", pc);
   fprintf (stderr, e->asm_code, arg);
   fputs   ("\n", stderr);
}


/**
 * \brief implementation of FOPEN virual machine instruction
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
instr_fopen (int verbose, vm_mem_t* vm) {
   int m = *(int*)&vm->mem[vm->sp]; vm->sp-=4;
   int f = *(int*)&vm->mem[vm->sp]; vm->sp-=4;
   int s = *(int*)&vm->mem[vm->sp];
   *(int*)&(vm->mem[vm->sp]) = open ((char*)&(vm->mem[s]), f, m);
   if (verbose)
      fprintf (stderr, "opening file '%s' with flags 0x%04X, mode 0x%04X, fd=%d\n",
                       (char*)&(vm->mem[s]), f, m, *(int*)&(vm->mem[vm->sp]));
}


/**
 * \brief implementation of FCLOSE virual machine instruction
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
instr_fclose (int verbose, vm_mem_t* vm) {
   int fd = *(int*)&vm->mem[vm->sp];
   int r = close (fd);
   *(int*)&vm->mem[vm->sp] = r;
   if (verbose)
      fprintf (stderr, "closing file fd=%d, return code=%d\n", fd, r);
}


/**
 * \brief implementation of PUTC virual machine instruction
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
instr_putc (int verbose, vm_mem_t* vm) {
   char c = (char)*(int*)&vm->mem[vm->sp];  vm->sp-=4;
   int fd = *(int*)&vm->mem[vm->sp];
   int r = write (fd, &c, 1);
   if (verbose)
      fprintf (stderr, "write character 0x%02x ('%c'), fd=%d, written=%d\n",
               c, (c>31 && c<127)?c:'?', fd, r);
   *(int*)&vm->mem[vm->sp] = r;
}


/**
 * \brief implementation of GETC virual machine instruction
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
instr_getc (int verbose, vm_mem_t* vm) {
   char c = 0;
   int fd = *(int*)&vm->mem[vm->sp];
   int r = read (fd, &c, 1);
   *(int*)&vm->mem[vm->sp] = r ? c : -1;
   if (verbose)
      fprintf (stderr, "read character 0x%02x ('%c'), fd=%d, read=%d\n",
               c, (c>31 && c<127)?c:'?', fd, r);
}


/**
 * \brief implementation of READ virual machine instruction
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
instr_read (int verbose, vm_mem_t* vm) {
   char x[30];
   int fd = *(int*)&vm->mem[vm->sp-8];
   int buf = *(int*)&vm->mem[vm->sp-4];
   int sz = *(int*)&vm->mem[vm->sp];
   int r = read (fd, &vm->mem[buf], sz);
   vm->sp -= 8;
   *(int*)&vm->mem[vm->sp] = r;
   if (verbose) {
      strncpy (x, &vm->mem[buf], sz); x[sz<30?sz:29] = '\0';
      fprintf (stderr, "read string fd=%d, read=%d, address=0x%08X, length=%d string='%s'\n",
               fd, r, buf, sz, x);
   }
}


/**
 * \brief implementation of WRITE virual machine instruction
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
instr_write (int verbose, vm_mem_t* vm) {
   int fd = *(int*)&vm->mem[vm->sp-8];
   int buf = *(int*)&vm->mem[vm->sp-4];
   int sz = *(int*)&vm->mem[vm->sp];
   int r = write (fd, &vm->mem[buf], sz);
   vm->sp -= 8;
   *(int*)&vm->mem[vm->sp] = r;
   if (verbose)
      fprintf (stderr, "write string fd=%d, written=%d, address=0x%08X, length=%d string='%s'\n",
               fd, r, buf, sz, &vm->mem[buf]);
}


/**
 * \brief implementation of NEW virual machine instruction
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
instr_new (int verbose, vm_mem_t* vm) {
// *(int*)&vm->mem[vm->sp] = (int)malloc (*(int*)&vm->mem[vm->sp]);
   *(int*)&vm->mem[vm->sp] = Heap_Allocate (vm, *(int*)&vm->mem[vm->sp]);
   if (verbose > 3)  Heap_Dump (vm, verbose);
}


/**
 * \brief implementation of DEL virual machine instruction
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
instr_del (int verbose, vm_mem_t* vm) {
// free ((void*)*(int*)&vm->mem[vm->sp]);
   Heap_Deallocate (vm, *(int*)&vm->mem[vm->sp]);
   vm->sp-=4;
   if (verbose > 3)  Heap_Dump (vm, verbose);
}


/**
 * \brief implementation of RET_I virual machine instruction
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
instr_ret_i (int verbose, vm_mem_t* vm) {
   vm->pc = *(int*)&vm->mem[vm->sp-8];
   *(int*)&vm->mem[vm->fp] = *(int*)&vm->mem[vm->sp];
   vm_addr_t old_fp = vm->fp;
   vm->fp = *(int*)&vm->mem[vm->sp-4];
   vm->sp = old_fp;
}


/**
 * \brief implementation of RET_L virual machine instruction
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
instr_ret_l (int verbose, vm_mem_t* vm) {
}


/**
 * \brief implementation of RET_F virual machine instruction
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
instr_ret_f (int verbose, vm_mem_t* vm) {
   *(float*)&vm->mem[vm->fp] = *(float*)&vm->mem[vm->sp];
   vm->pc = *(int*)&vm->mem[vm->sp-4];
   vm_addr_t old_fp = vm->fp;
   vm->fp = *(int*)&vm->mem[vm->sp-8];
   vm->sp = old_fp;
}


/**
 * \brief implementation of RET_D virual machine instruction
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
instr_ret_d (int verbose, vm_mem_t* vm) {
}


/**
 * \brief implementation of RET virual machine instruction
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 *
 */
inline void
instr_ret (int verbose, vm_mem_t* vm) {
   vm->pc = *(int*)&vm->mem[vm->sp-4];
   vm_addr_t old_fp = vm->fp;
   vm->fp = *(int*)&vm->mem[vm->sp];
   vm->sp = old_fp-4;
}


/**
 * \brief implementation of JSR virual machine instruction
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 * \param dest the detination addres of the subroutine
 *
 */
inline void
instr_jsr (int verbose, vm_mem_t* vm, vm_addr_t dest) {
   vm_addr_t old_fp = vm->fp;
   vm_addr_t old_pc = vm->pc;
/* vm_addr_t old_sp = vm->sp; */

   vm->sp += 4;
   vm->fp = vm->sp;
   *(int*)&vm->mem[vm->sp] = old_pc;
   vm->sp += 4;
   *(int*)&vm->mem[vm->sp] = old_fp;
   vm->pc = dest;
}


/**
 * \brief run the loaded executable
 * \param verbose if != 0 this function will provide verbose output
 * \param vm the pointer to the virtual machine memory
 * \return 0 on success, 1 otherwise
 *
 * This function executes the instructions as provided in \b vm_memory.
 *****************************************************************************/

int
run_vm (int verbose, vm_mem_t* vm) {

   signed short arg_s;
   signed int arg_i;
   unsigned int instr;
   struct instr_set_entry* e;
   int run = 1;
   int save_pc;
   unsigned char a,b,c,d;
   int rc = 1;

   Heap_Init (vm);
   if (verbose > 3)  Heap_Dump (vm, verbose);

   if (verbose)
      fprintf (stderr, "Start address is 0x%08x.\n", vm->pc);

   while (run) {
      save_pc = vm->pc;

      instr = vm->mem[vm->pc++];
      e = &(instruction_set[instr]);
      switch (e->params) {
         case 1:
            arg_i = (signed char)vm->mem[vm->pc++];
            dump_instruction (verbose, e, arg_i, save_pc);
            break;
         case 2:
            a = vm->mem[vm->pc++];
            b = vm->mem[vm->pc++];
            arg_s = a << 8 | b;
            dump_instruction (verbose, e, arg_s & 0xFFFF, save_pc);
            break;
         case 4:
            a = vm->mem[vm->pc++];
            b = vm->mem[vm->pc++];
            c = vm->mem[vm->pc++];
            d = vm->mem[vm->pc++];
            arg_i = a << 24 | b << 16 | c << 8 | d;
            dump_instruction (verbose, e, arg_i, save_pc);
            break;
         default:
            dump_instruction (verbose, e, 0, save_pc);
            break;
      }

   
      switch (e->instruction) {
         case INSTR_PUSH_B:	vm->sp+=4; *(int*)   &vm->mem[vm->sp] = arg_i;    break;
         case INSTR_PUSH_S:	vm->sp+=4; *(int*)   &vm->mem[vm->sp] = arg_s;    break;
         case INSTR_PUSH_I:	vm->sp+=4; *(int*)   &vm->mem[vm->sp] = arg_i;    break;
         case INSTR_PUSH_SP:    vm->sp+=4; *(int*)   &vm->mem[vm->sp] = vm->sp-4; break;
         case INSTR_PUSH_FP:    vm->sp+=4; *(int*)   &vm->mem[vm->sp] = vm->fp;   break;

         case INSTR_LD_B_IND:	arg_i = *(int*) &vm->mem[arg_i];
         case INSTR_LD_B:	vm->sp+=4; *(int*)   &vm->mem[vm->sp] = *(char*)  &vm->mem[arg_i]; break;
         case INSTR_LD_S_IND:	arg_i = *(int*) &vm->mem[arg_i];
         case INSTR_LD_S:	vm->sp+=4; *(int*)   &vm->mem[vm->sp] = *(short*) &vm->mem[arg_i]; break;
         case INSTR_LD_I_IND:	arg_i = *(int*) &vm->mem[arg_i];
         case INSTR_LD_I:	vm->sp+=4; *(int*)   &vm->mem[vm->sp] = *(int*)   &vm->mem[arg_i]; break;
         case INSTR_LD_L_IND:	arg_i = *(int*) &vm->mem[arg_i];
         case INSTR_LD_L:	vm->sp+=4; *(long*)  &vm->mem[vm->sp] = *(long*)  &vm->mem[arg_i];
   				vm->sp+=4; break;
         case INSTR_LD_F_IND:	arg_i = *(int*) &vm->mem[arg_i];
         case INSTR_LD_F:	vm->sp+=4; *(float*) &vm->mem[vm->sp] = *(float*) &vm->mem[arg_i]; break;
         case INSTR_LD_D_IND:	arg_i = *(int*) &vm->mem[arg_i];
         case INSTR_LD_D:	vm->sp+=4; *(double*)&vm->mem[vm->sp] = *(double*)&vm->mem[arg_i];
   				vm->sp+=4; break;

         case INSTR_LD_B_FP:	vm->sp+=4; *(int*)   &vm->mem[vm->sp] = *(char*)  &vm->mem[arg_s+vm->fp]; break;
         case INSTR_LD_S_FP:	vm->sp+=4; *(int*)   &vm->mem[vm->sp] = *(short*) &vm->mem[arg_s+vm->fp]; break;
         case INSTR_LD_I_FP:	vm->sp+=4; *(int*)   &vm->mem[vm->sp] = *(int*)   &vm->mem[arg_s+vm->fp]; break;
         case INSTR_LD_L_FP:	vm->sp+=4; *(long*)  &vm->mem[vm->sp] = *(long*)  &vm->mem[arg_s+vm->fp];
                                vm->sp+=4;  break;
         case INSTR_LD_F_FP:	vm->sp+=4; *(float*) &vm->mem[vm->sp] = *(float*) &vm->mem[arg_s+vm->fp]; break;
         case INSTR_LD_D_FP:	vm->sp+=4; *(double*)&vm->mem[vm->sp] = *(double*)&vm->mem[arg_s+vm->fp];
                                vm->sp+=4;  break;

         case INSTR_LD_B_SP:	arg_i = *(int*) &vm->mem[vm->sp];
				*(int*)   &vm->mem[vm->sp] = *(char*)  &vm->mem[arg_i]; break;
         case INSTR_LD_S_SP:	arg_i = *(int*) &vm->mem[vm->sp];
				*(int*)   &vm->mem[vm->sp] = *(short*) &vm->mem[arg_i]; break;
         case INSTR_LD_I_SP:	arg_i = *(int*) &vm->mem[vm->sp];
				*(int*)   &vm->mem[vm->sp] = *(int*)   &vm->mem[arg_i]; break;
         case INSTR_LD_L_SP:	arg_i = *(int*) &vm->mem[vm->sp];
				*(long*)  &vm->mem[vm->sp] = *(long*)  &vm->mem[arg_i]; vm->sp+=4; break;
         case INSTR_LD_F_SP:	arg_i = *(int*) &vm->mem[vm->sp];
				*(float*) &vm->mem[vm->sp] = *(float*) &vm->mem[arg_i]; break;
         case INSTR_LD_D_SP:	arg_i = *(int*) &vm->mem[vm->sp];
				*(double*)&vm->mem[vm->sp] = *(double*)&vm->mem[arg_i]; vm->sp+=4; break;

         case INSTR_ST_B_IND:	arg_i = *(int*) &vm->mem[arg_i];
         case INSTR_ST_B:	*(char*)  &vm->mem[arg_i] = (char) *(int*)&vm->mem[vm->sp]; vm->sp-=4; break;
         case INSTR_ST_S_IND:	arg_i = *(int*) &vm->mem[arg_i];
         case INSTR_ST_S:	*(short*) &vm->mem[arg_i] = (short)*(int*)&vm->mem[vm->sp]; vm->sp-=4; break;
         case INSTR_ST_I_IND:	arg_i = *(int*) &vm->mem[arg_i];
         case INSTR_ST_I:	*(int*)   &vm->mem[arg_i] =        *(int*)&vm->mem[vm->sp]; vm->sp-=4; break;
         case INSTR_ST_L_IND:	arg_i = *(int*) &vm->mem[arg_i];
         case INSTR_ST_L:	vm->sp-=4;
                                *(long*)  &vm->mem[arg_i] =       *(long*)&vm->mem[vm->sp]; vm->sp-=4; break;
         case INSTR_ST_F_IND:	arg_i = *(int*) &vm->mem[arg_i];
         case INSTR_ST_F:	*(float*) &vm->mem[arg_i] =      *(float*)&vm->mem[vm->sp]; vm->sp-=4; break;
         case INSTR_ST_D_IND:	arg_i = *(int*) &vm->mem[arg_i];
         case INSTR_ST_D:	vm->sp-=4;
                                *(double*)&vm->mem[arg_i] =     *(double*)&vm->mem[vm->sp]; vm->sp-=4; break;

         case INSTR_ST_B_FP:	*(char*)  &vm->mem[arg_s+vm->fp] = (char) *(int*)&vm->mem[vm->sp];
                                vm->sp-=4; break;
         case INSTR_ST_S_FP:	*(short*) &vm->mem[arg_s+vm->fp] = (short)*(int*)&vm->mem[vm->sp];
                                vm->sp-=4; break;
         case INSTR_ST_I_FP:	*(int*)   &vm->mem[arg_s+vm->fp] =        *(int*)&vm->mem[vm->sp];
                                vm->sp-=4; break;
         case INSTR_ST_L_FP:	vm->sp-=4;
                                *(long*)  &vm->mem[arg_s+vm->fp] =       *(long*)&vm->mem[vm->sp];
                                vm->sp-=4; break;
         case INSTR_ST_F_FP:	*(float*) &vm->mem[arg_s+vm->fp] =      *(float*)&vm->mem[vm->sp];
                                vm->sp-=4; break;
         case INSTR_ST_D_FP:	vm->sp-=4;
                                *(double*)&vm->mem[arg_s+vm->fp] =     *(double*)&vm->mem[vm->sp];
                                vm->sp-=4; break;

         case INSTR_ST_B_SP:    arg_i = *(int*) &vm->mem[vm->sp-4];
                                *(char*)  &vm->mem[arg_i] = (char) *(int*)&vm->mem[vm->sp]; vm->sp-=8; break;
         case INSTR_ST_S_SP:    arg_i = *(int*) &vm->mem[vm->sp-4];
                                *(short*) &vm->mem[arg_i] = (short)*(int*)&vm->mem[vm->sp]; vm->sp-=8; break;
         case INSTR_ST_I_SP:    arg_i = *(int*) &vm->mem[vm->sp-4];
                                *(int*)   &vm->mem[arg_i] =        *(int*)&vm->mem[vm->sp]; vm->sp-=8; break;
         case INSTR_ST_L_SP:    vm->sp-=4;  arg_i = *(int*) &vm->mem[vm->sp-4];
                                *(long*)  &vm->mem[arg_i] =       *(long*)&vm->mem[vm->sp]; vm->sp-=8; break;
         case INSTR_ST_F_SP:    arg_i = *(int*) &vm->mem[vm->sp-4];
                                *(float*) &vm->mem[arg_i] =      *(float*)&vm->mem[vm->sp]; vm->sp-=8; break;
         case INSTR_ST_D_SP:    vm->sp-=4;  arg_i = *(int*) &vm->mem[vm->sp-4];
                                *(double*)&vm->mem[arg_i] =     *(double*)&vm->mem[vm->sp]; vm->sp-=8; break;

         case INSTR_LDC_I_0:	vm->sp+=4; *(int*)&vm->mem[vm->sp] =  0; break;
         case INSTR_LDC_I_1:	vm->sp+=4; *(int*)&vm->mem[vm->sp] =  1; break;
         case INSTR_LDC_I_M1:	vm->sp+=4; *(int*)&vm->mem[vm->sp] = -1; break;

         case INSTR_LDC_L_0:	vm->sp+=4; *(long*)&vm->mem[vm->sp] =  0; vm->sp+=4; break;
         case INSTR_LDC_L_1:	vm->sp+=4; *(long*)&vm->mem[vm->sp] =  1; vm->sp+=4; break;
         case INSTR_LDC_L_M1:	vm->sp+=4; *(long*)&vm->mem[vm->sp] = -1; vm->sp+=4; break;

         case INSTR_LDC_F_0:	vm->sp+=4; *(float*)&vm->mem[vm->sp] =  0; break;
         case INSTR_LDC_F_1:	vm->sp+=4; *(float*)&vm->mem[vm->sp] =  1; break;
         case INSTR_LDC_F_M1:	vm->sp+=4; *(float*)&vm->mem[vm->sp] = -1; break;

         case INSTR_LDC_D_0:	vm->sp+=4; *(double*)&vm->mem[vm->sp] =  0; vm->sp+=4; break;
         case INSTR_LDC_D_1:	vm->sp+=4; *(double*)&vm->mem[vm->sp] =  1; vm->sp+=4; break;
         case INSTR_LDC_D_M1:	vm->sp+=4; *(double*)&vm->mem[vm->sp] = -1; vm->sp+=4; break;

         case INSTR_ADD_I:	*(int*)&vm->mem[vm->sp-4]     += *(int*)&vm->mem[vm->sp];      vm->sp-=4; break;
         case INSTR_ADD_L:	*(long*)&vm->mem[vm->sp-12]   += *(long*)&vm->mem[vm->sp-4];   vm->sp-=8; break;
         case INSTR_ADD_F:	*(float*)&vm->mem[vm->sp-4]   += *(float*)&vm->mem[vm->sp];    vm->sp-=4; break;
         case INSTR_ADD_D:	*(double*)&vm->mem[vm->sp-12] += *(double*)&vm->mem[vm->sp-4]; vm->sp-=8; break;

         case INSTR_SUB_I:	*(int*)&vm->mem[vm->sp-4]     -= *(int*)&vm->mem[vm->sp];      vm->sp-=4; break;
         case INSTR_SUB_L:	*(long*)&vm->mem[vm->sp-12]   -= *(long*)&vm->mem[vm->sp-4];   vm->sp-=8; break;
         case INSTR_SUB_F:	*(float*)&vm->mem[vm->sp-4]   -= *(float*)&vm->mem[vm->sp];    vm->sp-=4; break;
         case INSTR_SUB_D:	*(double*)&vm->mem[vm->sp-12] -= *(double*)&vm->mem[vm->sp-4]; vm->sp-=8; break;

         case INSTR_MUL_I:	*(int*)&vm->mem[vm->sp-4]     *= *(int*)&vm->mem[vm->sp];      vm->sp-=4; break;
         case INSTR_MUL_L:	*(long*)&vm->mem[vm->sp-12]   *= *(long*)&vm->mem[vm->sp-4];   vm->sp-=8; break;
         case INSTR_MUL_F:	*(float*)&vm->mem[vm->sp-4]   *= *(float*)&vm->mem[vm->sp];    vm->sp-=4; break;
         case INSTR_MUL_D:	*(double*)&vm->mem[vm->sp-12] *= *(double*)&vm->mem[vm->sp-4]; vm->sp-=8; break;

         case INSTR_DIV_I:	*(int*)&vm->mem[vm->sp-4]     /= *(int*)&vm->mem[vm->sp];      vm->sp-=4; break;
         case INSTR_DIV_L:	*(long*)&vm->mem[vm->sp-12]   /= *(long*)&vm->mem[vm->sp-4];   vm->sp-=8; break;
         case INSTR_DIV_F:	*(float*)&vm->mem[vm->sp-4]   /= *(float*)&vm->mem[vm->sp];    vm->sp-=4; break;
         case INSTR_DIV_D:	*(double*)&vm->mem[vm->sp-12] /= *(double*)&vm->mem[vm->sp-4]; vm->sp-=8; break;

         case INSTR_REM_I:	*(int*)&vm->mem[vm->sp-4]     %= *(int*)&vm->mem[vm->sp];      vm->sp-=4; break;
         case INSTR_REM_L:	*(long*)&vm->mem[vm->sp-12]   %= *(long*)&vm->mem[vm->sp-4];   vm->sp-=8; break;
         case INSTR_REM_F:	not_implemented (e);
         case INSTR_REM_D:	not_implemented (e);

         case INSTR_NEG_I:	*(int*)&vm->mem[vm->sp]      = - *(int*)&vm->mem[vm->sp];      break;
         case INSTR_NEG_L:	*(long*)&vm->mem[vm->sp-4]   = - *(long*)&vm->mem[vm->sp-4];   break;
         case INSTR_NEG_F:	*(float*)&vm->mem[vm->sp]    = - *(float*)&vm->mem[vm->sp];    break;
         case INSTR_NEG_D:	*(double*)&vm->mem[vm->sp-4] = - *(double*)&vm->mem[vm->sp-4]; break;

         case INSTR_SHL_I:	*(int*)&vm->mem[vm->sp-4]  <<= *(int*)&vm->mem[vm->sp];  vm->sp-=4; break;
         case INSTR_SHL_L:	*(long*)&vm->mem[vm->sp-8] <<= *(int*)&vm->mem[vm->sp];  vm->sp-=4; break;
         case INSTR_SHR_I:	*(int*)&vm->mem[vm->sp-4]  >>= *(int*)&vm->mem[vm->sp];  vm->sp-=4; break;
         case INSTR_SHR_L:	*(long*)&vm->mem[vm->sp-8] >>= *(int*)&vm->mem[vm->sp];  vm->sp-=4; break;

         case INSTR_AND_I:	*(int*)&vm->mem[vm->sp-4]   &= *(int*)&vm->mem[vm->sp];     vm->sp-=4; break;
         case INSTR_AND_L:	*(long*)&vm->mem[vm->sp-12] &= *(long*)&vm->mem[vm->sp-4];  vm->sp-=8; break;
         case INSTR_OR_I:	*(int*)&vm->mem[vm->sp-4]   |= *(int*)&vm->mem[vm->sp];     vm->sp-=4; break;
         case INSTR_OR_L:	*(long*)&vm->mem[vm->sp-12] |= *(long*)&vm->mem[vm->sp-4];  vm->sp-=8; break;
         case INSTR_XOR_I:	*(int*)&vm->mem[vm->sp-4]   ^= *(int*)&vm->mem[vm->sp];     vm->sp-=4; break;
         case INSTR_XOR_L:	*(long*)&vm->mem[vm->sp-12] ^= *(long*)&vm->mem[vm->sp-4];  vm->sp-=8; break;

         case INSTR_CMP_I: {
		int r = *(int*)&vm->mem[vm->sp-4] - *(int*)&vm->mem[vm->sp]; vm->sp-=4;
                *(int*)&vm->mem[vm->sp] = r < 0 ? -1 : (r > 0 ? 1 : 0); }
                break;
         case INSTR_CMP_L: {
		long r = *(long*)&vm->mem[vm->sp-12] - *(long*)&vm->mem[vm->sp-4]; vm->sp-=12;
                *(int*)&vm->mem[vm->sp] = r < 0 ? -1 : (r > 0 ? 1 : 0); }
                break;
         case INSTR_CMP_F: {
                float r = *(float*)&vm->mem[vm->sp-4] - *(float*)&vm->mem[vm->sp]; vm->sp-=4;
                *(int*)&vm->mem[vm->sp] = r < 0 ? -1 : (r > 0 ? 1 : 0); }
                break;
         case INSTR_CMP_D: {
		double r = *(double*)&vm->mem[vm->sp-12] - *(double*)&vm->mem[vm->sp-4]; vm->sp-=12;
                *(int*)&vm->mem[vm->sp] = r < 0 ? -1 : (r > 0 ? 1 : 0); }
                break;

         case INSTR_I2B:	*(int*)   &vm->mem[vm->sp]   = (char)  *(int*)&vm->mem[vm->sp];               break;
         case INSTR_I2S:	*(int*)   &vm->mem[vm->sp]   = (short) *(int*)&vm->mem[vm->sp];               break;
         case INSTR_I2L:	*(long*)  &vm->mem[vm->sp]   =         *(int*)&vm->mem[vm->sp];    vm->sp+=4; break;
         case INSTR_I2F:	*(float*) &vm->mem[vm->sp]   =         *(int*)&vm->mem[vm->sp];               break;
         case INSTR_I2D:	*(double*)&vm->mem[vm->sp]   =         *(int*)&vm->mem[vm->sp];    vm->sp+=4; break;

         case INSTR_L2I:	*(int*)   &vm->mem[vm->sp-4] = (int)   *(long*)&vm->mem[vm->sp-4]; vm->sp-=4; break;
         case INSTR_L2F:	*(float*) &vm->mem[vm->sp-4] = (float) *(long*)&vm->mem[vm->sp-4]; vm->sp-=4; break;
         case INSTR_L2D:	*(double*)&vm->mem[vm->sp-4] = (double)*(long*)&vm->mem[vm->sp-4];            break;

         case INSTR_F2I:	*(int*)   &vm->mem[vm->sp]   = (int)   *(float*)&vm->mem[vm->sp];             break;
         case INSTR_F2L:	*(long*)  &vm->mem[vm->sp]   = (long)  *(float*)&vm->mem[vm->sp];  vm->sp+=4; break;
         case INSTR_F2D:	*(double*)&vm->mem[vm->sp]   = (double)*(float*)&vm->mem[vm->sp];  vm->sp+=4; break;

         case INSTR_D2I:	*(int*)   &vm->mem[vm->sp]   = (int)   *(double*)&vm->mem[vm->sp]; vm->sp-=4; break;
         case INSTR_D2L:	*(long*)  &vm->mem[vm->sp]   = (long)  *(double*)&vm->mem[vm->sp];            break;
         case INSTR_D2F:	*(float*) &vm->mem[vm->sp]   = (float) *(double*)&vm->mem[vm->sp]; vm->sp-=4; break;

         case INSTR_RET_I:	instr_ret_i (verbose, vm); break;
         case INSTR_RET_L:	instr_ret_l (verbose, vm); not_implemented (e); break;
         case INSTR_RET_F:	instr_ret_f (verbose, vm); not_implemented (e); break;
         case INSTR_RET_D:	instr_ret_d (verbose, vm); not_implemented (e); break;

         case INSTR_POP:	vm->sp -= 4; break;
         case INSTR_POP2:	vm->sp -= 8; break;

         case INSTR_DUP:	vm->sp += 4; *(int*)&vm->mem[vm->sp] = *(int*)&vm->mem[vm->sp-4]; break;
         case INSTR_DUP2:	vm->sp += 4; *(int*)&vm->mem[vm->sp] = *(int*)&vm->mem[vm->sp-8];
				vm->sp += 4; *(int*)&vm->mem[vm->sp] = *(int*)&vm->mem[vm->sp-8]; break;

         case INSTR_SWAP: {
            int* a = (int*)&vm->mem[vm->sp];
            int* b = (int*)&vm->mem[vm->sp-4];
            int c = *a; *a=*b; *b=c; }
            break;
         case INSTR_SWAP2: {
            long* a = (long*)&vm->mem[vm->sp];
            long* b = (long*)&vm->mem[vm->sp-8];
            long c = *a; *a=*b; *b=c; }
            break;

         case INSTR_DEC_FP:	vm->fp -= arg_s;		break;
         case INSTR_INC_SP:	vm->sp += arg_s;		break;
         case INSTR_DEC_SP:	vm->sp -= arg_s;		break;
         case INSTR_INC_I:	(*(int*) &vm->mem[arg_i])++;	break;
         case INSTR_INC_L: 	(*(long*)&vm->mem[arg_i])++;	break;
         case INSTR_RET:	instr_ret (verbose, vm);	break;
         case INSTR_JMP:	vm->pc = arg_i;			break;
         case INSTR_JSR:	instr_jsr (verbose, vm, arg_i);	break;
         case INSTR_FOPEN:	instr_fopen (verbose, vm);	break;
         case INSTR_FCLOSE:	instr_fclose (verbose, vm);	break;
         case INSTR_GETC:	instr_getc (verbose, vm);	break;
         case INSTR_PUTC:	instr_putc (verbose, vm);	break;
         case INSTR_READ:       instr_read (verbose, vm);       break;
         case INSTR_WRITE:      instr_write (verbose, vm);      break;
         case INSTR_HALT:	run = 0; rc = *(int*)&vm->mem[vm->sp];	break;
         case INSTR_BEQ:	if (!*(int*)&vm->mem[vm->sp]    )   vm->pc += arg_s; vm->sp-=4; break;
         case INSTR_BNE:	if (*(int*)&vm->mem[vm->sp]     )   vm->pc += arg_s; vm->sp-=4; break;
         case INSTR_BGE:	if (*(int*)&vm->mem[vm->sp] >= 0)   vm->pc += arg_s; vm->sp-=4; break;
         case INSTR_BGT:	if (*(int*)&vm->mem[vm->sp] >  0)   vm->pc += arg_s; vm->sp-=4; break;
         case INSTR_BLE:	if (*(int*)&vm->mem[vm->sp] <= 0)   vm->pc += arg_s; vm->sp-=4; break;
         case INSTR_BLT:	if (*(int*)&vm->mem[vm->sp] <  0)   vm->pc += arg_s; vm->sp-=4; break;
         case INSTR_NEW:	instr_new (verbose, vm);	break;
         case INSTR_DEL:	instr_del (verbose, vm);	break;
         default:
            not_implemented (e);
            break;
      }

      dump_status (verbose, vm);
   }


   if (verbose)  fprintf (stderr, "Execution terminated.\n");
   
   if (verbose > 3)  Heap_Dump (vm, verbose);

   return rc;
}

