/**
 * \file vm.h
 * \brief CKPM virtual machine definitions
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/

#ifndef _CKPM_VM_H_
#define _CKPM_VM_H_

#define VM_VERSION      0x00000001	/*!< version of the virtual machine */
#define VM_MEM_DEFAULT	4		/*!< default size of virtual machine memory in MB */
#define VM_MEM_MAX	64		/*!< maximum size of virtual machine memory in MB */


typedef unsigned int vm_addr_t;		/*!< virtual machine addresses */
typedef unsigned int vm_size_t;		/*!< virtual machine size type */

/**
 * \typedef vm_mem_t
 * \brief virtual machine memory
 * This structure describes the memory layout of the CKPMvm virtual machine 
 */
typedef struct _vm_mem_t {
   vm_addr_t pc;			/*!< program counter (index in mem) */
   vm_addr_t sp;			/*!< operand stack pointer (index in mem) */
   vm_addr_t fp;			/*!< frame pointer (index in mem) */
   vm_addr_t mem_max;			/*!< allocated virtual machine memory */
   vm_addr_t heap;			/*!< start of heap management (index in mem) */
   unsigned char mem[1];		/*!< variable length virtual machine memory */
} vm_mem_t;

#define VM_MEM_T_SIZE	(sizeof(vm_mem_t) - 1)	/*!< size of vm_mem_t without allocated memory for mem */



/*
 * forward declarations
 */
vm_mem_t* load_file (int verbose, int argc, char** argv, char* file_name, vm_size_t mem_size);
int run_vm (int verbose, vm_mem_t* vm_memory);
void shutdown_vm (int verbose, vm_mem_t* vm_memory);


#endif /* _CKPM_VM_H_ */

