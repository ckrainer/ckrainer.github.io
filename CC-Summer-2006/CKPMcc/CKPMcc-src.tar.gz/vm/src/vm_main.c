/**
 * \file vm_main.c
 * \brief CKPM virtual machine main program
 */
/* Copyright (C) 2006 by Clemens Krainer
 * @(#) $Id:$
 *
 * Author: Clemens Krainer <ClemensDaniel.Krainer@sbg.ac.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
 *****************************************************************************/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "vm.h"


/**
 * \brief print the usage message
 * \param exit_code variable containing the required return value
 * \return value from parameter exit_code
 *****************************************************************************/

int
print_usage (int exit_code) {
   puts ("Usage: CKPMvm [-hvV] [-s size] file [arg1] [arg2 ...]\n\n"
         "-h, --help          show this usage message.\n"
         "-s, --vm-mem-size   memory size of the virtual machine in MB\n"
         "-v, --verbose       verbose mode, additional '-v' increase verbosity.\n"
         "-V, --version       show version\n"
         "file                file name of the executable to be run by the virtual machine\n"
         "arg1, arg2, ...     arguments to be passed to the program\n"
   );
   return exit_code;
}


/**
 * \brief virtual machine main program
 * \param argc argument counter, contains the number of entries in argv
 * \param argv argument vector
 * \return exit code, 0 on success, otherwise 1
 *****************************************************************************/

int
main (int argc, char** argv) {
   char* file_name = NULL;
   int verbose = 0;
   int i, k, rc;
   vm_mem_t* vm_memory = NULL;
   size_t mem_size = VM_MEM_DEFAULT;

   int vm_argc = 0;
   char** vm_argv = (char**)NULL;


   for (i = 1; i < argc; i++) {
      if (!strcmp (argv[i], "--help") || !strcmp (argv[i], "-h") || !strcmp (argv[i], "-?")) {
         return print_usage (0);
      }

      if (!strcmp (argv[i], "--vm-mem-size") || !strcmp (argv[i], "-s") ) {
         if (++i < argc)
            mem_size = atoi (argv[i]);
         continue;
      }

      if (!strcmp (argv[i], "--version") || !strcmp (argv[i], "-V") ) {
         fprintf (stdout, "%d\n", VM_VERSION);
         return 0;
      }

      if (!strcmp (argv[i], "--verbose") || !strcmp (argv[i], "-v") ) {
         verbose++;
         continue;
      }

      file_name = argv[i];
      vm_argc = argc - i;
      vm_argv = (char**) malloc ( vm_argc * sizeof(char*) );
      for (k=0; k < vm_argc; k++)
         vm_argv[k] = argv[i+k];
      break;
/*
      if (i+1 != argc)
         return print_usage (1);
 */
   }

   if (!file_name || !*file_name)
         return print_usage (1);

   if (verbose) {
      fprintf (stdout, "Verbose mode, level is %d. VM version is %d\n", verbose, VM_VERSION);
      fprintf (stdout, "File name is '%s'\n", file_name);
   }

   vm_memory = load_file (verbose, vm_argc, vm_argv, file_name, mem_size);
   if (!vm_memory)
      return 1;

   rc = run_vm (verbose, vm_memory);

   shutdown_vm (verbose, vm_memory);

   return rc;
}
